"""Builds rsrc_windows_amd64.syso: a COFF object with the .exe icon and version info.
Go's linker picks up *.syso files automatically, so no extra tools are needed."""
import struct
import sys

ICO, OUT = sys.argv[1], sys.argv[2]
# optional: product name + manifest level (KettehLyzer runs without admin)
NAME = sys.argv[3] if len(sys.argv) > 3 else "KettehPot"
LEVEL = sys.argv[4] if len(sys.argv) > 4 else "requireAdministrator"
VERSION = (1, 3, 0, 0)
STRINGS = {
    "Comments": "By | Ketteh & Applepot",
    "CompanyName": "Ketteh INC",
    "FileDescription": NAME,
    "FileVersion": "1.3.0.0",
    "InternalName": NAME,
    "LegalCopyright": "© 2026 Ketteh INC",
    "OriginalFilename": NAME + ".exe",
    "ProductName": NAME,
    "ProductVersion": "1.3.0.0",
}
RT_ICON, RT_GROUP_ICON, RT_VERSION, RT_MANIFEST = 3, 14, 16, 24
LANG = 0x0409


def pad4(b):
    return b + b"\0" * (-len(b) % 4)


# ---------------------------------------------------------------- icon
ico = open(ICO, "rb").read()
_, ico_type, count = struct.unpack_from("<HHH", ico, 0)
assert ico_type == 1, "not an .ico file"
icons, group = [], struct.pack("<HHH", 0, 1, count)
for i in range(count):
    w, h, colors, _, planes, bpp, size, off = struct.unpack_from("<BBBBHHII", ico, 6 + 16 * i)
    icons.append(ico[off:off + size])
    group += struct.pack("<BBBBHHIH", w, h, colors, 0, planes, bpp, size, i + 1)


# ---------------------------------------------------------------- version info
def node(key, value=b"", wtype=1, value_len=None, children=()):
    k = (key + "\0").encode("utf-16-le")
    if value_len is None:
        value_len = len(value)
    body = pad4(struct.pack("<HHH", 0, value_len, wtype) + k) + value
    for c in children:
        body = pad4(body) + c
    return struct.pack("<H", len(body)) + body[2:]


def text(s):
    return (s + "\0").encode("utf-16-le")


ms = (VERSION[0] << 16) | VERSION[1]
ls = (VERSION[2] << 16) | VERSION[3]
fixed = struct.pack("<13I", 0xFEEF04BD, 0x00010000, ms, ls, ms, ls, 0x3F, 0, 0x40004, 1, 0, 0, 0)
strings = [node(k, text(v), 1, len(v) + 1) for k, v in STRINGS.items()]
string_table = node("040904B0", children=strings)
var = node("Translation", struct.pack("<HH", LANG, 0x04B0), 0)
version = node("VS_VERSION_INFO", fixed, 0, children=[
    node("StringFileInfo", children=[string_table]),
    node("VarFileInfo", children=[var]),
])

# ---------------------------------------------------------------- manifest (asks for admin on launch)
MANIFEST = b"""<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<assembly xmlns="urn:schemas-microsoft-com:asm.v1" manifestVersion="1.0">
  <assemblyIdentity type="win32" name="Ketteh.%s" version="1.3.0.0" processorArchitecture="amd64"/>
  <trustInfo xmlns="urn:schemas-microsoft-com:asm.v3">
    <security>
      <requestedPrivileges>
        <requestedExecutionLevel level="%s" uiAccess="false"/>
      </requestedPrivileges>
    </security>
  </trustInfo>
  <compatibility xmlns="urn:schemas-microsoft-com:compatibility.v1">
    <application>
      <supportedOS Id="{8e0f7a12-bfb3-4fe8-b9a5-48fd50a15a9a}"/>
    </application>
  </compatibility>
  <application xmlns="urn:schemas-microsoft-com:asm.v3">
    <windowsSettings>
      <activeCodePage xmlns="http://schemas.microsoft.com/SMI/2019/WindowsSettings">UTF-8</activeCodePage>
    </windowsSettings>
  </application>
</assembly>
""" % (NAME.encode(), LEVEL.encode())

# ---------------------------------------------------------------- resource tree
resources = {RT_ICON: {i + 1: d for i, d in enumerate(icons)},
             RT_GROUP_ICON: {1: group},
             RT_VERSION: {1: version},
             RT_MANIFEST: {1: MANIFEST}}

# layout: root dir, type dirs, name dirs (each with 1 language entry), data entries, data
def dir_size(n):
    return 16 + 8 * n

types = sorted(resources)
off = dir_size(len(types))
type_off, name_off = {}, {}
for t in types:
    type_off[t] = off
    off += dir_size(len(resources[t]))
for t in types:
    for n in sorted(resources[t]):
        name_off[(t, n)] = off
        off += dir_size(1)
entry_off = {}
for t in types:
    for n in sorted(resources[t]):
        entry_off[(t, n)] = off
        off += 16
data_off = {}
for t in types:
    for n in sorted(resources[t]):
        off += -off % 8
        data_off[(t, n)] = off
        off += len(resources[t][n])

sec = bytearray(off)
relocs = []

def put_dir(at, entries):
    struct.pack_into("<IIHHHH", sec, at, 0, 0, 0, 0, 0, len(entries))
    for i, (ident, target, is_dir) in enumerate(entries):
        struct.pack_into("<II", sec, at + 16 + 8 * i, ident, target | (0x80000000 if is_dir else 0))

put_dir(0, [(t, type_off[t], True) for t in types])
for t in types:
    put_dir(type_off[t], [(n, name_off[(t, n)], True) for n in sorted(resources[t])])
    for n in sorted(resources[t]):
        put_dir(name_off[(t, n)], [(LANG, entry_off[(t, n)], False)])
        data = resources[t][n]
        struct.pack_into("<IIII", sec, entry_off[(t, n)], data_off[(t, n)], len(data), 0, 0)
        relocs.append(entry_off[(t, n)])  # OffsetToData becomes an RVA at link time
        sec[data_off[(t, n)]:data_off[(t, n)] + len(data)] = data

# ---------------------------------------------------------------- COFF object
IMAGE_FILE_MACHINE_AMD64 = 0x8664
IMAGE_REL_AMD64_ADDR32NB = 0x0003
raw_ptr = 20 + 40
reloc_ptr = raw_ptr + len(sec)
sym_ptr = reloc_ptr + 10 * len(relocs)

out = struct.pack("<HHIIIHH", IMAGE_FILE_MACHINE_AMD64, 1, 0, sym_ptr, 1, 0, 0)
out += struct.pack("<8sIIIIIIHHI", b".rsrc", 0, 0, len(sec), raw_ptr, reloc_ptr, 0,
                   len(relocs), 0, 0x40000040)
out += bytes(sec)
for r in relocs:
    out += struct.pack("<IIH", r, 0, IMAGE_REL_AMD64_ADDR32NB)
out += struct.pack("<8sIhHBB", b".rsrc", 0, 1, 0, 3, 0)  # static symbol for the section
out += struct.pack("<I", 4)  # empty string table
open(OUT, "wb").write(out)
print(f"wrote {OUT}: {len(icons)} icons, {len(out)} bytes")
