// Discord: ONE live message per SS in the staff channel. It is posted after the first tool
// finishes and edited after every tool after that, so staff watch results come in.
package main

import (
	"bytes"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"os"
	"path/filepath"
	"regexp"
	"sort"
	"strconv"
	"strings"
	"time"
)

// Set at build time so players never see or type it:
//
//	go build -ldflags "-s -w -X main.webhookURL=https://discord.com/api/webhooks/..." .
//
// or drop a ketteh_webhook.txt with the URL next to the exe.
var webhookURL = ""

var reWebhook = regexp.MustCompile(`^https://(?:(?:canary|ptb)\.)?discord(?:app)?\.com/api/webhooks/\d+/[\w-]+$`)

func findWebhook() string {
	if reWebhook.MatchString(webhookURL) {
		return webhookURL
	}
	if exe, err := os.Executable(); err == nil {
		if b, err := os.ReadFile(filepath.Join(filepath.Dir(exe), "ketteh_webhook.txt")); err == nil {
			if u := strings.TrimSpace(string(b)); reWebhook.MatchString(u) {
				webhookURL = u
				return u
			}
		}
	}
	return ""
}

func fullReport() string {
	return "KETTEHPOT v" + version + "  ·  " + credits + "  ·  discord: zoe_mahhh\r\n" +
		"saved " + ts(time.Now()) + "\r\n\r\n" + report.String()
}

// ---------------------------------------------------------------- what ran this session

type toolRun struct {
	order        int
	name         string
	fails, warns []string
	took         time.Duration
	crashed      string
}

var (
	runs        = map[string]*toolRun{}
	mcAccounts  []string
	hookMsgID   string
	hookStarted = time.Now()
	hookBroken  bool
)

func noteAccount(name string) {
	name = strings.TrimSpace(name)
	if name == "" {
		return
	}
	for _, a := range mcAccounts {
		if strings.EqualFold(a, name) {
			return
		}
	}
	mcAccounts = append(mcAccounts, name)
}

func recordRun(order int, name string, fs []finding, took time.Duration, crashed string) {
	r := &toolRun{order: order, name: name, took: took, crashed: crashed}
	for _, f := range fs {
		if f.level == "FAIL" {
			r.fails = append(r.fails, f.text)
		} else {
			r.warns = append(r.warns, f.text)
		}
	}
	runs[name] = r // a re-run replaces the old result
}

// ---------------------------------------------------------------- building the message

var mdEscaper = strings.NewReplacer(`\`, `\\`, "*", `\*`, "_", `\_`, "~", `\~`, "`", "'", "|", `\|`, ">", `\>`, "#", `\#`)

func md(s string) string { return mdEscaper.Replace(s) }

// runeLen counts the way Discord does (UTF-16 units), so an emoji like 🔴 counts as 2.
func runeLen(s string) int {
	n := 0
	for _, r := range s {
		if r >= 0x10000 {
			n += 2
		} else {
			n++
		}
	}
	return n
}

// fieldValue lists fails then warnings, fitted into max characters.
func fieldValue(r *toolRun, max int) string {
	if r.crashed != "" {
		return "⚠ crashed: " + md(cut(r.crashed, 150))
	}
	if len(r.fails)+len(r.warns) == 0 {
		return fmt.Sprintf("nothing suspicious · %.1fs", r.took.Seconds())
	}
	var lines []string
	for _, f := range r.fails {
		lines = append(lines, "🔴 "+md(cut(f, 150)))
	}
	for _, w := range r.warns {
		lines = append(lines, "🟡 "+md(cut(w, 150)))
	}
	var b strings.Builder
	for i, l := range lines {
		more := fmt.Sprintf("… +%d more", len(lines)-i)
		if runeLen(b.String())+runeLen(l)+1+runeLen(more) > max {
			b.WriteString(more)
			break
		}
		b.WriteString(l + "\n")
	}
	return strings.TrimRight(b.String(), "\n")
}

func buildPayload(fieldCap int) map[string]any {
	var list []*toolRun
	totalF, totalW := 0, 0
	for _, r := range runs {
		list = append(list, r)
		totalF += len(r.fails)
		totalW += len(r.warns)
	}
	sort.Slice(list, func(i, j int) bool { return list[i].order < list[j].order })

	host, _ := os.Hostname()
	color, verdict := 0x8FE3C0, "✅ nothing suspicious so far"
	switch {
	case totalF > 0:
		color, verdict = 0xFF5C7A, fmt.Sprintf("🔴 %d fail · %d warn", totalF, totalW)
	case totalW > 0:
		color, verdict = 0xF5D58A, fmt.Sprintf("🟡 %d warning(s), no fails", totalW)
	}
	admin := "yes"
	if !isAdmin() {
		admin = "**NO** (a lot of checks couldn't run)"
	}
	acct := "not seen yet"
	if len(mcAccounts) > 0 {
		acct = "`" + strings.Join(mcAccounts, "`, `") + "`"
	}
	desc := fmt.Sprintf("**%s**\n\n**PC** `%s` · **user** `%s`\n**MC accounts** %s · **admin** %s\n**frozen** <t:%d:t> · **toolkit opened** <t:%d:t> · **updated** <t:%d:R>",
		verdict, host, currentUser(), acct, admin, ssStart.Unix(), hookStarted.Unix(), time.Now().Unix())

	// Discord caps a message's embed at 6000 characters and a field at 1024: share it out
	budget := 5400 - runeLen(desc) - 160
	var fields []map[string]any
	left := len(list)
	for _, r := range list {
		name := "✅ " + r.name
		switch {
		case r.crashed != "":
			name = "⚠️ " + r.name
		case len(r.fails) > 0:
			name = fmt.Sprintf("🔴 %s · %d fail, %d warn", r.name, len(r.fails), len(r.warns))
		case len(r.warns) > 0:
			name = fmt.Sprintf("🟡 %s · %d warn", r.name, len(r.warns))
		}
		share := (budget - runeLen(name)) / left
		if share > fieldCap {
			share = fieldCap
		}
		if share < 60 {
			share = 60
		}
		v := fieldValue(r, share)
		budget -= runeLen(name) + runeLen(v)
		left--
		fields = append(fields, map[string]any{"name": name, "value": v})
	}
	if len(fields) == 0 {
		fields = append(fields, map[string]any{"name": "waiting", "value": "no checks run yet"})
	}
	return map[string]any{
		"username":         "KettehPot",
		"allowed_mentions": map[string]any{"parse": []string{}},
		"embeds": []map[string]any{{
			"title":       "SS · " + host,
			"description": desc,
			"color":       color,
			"fields":      fields,
			"footer":      map[string]any{"text": fmt.Sprintf("KettehPot v%s · %d check(s) run · %s", version, len(list), credits)},
			"timestamp":   time.Now().UTC().Format(time.RFC3339),
		}},
	}
}

// ---------------------------------------------------------------- sending

var hookClient = &http.Client{Timeout: 15 * time.Second}

func hookDo(method, url string, body []byte) (int, []byte, error) {
	for attempt := 0; attempt < 3; attempt++ {
		req, err := http.NewRequest(method, url, bytes.NewReader(body))
		if err != nil {
			return 0, nil, err
		}
		req.Header.Set("Content-Type", "application/json")
		req.Header.Set("User-Agent", "KettehPot/"+version)
		resp, err := hookClient.Do(req)
		if err != nil {
			return 0, nil, err
		}
		b, _ := io.ReadAll(io.LimitReader(resp.Body, 1<<16))
		resp.Body.Close()
		if resp.StatusCode == 429 { // rate limited: wait what discord says, then retry
			var rl struct {
				RetryAfter float64 `json:"retry_after"`
			}
			json.Unmarshal(b, &rl)
			if rl.RetryAfter <= 0 || rl.RetryAfter > 10 {
				rl.RetryAfter = 2
			}
			time.Sleep(time.Duration(rl.RetryAfter*1000) * time.Millisecond)
			continue
		}
		return resp.StatusCode, b, nil
	}
	return 429, nil, nil
}

// syncWebhook posts the live message, or edits it if it already exists.
func syncWebhook(loud bool) bool {
	url := findWebhook()
	if url == "" {
		if loud {
			colorPrint("   no staff webhook in this build", "DarkGray")
		}
		return false
	}
	var code int
	var err error
	// full detail first; if Discord says the message is too big (400), send shorter lists
	for _, fieldCap := range []int{900, 400, 150} {
		body, _ := json.Marshal(buildPayload(fieldCap))
		code, err = sendHook(url, body)
		if err != nil || code != 400 {
			break
		}
	}
	if err == nil && code/100 == 2 {
		hookBroken = false
		return true
	}
	{
		why := "no internet?"
		if err == nil {
			why = "status " + strconv.Itoa(code)
		}
		colorPrint("   couldn't update the staff discord ("+why+")", "DarkGray")
	}
	hookBroken = true
	return false
}

// sendHook edits the live message, or posts it when there isn't one yet (or it was deleted).
func sendHook(url string, body []byte) (int, error) {
	if hookMsgID != "" {
		code, _, err := hookDo("PATCH", url+"/messages/"+hookMsgID, body)
		if err != nil || code != 404 {
			return code, err
		}
		hookMsgID = "" // deleted in discord: post a fresh one
	}
	code, resp, err := hookDo("POST", url+"?wait=true", body)
	if err == nil && code/100 == 2 {
		var m struct {
			ID string `json:"id"`
		}
		json.Unmarshal(resp, &m)
		hookMsgID = m.ID
	}
	return code, err
}

// the W key
func sendWebhook() {
	if findWebhook() == "" {
		u := strings.TrimSpace(readHost("   paste the staff webhook URL (enter = cancel) >"))
		if u == "" {
			return
		}
		if !reWebhook.MatchString(u) {
			colorPrint("   that's not a discord webhook link", "Red")
			return
		}
		webhookURL = u
	}
	if len(runs) == 0 {
		colorPrint("   run some checks first (A runs everything)", "DarkGray")
		return
	}
	if syncWebhook(true) {
		colorPrint("   staff discord is up to date </3", "Green")
	}
}
