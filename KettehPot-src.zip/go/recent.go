// Recent Activity: files and folders opened recently, UserAssist run counts, Win+R history.
package main

import (
	"encoding/binary"
	"fmt"
	"os"
	"path/filepath"
	"sort"
	"strings"
	"time"
	"unicode/utf16"
)

// ---------------------------------------------------------------- .lnk parsing

// lnkTarget returns the full path a Windows shortcut points at ("" if it has none).
func lnkTarget(b []byte) string {
	if len(b) < 0x4C || binary.LittleEndian.Uint32(b) != 0x4C {
		return ""
	}
	flags := binary.LittleEndian.Uint32(b[0x14:])
	off := 0x4C
	if flags&0x1 != 0 {
		if off+2 > len(b) {
			return ""
		}
		off += 2 + int(binary.LittleEndian.Uint16(b[off:]))
	}
	if flags&0x2 == 0 || off+28 > len(b) {
		return ""
	}
	li := b[off:]
	liSize := int(binary.LittleEndian.Uint32(li))
	hdr := int(binary.LittleEndian.Uint32(li[4:]))
	liFlags := binary.LittleEndian.Uint32(li[8:])
	if liSize > len(li) || liFlags&1 == 0 {
		return ""
	}
	if hdr >= 0x24 && len(li) >= 0x24 {
		if u := int(binary.LittleEndian.Uint32(li[28:])); u > 0 && u < liSize {
			if s := utf16At(li, u, 520); s != "" {
				return s
			}
		}
	}
	base := cString(li, int(binary.LittleEndian.Uint32(li[16:])))
	suffix := cString(li, int(binary.LittleEndian.Uint32(li[24:])))
	if suffix != "" && !strings.HasSuffix(base, `\`) {
		base += `\`
	}
	return base + suffix
}

func cString(b []byte, off int) string {
	if off <= 0 || off >= len(b) {
		return ""
	}
	end := off
	for end < len(b) && b[end] != 0 {
		end++
	}
	return string(b[off:end])
}

// ---------------------------------------------------------------- UserAssist

func rot13(s string) string {
	r := []rune(s)
	for i, c := range r {
		switch {
		case c >= 'a' && c <= 'z':
			r[i] = 'a' + (c-'a'+13)%26
		case c >= 'A' && c <= 'Z':
			r[i] = 'A' + (c-'A'+13)%26
		}
	}
	return string(r)
}

var knownFolders = map[string]string{
	"{6D809377-6AF0-444B-8957-A3773F02200E}": `C:\Program Files`,
	"{7C5A40EF-A0FB-4BFC-874A-C0F2E0B9FA8E}": `C:\Program Files (x86)`,
	"{1AC14E77-02E7-4E5D-B744-2EB1AE5198B7}": `C:\Windows\System32`,
	"{D65231B0-B2F1-4857-A4CE-A8E7C6EA7D27}": `C:\Windows\SysWOW64`,
	"{F38BF404-1D43-42F2-9305-67DE0B28FC23}": `C:\Windows`,
	"{374DE290-123F-4565-9164-39C4925E467B}": `%USERPROFILE%\Downloads`,
	"{B4BFCC3A-DB2C-424C-B029-7FE99A87C641}": `%USERPROFILE%\Desktop`,
	"{FDD39AD0-238F-46AF-ADB4-6C85480369C7}": `%USERPROFILE%\Documents`,
	"{0762D272-C50A-4BB0-A382-697DCD729B80}": `C:\Users`,
	"{A77F5D77-2E2B-44C3-A6A2-ABA601054A51}": `%APPDATA%\Microsoft\Windows\Start Menu\Programs`,
	"{9E3995AB-1F9C-4F13-B827-48B24B6C7174}": `%APPDATA%\Microsoft\Internet Explorer\Quick Launch\User Pinned`,
}

func expandKnown(p string) string {
	for g, real := range knownFolders {
		if strings.HasPrefix(strings.ToUpper(p), g) {
			p = real + p[len(g):]
			break
		}
	}
	p = strings.ReplaceAll(p, "%USERPROFILE%", homeDir())
	p = strings.ReplaceAll(p, "%APPDATA%", appData())
	return p
}

type uaEntry struct {
	path string
	runs uint32
	last time.Time
}

func userAssist() []uaEntry {
	const base = `Software\Microsoft\Windows\CurrentVersion\Explorer\UserAssist`
	guids, _ := regSubkeys(hkcu, base)
	var out []uaEntry
	for _, g := range guids {
		vals, _ := regValues(hkcu, base+`\`+g+`\Count`)
		for _, v := range vals {
			if len(v.Data) < 68 {
				continue
			}
			name := rot13(v.Name)
			if strings.HasPrefix(name, "UEME_") {
				continue
			}
			out = append(out, uaEntry{
				path: expandKnown(name),
				runs: binary.LittleEndian.Uint32(v.Data[4:]),
				last: filetime(binary.LittleEndian.Uint64(v.Data[60:])),
			})
		}
	}
	sort.Slice(out, func(i, j int) bool { return out[i].last.After(out[j].last) })
	return out
}

// ---------------------------------------------------------------- the tool

type recentItem struct {
	opened time.Time
	target string
	lnk    string
}

func runRecent() {
	const window = 48 * time.Hour

	// ---------------- recent files + folders
	section("Opened files & folders  ·  last 48h")
	dir := filepath.Join(appData(), `Microsoft\Windows\Recent`)
	entries, err := os.ReadDir(dir)
	if err != nil {
		row("WARN", "Recent folder", "can't read it", err.Error())
	}
	var items []recentItem
	for _, e := range entries {
		if e.IsDir() || !strings.EqualFold(filepath.Ext(e.Name()), ".lnk") {
			continue
		}
		info, err := e.Info()
		if err != nil {
			continue
		}
		it := recentItem{opened: info.ModTime(), lnk: strings.TrimSuffix(e.Name(), filepath.Ext(e.Name()))}
		if b, err := os.ReadFile(filepath.Join(dir, e.Name())); err == nil {
			it.target = lnkTarget(b)
		}
		items = append(items, it)
	}
	sort.Slice(items, func(i, j int) bool { return items[i].opened.After(items[j].opened) })
	if len(entries) > 0 && len(items) < 3 {
		row("WARN", "Recent items", fmt.Sprintf("only %d", len(items)), "the recent list looks cleared")
	}
	var opened, started, typedLines []string // everything, for the discord message
	shown, flagged := 0, 0
	for _, it := range items {
		if it.opened.Before(time.Now().Add(-window)) {
			break
		}
		name := it.lnk
		path := it.target
		if path == "" {
			path = "(no path stored) " + it.lnk
		}
		gone := it.target != "" && !exists(it.target)
		fl := exeFlags(name + " " + path)
		lowp := strings.ToLower(path)
		risky := strings.HasSuffix(lowp, ".jar") || strings.HasSuffix(lowp, ".exe") || strings.HasSuffix(lowp, ".ahk") ||
			strings.Contains(lowp, `\mods`) || strings.Contains(lowp, ".minecraft")
		mark, gonetxt := "  ", ""
		switch {
		case len(fl) > 0:
			mark = "✗ "
		case gone && risky:
			mark = "! "
		}
		if gone {
			gonetxt = "  (gone)"
		}
		opened = append(opened, mark+it.opened.Format("01-02 15:04")+"  "+path+gonetxt)
		switch {
		case len(fl) > 0:
			flagged++
			row(fl[0].level, cut(name, 24), fl[0].label, "opened "+ago(it.opened))
			sub(path, "DarkGray")
		case gone && risky:
			flagged++
			row("WARN", cut(name, 24), "opened, gone now", "opened "+ago(it.opened))
			sub(path, "DarkGray")
		default:
			line := fmt.Sprintf("   %s  %s", it.opened.Format("01-02 15:04"), cut(path, 90))
			if shown < 25 {
				outln(line, map[bool]string{true: "White", false: "Gray"}[risky])
			} else {
				report.WriteString(line + "\r\n")
			}
			shown++
		}
	}
	if shown > 25 {
		outln(fmt.Sprintf("   ... %d more in the saved report", shown-25), "DarkGray")
	}
	if flagged == 0 {
		row("OK", "Flagged recent items", "none", "")
	}

	// ---------------- UserAssist
	section("UserAssist  ·  programs started from explorer / start menu")
	ua := userAssist()
	if len(ua) == 0 {
		row("WARN", "UserAssist", "empty", "either tracking is off or it was cleared")
	}
	uaShown := 0
	for _, u := range ua {
		if u.last.Before(time.Now().Add(-window)) {
			break
		}
		name := filepath.Base(strings.ReplaceAll(u.path, `\`, "/"))
		fl := exeFlags(name)
		gone := len(u.path) > 2 && u.path[1] == ':' && strings.HasSuffix(strings.ToLower(u.path), ".exe") && !exists(u.path)
		mark, gonetxt := "  ", ""
		if len(fl) > 0 {
			mark = "✗ "
		} else if gone {
			mark, gonetxt = "! ", "  (gone)"
		}
		started = append(started, fmt.Sprintf("%s%s  %s  %dx%s", mark, u.last.Format("01-02 15:04"), u.path, u.runs, gonetxt))
		switch {
		case len(fl) > 0:
			row(fl[0].level, cut(name, 24), fl[0].label, fmt.Sprintf("%dx · last %s", u.runs, ago(u.last)))
			sub(u.path, "DarkGray")
		case gone:
			row("WARN", cut(name, 24), "exe gone now", fmt.Sprintf("%dx · last %s", u.runs, ago(u.last)))
			sub(u.path, "DarkGray")
		default:
			if uaShown < 15 {
				outn(fmt.Sprintf("   %s  %s", u.last.Format("01-02 15:04"), pad(cut(name, 40), 40)), "Gray")
				outln(fmt.Sprintf("  %dx", u.runs), "DarkGray")
			} else {
				report.WriteString(fmt.Sprintf("   %s  %s  %dx\r\n", u.last.Format("01-02 15:04"), u.path, u.runs))
			}
			uaShown++
		}
	}

	// ---------------- Win+R and typed paths
	section("Typed into Win+R / the address bar")
	typed := 0
	for _, k := range []struct{ path, label string }{
		{`Software\Microsoft\Windows\CurrentVersion\Explorer\RunMRU`, "Win+R"},
		{`Software\Microsoft\Windows\CurrentVersion\Explorer\TypedPaths`, "Address bar"},
	} {
		vals, _ := regValues(hkcu, k.path)
		for _, v := range vals {
			if v.Name == "MRUList" || v.Type != 1 {
				continue
			}
			s := strings.TrimSuffix(utf16Z(v.Data), `\1`)
			if s == "" {
				continue
			}
			typed++
			lvl := "INFO"
			why := ""
			if fl := psFlags(s); len(fl) > 0 {
				lvl, why = fl[0].level, fl[0].label
			} else if fl := exeFlags(s); len(fl) > 0 {
				lvl, why = fl[0].level, fl[0].label
			}
			row(lvl, k.label, cut(s, 60), why)
			mark := "  "
			if lvl != "INFO" {
				mark = "✗ "
			}
			typedLines = append(typedLines, mark+pad(k.label, 12)+s)
		}
	}
	if typed == 0 {
		row("OK", "Typed commands", "none saved", "")
	}

	// everything above, in one separate discord message
	sendDetail("Recent Activity", "🗂️", []detailSection{
		{"OPENED FILES & FOLDERS · last 48h", opened},
		{"STARTED FROM START / EXPLORER · last 48h", started},
		{"TYPED IN WIN+R / ADDRESS BAR", typedLines},
	})
}

func utf16Z(b []byte) string {
	u := make([]uint16, 0, len(b)/2)
	for i := 0; i+1 < len(b); i += 2 {
		c := uint16(b[i]) | uint16(b[i+1])<<8
		if c == 0 {
			break
		}
		u = append(u, c)
	}
	return string(utf16.Decode(u))
}
