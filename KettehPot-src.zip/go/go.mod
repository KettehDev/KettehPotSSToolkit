module kettehpot

go 1.24
