// GUI mode: the toolkit serves a small page on 127.0.0.1 (random port + secret token)
// and opens it as an app window. Every row / section / question becomes a live event.
package main

import (
	"crypto/rand"
	_ "embed"
	"encoding/base64"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"net"
	"net/http"
	"os"
	"strconv"
	"strings"
	"sync"
	"sync/atomic"
	"time"
)

//go:embed web/index.html
var indexHTML string

//go:embed web/logo.png
var logoPNG []byte

var (
	gui     bool   // true when the window is driving the toolkit
	guiTool string // key of the tool that's running, events are tagged with it

	evMu      sync.Mutex
	evLog     [][]byte // every event so far, replayed when the page (re)connects
	evSubs    = map[chan int]bool{}
	evCount   int
	lastSeen  = time.Now()
	connected bool

	promptMu   sync.Mutex
	promptSeq  int
	promptWait = map[int]chan string{}

	runMu   sync.Mutex
	running bool

	structDepth int // >0 while row()/section()/... print, so their pieces aren't also sent as text
	lineBuf     strings.Builder
	lineColor   string
	noteBuf     strings.Builder
	noteColor   string
)

// emit sends one event to the window.
func emit(ev map[string]any) {
	if !gui {
		return
	}
	if _, ok := ev["key"]; !ok && guiTool != "" {
		ev["key"] = guiTool
	}
	b, _ := json.Marshal(ev)
	evMu.Lock()
	evLog = append(evLog, b)
	evCount = len(evLog)
	for ch := range evSubs {
		select {
		case ch <- evCount:
		default:
		}
	}
	evMu.Unlock()
}

// guiText collects out() pieces into whole lines.
func guiText(text, color string, newline bool) {
	if lineBuf.Len() == 0 {
		lineColor = color
	}
	lineBuf.WriteString(text)
	if newline {
		line := strings.TrimRight(lineBuf.String(), " ")
		lineBuf.Reset()
		emit(map[string]any{"type": "text", "text": line, "color": lineColor})
	}
}

// guiNote collects colorPart/colorPrint (console-only messages) into toasts.
func guiNote(text, color string, newline bool) {
	if noteBuf.Len() == 0 {
		noteColor = color
	}
	noteBuf.WriteString(text)
	if newline {
		t := strings.TrimSpace(strings.ReplaceAll(noteBuf.String(), "↳", ""))
		noteBuf.Reset()
		if t != "" {
			emit(map[string]any{"type": "note", "text": t, "color": noteColor})
		}
	}
}

// ---------------------------------------------------------------- questions

// guiAsk shows a popup in the window and waits for the answer.
// kind: yesno | text | time | choose. Returns "" when cancelled.
func guiAsk(kind, title, message string, extra map[string]any) string {
	promptMu.Lock()
	promptSeq++
	id := promptSeq
	ch := make(chan string, 1)
	promptWait[id] = ch
	promptMu.Unlock()
	ev := map[string]any{"type": "prompt", "id": id, "kind": kind, "title": title, "message": message}
	for k, v := range extra {
		ev[k] = v
	}
	emit(ev)
	ans := <-ch
	emit(map[string]any{"type": "prompt_done", "id": id})
	return ans
}

type choice struct {
	Label string `json:"label"`
	Desc  string `json:"desc"`
}

// choose lets the user pick one option or type a path (console: numbered list).
// Returns the option index (or -1 with a path), ok=false when cancelled.
func choose(title, hint string, opts []choice, allowPath bool) (int, string, bool) {
	if gui {
		a := guiAsk("choose", title, hint, map[string]any{"options": opts, "allowPath": allowPath})
		if a == "" {
			return 0, "", false
		}
		if strings.HasPrefix(a, "#") {
			n, err := strconv.Atoi(a[1:])
			if err == nil && n >= 0 && n < len(opts) {
				return n, "", true
			}
			return 0, "", false
		}
		return -1, strings.Trim(strings.TrimSpace(a), `"'`), true
	}
	section(title)
	for i, o := range opts {
		colorPart(fmt.Sprintf("   [%d]  ", i+1), "Magenta")
		colorPart(pad(cut(o.Label, 40), 42), "White")
		colorPrint(o.Desc, "DarkGray")
	}
	if len(opts) == 0 {
		colorPrint("   nothing found automatically", "DarkGray")
	}
	if hint != "" {
		colorPrint("   "+hint, "DarkGray")
	}
	q := "   number (enter = back) >"
	if allowPath {
		q = "   number or path (enter = back) >"
	}
	for {
		a := strings.Trim(strings.TrimSpace(readHost(q)), `"'`)
		if a == "" || strings.EqualFold(a, "q") {
			return 0, "", false
		}
		if n, err := strconv.Atoi(a); err == nil && n >= 1 && n <= len(opts) {
			return n - 1, "", true
		}
		if allowPath {
			return -1, a, true
		}
		colorPrint("   pick a number from the list", "DarkGray")
	}
}

// ---------------------------------------------------------------- running tools

func toolByKey(key string) (tool, bool) {
	for _, t := range tools {
		if t.key == key {
			return t, true
		}
	}
	return tool{}, false
}

// runAll runs every tool marked inAll, then the summary + desktop copy.
func runAll() {
	module = ""
	total, n := 0, 0
	for _, t := range tools {
		if t.inAll {
			total++
		}
	}
	started := time.Now()
	emit(map[string]any{"type": "all_start", "total": total})
	for _, t := range tools {
		if t.inAll {
			n++
			progress = fmt.Sprintf("[%d/%d]", n, total)
			emit(map[string]any{"type": "all_progress", "n": n, "total": total, "name": t.name})
			runTool(t)
		}
	}
	progress = ""
	guiTool = ""
	finalSummary()
	blank()
	outln(fmt.Sprintf("   all %d checks done in %s", total, shortDur(time.Since(started)+time.Minute-time.Second)), "DarkGray")
	path := autoSaveReport()
	emit(map[string]any{"type": "all_done", "took": time.Since(started).Seconds(), "saved": path})
}

func autoSaveReport() string {
	path := outputDir() + string(os.PathSeparator) + "kettehpot_report_" + time.Now().Format("2006-01-02_15-04-05") + ".txt"
	if writeText(path, fullReport()) == nil {
		colorPrint("   full report saved -> "+path, "Green")
		return path
	}
	return ""
}

func summaryEvent() {
	var fs, ws []map[string]string
	for _, f := range findings {
		m := map[string]string{"module": f.module, "text": f.text}
		if f.level == "FAIL" {
			fs = append(fs, m)
		} else {
			ws = append(ws, m)
		}
	}
	emit(map[string]any{"type": "summary", "key": "", "fails": fs, "warns": ws})
}

// ---------------------------------------------------------------- the server

func randToken() string {
	b := make([]byte, 16)
	rand.Read(b)
	return hex.EncodeToString(b)
}

// startGUI serves the page and returns its URL.
func startGUI() (string, error) {
	ln, err := net.Listen("tcp", "127.0.0.1:0") // this pc only, random free port
	if err != nil {
		return "", err
	}
	token := randToken()
	guiBase, guiToken = "http://"+ln.Addr().String(), token
	mux := http.NewServeMux()
	authed := func(h http.HandlerFunc) http.HandlerFunc {
		return func(w http.ResponseWriter, r *http.Request) {
			if r.URL.Query().Get("t") != token {
				http.Error(w, "no", http.StatusForbidden)
				return
			}
			w.Header().Set("Cache-Control", "no-store")
			h(w, r)
		}
	}
	mux.HandleFunc("/", authed(func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Content-Type", "text/html; charset=utf-8")
		page := strings.Replace(indexHTML, "{{LOGO}}", "data:image/png;base64,"+base64.StdEncoding.EncodeToString(logoPNG), -1)
		w.Write([]byte(page))
	}))
	mux.HandleFunc("/events", authed(serveEvents))
	mux.HandleFunc("/lyzer", authed(func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Content-Type", "text/html; charset=utf-8")
		page := strings.Replace(lyzerHTML, "{{LOGO}}", "data:image/png;base64,"+base64.StdEncoding.EncodeToString(logoPNG), -1)
		w.Write([]byte(page))
	}))
	mux.HandleFunc("/api/lyzer", authed(func(w http.ResponseWriter, r *http.Request) {
		lyzerMu.Lock()
		b := lyzerJSON
		lyzerMu.Unlock()
		w.Header().Set("Content-Type", "application/json")
		if b == nil {
			w.Write([]byte("null"))
			return
		}
		w.Write(b)
	}))
	mux.HandleFunc("/api/run", authed(func(w http.ResponseWriter, r *http.Request) {
		key := r.URL.Query().Get("key")
		runMu.Lock()
		if running {
			runMu.Unlock()
			http.Error(w, "busy", http.StatusConflict)
			return
		}
		running = true
		runMu.Unlock()
		go func() {
			defer func() {
				recover()
				runMu.Lock()
				running = false
				runMu.Unlock()
				guiTool = ""
				emit(map[string]any{"type": "idle", "key": ""})
			}()
			switch key {
			case "all":
				runAll()
			case "save":
				guiTool = ""
				saveReport()
			case "discord":
				guiTool = ""
				sendWebhook()
			default:
				if t, ok := toolByKey(key); ok {
					runTool(t)
					summaryEvent()
				}
			}
		}()
		w.WriteHeader(http.StatusNoContent)
	}))
	mux.HandleFunc("/api/answer", authed(func(w http.ResponseWriter, r *http.Request) {
		id, _ := strconv.Atoi(r.URL.Query().Get("id"))
		promptMu.Lock()
		ch, ok := promptWait[id]
		delete(promptWait, id)
		promptMu.Unlock()
		if ok {
			ch <- r.URL.Query().Get("v")
		}
		w.WriteHeader(http.StatusNoContent)
	}))
	mux.HandleFunc("/api/reveal", authed(func(w http.ResponseWriter, r *http.Request) {
		// show a scanned jar in Explorer (only files KettehLyzer actually scanned)
		p := r.URL.Query().Get("path")
		if lyzerKnows(p) {
			revealInExplorer(p)
		}
		w.WriteHeader(http.StatusNoContent)
	}))
	mux.HandleFunc("/api/openlyzer", authed(func(w http.ResponseWriter, r *http.Request) {
		openBrowser(lyzerURL())
		w.WriteHeader(http.StatusNoContent)
	}))
	mux.HandleFunc("/api/quit", authed(func(w http.ResponseWriter, r *http.Request) {
		w.WriteHeader(http.StatusNoContent)
		go func() { time.Sleep(300 * time.Millisecond); os.Exit(0) }()
	}))
	go http.Serve(ln, mux)
	return fmt.Sprintf("http://%s/?t=%s", ln.Addr().String(), token), nil
}

// serveEvents streams events (server-sent events), replaying what the page missed.
func serveEvents(w http.ResponseWriter, r *http.Request) {
	fl, ok := w.(http.Flusher)
	if !ok {
		http.Error(w, "no stream", 500)
		return
	}
	w.Header().Set("Content-Type", "text/event-stream")
	w.Header().Set("Connection", "keep-alive")
	from, _ := strconv.Atoi(r.Header.Get("Last-Event-ID"))
	ch := make(chan int, 1)
	evMu.Lock()
	evSubs[ch] = true
	connected = true
	evMu.Unlock()
	if r.URL.Query().Get("view") == "lyzer" {
		atomic.AddInt32(&lyzerViewers, 1)
		defer atomic.AddInt32(&lyzerViewers, -1)
	}
	defer func() {
		evMu.Lock()
		delete(evSubs, ch)
		lastSeen = time.Now()
		evMu.Unlock()
	}()
	send := func() bool {
		evMu.Lock()
		batch := evLog[from:]
		evMu.Unlock()
		for i, b := range batch {
			if _, err := fmt.Fprintf(w, "id: %d\ndata: %s\n\n", from+i+1, b); err != nil {
				return false
			}
		}
		from += len(batch)
		fl.Flush()
		return true
	}
	if !send() {
		return
	}
	tick := time.NewTicker(15 * time.Second)
	defer tick.Stop()
	for {
		select {
		case <-r.Context().Done():
			return
		case <-ch:
			if !send() {
				return
			}
		case <-tick.C:
			if _, err := fmt.Fprint(w, ": ping\n\n"); err != nil {
				return
			}
			fl.Flush()
		}
	}
}

// watchWindow exits once the window has been closed for a while.
func watchWindow() {
	for {
		time.Sleep(2 * time.Second)
		evMu.Lock()
		gone := connected && len(evSubs) == 0 && time.Since(lastSeen) > 12*time.Second
		evMu.Unlock()
		if gone {
			os.Exit(0)
		}
	}
}

// waitConnected reports whether the window connected within d.
func waitConnected(d time.Duration) bool {
	deadline := time.Now().Add(d)
	for time.Now().Before(deadline) {
		evMu.Lock()
		c := connected
		evMu.Unlock()
		if c {
			return true
		}
		time.Sleep(200 * time.Millisecond)
	}
	return false
}

func helloEvent() {
	host, _ := os.Hostname()
	var ts []map[string]any
	for _, t := range tools {
		ts = append(ts, map[string]any{"key": t.key, "name": t.name, "desc": t.desc, "inAll": t.inAll})
	}
	emit(map[string]any{"type": "hello", "key": "", "host": host, "user": currentUser(), "admin": isAdmin(),
		"version": version, "credits": credits, "tools": ts, "discord": findWebhook() != ""})
}
