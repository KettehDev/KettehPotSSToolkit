// DNS History: sites this PC looked up recently. Cheat clients log in to their own servers,
// so their domains show up here even after the cheat itself is deleted.
package main

import (
	"fmt"
	"regexp"
	"sort"
	"strings"
)

// known cheat client / injector sites
var cheatDomains = []struct{ domain, label string }{
	{"vape.gg", "Vape"}, {"manthe.industries", "Vape"}, {"intent.store", "Intent (Rise / Vape)"},
	{"riseclient.com", "Rise"}, {"liquidbounce.net", "LiquidBounce"}, {"ccbluex.net", "LiquidBounce"},
	{"meteorclient.com", "Meteor"}, {"wurstclient.net", "Wurst"}, {"aristois.net", "Aristois"},
	{"impactclient.net", "Impact"}, {"futureclient.net", "Future"}, {"rusherhack.org", "RusherHack"},
	{"novoline.wtf", "Novoline"}, {"sigmaclient.info", "Sigma"}, {"sigmaclient.cloud", "Sigma"},
	{"prestigeclient.vip", "Prestige"}, {"entropy.club", "Entropy"}, {"slinky.gg", "Slinky"},
	{"doomsdayclient.com", "Doomsday"}, {"whiteout.lol", "Whiteout"}, {"drip.gg", "Drip"},
	{"boze.dev", "Boze"}, {"thunderhack.net", "ThunderHack"}, {"argonclient.com", "Argon"},
	{"kryptonclient.com", "Krypton"}, {"virel.dev", "Virel"}, {"catalystclient.com", "Catalyst"},
	{"clickcrystals.xyz", "ClickCrystals"}, {"inertiaclient.com", "Inertia"}, {"opautoclicker.com", "OP Auto Clicker"},
	{"autoclicker.io", "autoclicker"}, {"gs-autoclicker.com", "GS Auto Clicker"}, {"speedautoclicker.net", "Speed AutoClicker"},
	{"cheatengine.org", "Cheat Engine"}, {"unknowncheats.me", "UnknownCheats forum"}, {"mpgh.net", "MPGH cheat forum"},
}

var (
	reCheatyHost = regexp.MustCompile(`(?i)(^|[.\-])(cheat|cheats|hack|hacks|hacked|inject|injector|clicker|ghostclient|ghost-client|killaura|bypass|crack|cracked)([.\-]|$)`)
	fileHosts    = []string{"mediafire.com", "mega.nz", "mega.io", "gofile.io", "anonfiles", "pixeldrain.com", "sendspace.com", "file.io", "transfer.sh", "catbox.moe", "workupload.com", "upload.ee"}
)

func runDNS() {
	section("Sites looked up recently  ·  DNS cache")
	names, err := dnsCache()
	if err != nil {
		row("WARN", "DNS cache", "couldn't read it", err.Error())
		return
	}
	seen := map[string]bool{}
	var hosts []string
	for _, n := range names {
		n = strings.ToLower(strings.TrimSuffix(strings.TrimSpace(n), "."))
		if n == "" || seen[n] {
			continue
		}
		seen[n] = true
		hosts = append(hosts, n)
	}
	sort.Strings(hosts)
	row("INFO", "Cached lookups", fmt.Sprintf("%d sites", len(hosts)), "clears on reboot, entries expire after minutes to hours")
	if len(hosts) < 15 {
		row("WARN", "DNS cache", "almost empty", "flushed recently? (ipconfig /flushdns)")
	}

	bad := 0
	for _, h := range hosts {
		matched := false
		for _, c := range cheatDomains {
			if h == c.domain || strings.HasSuffix(h, "."+c.domain) {
				row("FAIL", cut(h, 24), "cheat site · "+c.label, "")
				bad++
				matched = true
				break
			}
		}
		if matched {
			continue
		}
		if reCheatyHost.MatchString(h) {
			row("WARN", cut(h, 24), "cheat-sounding site", h)
			bad++
			continue
		}
		for _, f := range fileHosts {
			if strings.Contains(h, f) {
				row("WARN", cut(h, 24), "file sharing site", "cheats are often passed around on these")
				bad++
				break
			}
		}
	}
	if bad == 0 {
		row("OK", "Cheat / file sites", "none in the cache", "")
	}
	report.WriteString("   all cached sites:\r\n")
	for _, h := range hosts {
		report.WriteString("     " + h + "\r\n")
	}
}
