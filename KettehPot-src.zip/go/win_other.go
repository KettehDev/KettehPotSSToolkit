//go:build !windows

// Stand-ins so the toolkit builds and the parsers can be tested off Windows.
package main

import (
	"errors"
	"os"
	"path/filepath"
	"time"
)

var errNotWindows = errors.New("windows only")

func setupConsole(string) bool                             { return true }
func isAdmin() bool                                        { return true }
func currentUser() string                                  { return os.Getenv("USER") }
func bootTime() time.Time                                  { return time.Now().Add(-3 * time.Hour) }
func osInfo() (string, string)                             { return "not windows", "0" }
func regString(regRoot, string, string) (string, bool)     { return "", false }
func regDWORD(regRoot, string, string) (uint32, bool)      { return 0, false }
func regSubkeys(regRoot, string) ([]string, bool)          { return nil, false }
func regValues(regRoot, string) ([]regValue, bool)         { return nil, false }
func sidToName(string) string                              { return "" }
func driveRoot(letter string) string                       { return letter + "/" }
func driveLetters() []string                               { return nil }
func listDrives() []driveInfo                              { return nil }
func deviceMap() map[string]string                         { return map[string]string{} }
func volumeSerials() map[uint32]string                     { return map[uint32]string{} }
func queryService(string) (svcInfo, bool)                  { return svcInfo{}, false }
func processStart(uint32) (time.Time, bool)                { return time.Time{}, false }
func listProcesses() []procInfo                            { return nil }
func processImage(uint32) string                           { return "" }
func processCmdline(uint32) string                         { return "" }
func processModules(uint32) ([]string, bool)               { return nil, false }
func queryEvents(string, string, int) ([]winEvent, error)  { return nil, errNotWindows }
func queryEventsOldest(string) ([]winEvent, error)         { return nil, errNotWindows }
func lastEvent(string, int, string) (time.Time, int, bool) { return time.Time{}, 0, false }
func prefetchDir() string                                  { return filepath.Join(os.TempDir(), "Prefetch") }
func fileAttrs(os.FileInfo) (bool, bool, time.Time)        { return false, false, time.Time{} }
func readZoneIdentifier(string) string                     { return "" }
func decompressMAM(b []byte) ([]byte, error)               { return b, nil }
func usnWalk(string, func(usnRecord)) (usnJournal, error)  { return usnJournal{}, errNotWindows }
func resolveFileRef(string, uint64) string                 { return "" }

func desktopDir() string {
	home, _ := os.UserHomeDir()
	if d := filepath.Join(home, "Desktop"); isDir(d) {
		return d
	}
	wd, _ := os.Getwd()
	return wd
}

func enableDebugPrivilege() bool                              { return false }
func memWalk(uint32, int64, func([]byte) bool) (int64, error) { return 0, errNotWindows }
func regKeyTime(regRoot, string) (time.Time, bool)            { return time.Time{}, false }
func dnsCache() ([]string, error)                             { return nil, errNotWindows }
func openAppWindow(string) bool                               { return false }
func showConsole(bool)                                        {}
