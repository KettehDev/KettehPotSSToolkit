// Minecraft Instances: finds every launcher's instances, when each was last played,
// mods that were loaded last session but are gone now, and checks every jar on Modrinth.
package main

import (
	"archive/zip"
	"bufio"
	"bytes"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"os"
	"path/filepath"
	"regexp"
	"sort"
	"strconv"
	"strings"
	"sync"
	"time"
)

type mcInstance struct {
	launcher string
	name     string
	gameDir  string
	modsDir  string
	lastPlay time.Time // latest.log written
}

func homeDir() string {
	if h := os.Getenv("USERPROFILE"); h != "" {
		return h
	}
	h, _ := os.UserHomeDir()
	return h
}

func appData() string {
	if a := os.Getenv("APPDATA"); a != "" {
		return a
	}
	return filepath.Join(homeDir(), "AppData", "Roaming")
}

func subDirs(p string) []string {
	var out []string
	entries, _ := os.ReadDir(p)
	for _, e := range entries {
		if e.IsDir() {
			out = append(out, filepath.Join(p, e.Name()))
		}
	}
	return out
}

// findModsDirs walks a few levels down looking for folders named "mods" (Lunar / Feather layouts change a lot).
func findModsDirs(root string, depth int) []string {
	var out []string
	var walk func(p string, d int)
	walk = func(p string, d int) {
		for _, s := range subDirs(p) {
			n := strings.ToLower(filepath.Base(s))
			if n == "mods" || n == "user-mods" {
				out = append(out, s)
				continue
			}
			if d > 0 && n != "assets" && n != "libraries" && n != "jre" && n != "cache" && n != "logs" && n != "natives" {
				walk(s, d-1)
			}
		}
	}
	walk(root, depth)
	return out
}

func findInstances() []mcInstance {
	var out []mcInstance
	seen := map[string]bool{}
	add := func(launcher, name, game string) {
		if !isDir(game) || seen[strings.ToLower(game)] {
			return
		}
		seen[strings.ToLower(game)] = true
		in := mcInstance{launcher: launcher, name: name, gameDir: game}
		if m := filepath.Join(game, "mods"); isDir(m) {
			in.modsDir = m
		}
		if st, err := os.Stat(filepath.Join(game, "logs", "latest.log")); err == nil {
			in.lastPlay = st.ModTime()
		}
		out = append(out, in)
	}
	ad, home := appData(), homeDir()

	add("Vanilla / Official", ".minecraft", filepath.Join(ad, ".minecraft"))
	for _, base := range []string{filepath.Join(ad, "ModrinthApp", "profiles"), filepath.Join(ad, "com.modrinth.theseus", "profiles")} {
		for _, d := range subDirs(base) {
			add("Modrinth App", filepath.Base(d), d)
		}
	}
	for _, l := range []struct{ name, dir string }{
		{"Prism Launcher", filepath.Join(ad, "PrismLauncher", "instances")},
		{"PolyMC", filepath.Join(ad, "PolyMC", "instances")},
		{"MultiMC", filepath.Join(home, "MultiMC", "instances")},
		{"MultiMC", filepath.Join(home, "Desktop", "MultiMC", "instances")},
	} {
		for _, d := range subDirs(l.dir) {
			game := filepath.Join(d, "minecraft")
			if !isDir(game) {
				game = filepath.Join(d, ".minecraft")
			}
			add(l.name, filepath.Base(d), game)
		}
	}
	for _, d := range subDirs(filepath.Join(home, "curseforge", "minecraft", "Instances")) {
		add("CurseForge", filepath.Base(d), d)
	}
	for _, base := range []string{filepath.Join(ad, "gdlauncher_next", "instances"), filepath.Join(ad, "gdlauncher_carbon", "data", "instances")} {
		for _, d := range subDirs(base) {
			game := filepath.Join(d, "instance")
			if !isDir(game) {
				game = d
			}
			add("GDLauncher", filepath.Base(d), game)
		}
	}
	for _, d := range subDirs(filepath.Join(ad, "ATLauncher", "instances")) {
		add("ATLauncher", filepath.Base(d), d)
	}
	add("TLauncher", ".tlauncher", filepath.Join(ad, ".tlauncher", "legacy", "Minecraft", "game"))

	// Lunar + Feather keep mods in deeper per-version folders
	for _, l := range []struct{ name, dir string }{
		{"Lunar Client", filepath.Join(home, ".lunarclient")},
		{"Feather", filepath.Join(ad, ".feather")},
		{"Dawn", filepath.Join(ad, ".dawn")},
		{"Badlion", filepath.Join(ad, ".minecraft", "Badlion Client")},
	} {
		if !isDir(l.dir) {
			continue
		}
		for _, m := range findModsDirs(l.dir, 4) {
			if seen[strings.ToLower(m)] {
				continue
			}
			seen[strings.ToLower(m)] = true
			rel, _ := filepath.Rel(l.dir, filepath.Dir(m))
			in := mcInstance{launcher: l.name, name: rel, gameDir: filepath.Dir(m), modsDir: m}
			for _, lg := range []string{filepath.Join(l.dir, "logs", "latest.log"), filepath.Join(filepath.Dir(m), "logs", "latest.log")} {
				if st, err := os.Stat(lg); err == nil && st.ModTime().After(in.lastPlay) {
					in.lastPlay = st.ModTime()
				}
			}
			out = append(out, in)
		}
	}
	sort.SliceStable(out, func(i, j int) bool { return out[i].lastPlay.After(out[j].lastPlay) })
	return out
}

// ---------------------------------------------------------------- latest.log

var (
	reLoadingMods = regexp.MustCompile(`Loading \d+ mods:`)
	reModLine     = regexp.MustCompile(`^\s+- ([a-z0-9_.\-]+) (\S+)`)
	reNestedLine  = regexp.MustCompile(`^\s+(\|--|\\--)`)
	reMcVersion   = regexp.MustCompile(`(?i)Minecraft (?:version|server) ?:? ?(\d+\.\d+(?:\.\d+)?)|Loading Minecraft (\d+\.\d+(?:\.\d+)?)`)
	reUserLog     = regexp.MustCompile(`Setting user: (\w{1,16})`)
)

type logInfo struct {
	loaded  map[string]string // mod id -> version (top-level only)
	user    string
	mc      string
	loader  string
	hasList bool
}

var builtinIDs = map[string]bool{"minecraft": true, "java": true, "fabricloader": true, "mixinextras": true, "quilt_loader": true}

func readLatestLog(path string) (logInfo, bool) {
	f, err := os.Open(path)
	if err != nil {
		return logInfo{}, false
	}
	defer f.Close()
	li := logInfo{loaded: map[string]string{}}
	sc := bufio.NewScanner(io.LimitReader(f, 8<<20))
	sc.Buffer(make([]byte, 1<<20), 1<<20)
	inList := false
	lines := 0
	for sc.Scan() {
		l := sc.Text()
		lines++
		if li.user == "" {
			if m := reUserLog.FindStringSubmatch(l); m != nil {
				li.user = m[1]
			}
		}
		if li.mc == "" {
			if m := reMcVersion.FindStringSubmatch(l); m != nil {
				li.mc = m[1] + m[2]
			}
		}
		if li.loader == "" {
			switch {
			case strings.Contains(l, "Fabric Loader"):
				li.loader = "Fabric"
			case strings.Contains(l, "Quilt Loader"):
				li.loader = "Quilt"
			case strings.Contains(l, "ModLauncher") || strings.Contains(l, "neoforge"):
				li.loader = "Forge / NeoForge"
			}
		}
		if reLoadingMods.MatchString(l) {
			inList, li.hasList = true, true
			continue
		}
		if inList {
			if reNestedLine.MatchString(l) {
				continue
			}
			if m := reModLine.FindStringSubmatch(l); m != nil {
				if !builtinIDs[m[1]] {
					li.loaded[m[1]] = m[2]
				}
				continue
			}
			inList = false
		}
		if lines > 4000 && li.hasList && !inList {
			break // the mod list is near the top, no need to read the whole session
		}
	}
	return li, true
}

// ---------------------------------------------------------------- jars

type jarInfo struct {
	path, name string
	ids        []string // fabric / quilt / forge mod ids inside
	sha1       string
	modified   time.Time
	created    time.Time
	hidden     bool
	modrinth   string // project title if found
	onModrinth bool
}

var reTomlID = regexp.MustCompile(`(?m)^\s*modId\s*=\s*"([^"]+)"`)

func jarModIDs(path string) []string {
	zr, err := zip.OpenReader(path)
	if err != nil {
		return nil
	}
	defer zr.Close()
	var ids []string
	for _, f := range zr.File {
		switch f.Name {
		case "fabric.mod.json":
			var v struct {
				ID string `json:"id"`
			}
			if json.Unmarshal(readEntry(f, 1<<20), &v) == nil && v.ID != "" {
				ids = append(ids, v.ID)
			}
		case "quilt.mod.json":
			var v struct {
				QL struct {
					ID string `json:"id"`
				} `json:"quilt_loader"`
			}
			if json.Unmarshal(readEntry(f, 1<<20), &v) == nil && v.QL.ID != "" {
				ids = append(ids, v.QL.ID)
			}
		case "META-INF/mods.toml", "META-INF/neoforge.mods.toml":
			for _, m := range reTomlID.FindAllStringSubmatch(string(readEntry(f, 1<<20)), -1) {
				ids = append(ids, m[1])
			}
		}
	}
	return ids
}

func listJars(dir string) []*jarInfo {
	var out []*jarInfo
	entries, _ := os.ReadDir(dir)
	for _, e := range entries {
		n := strings.ToLower(e.Name())
		if e.IsDir() || !(strings.HasSuffix(n, ".jar") || strings.HasSuffix(n, ".jar.disabled")) {
			continue
		}
		p := filepath.Join(dir, e.Name())
		j := &jarInfo{path: p, name: e.Name()}
		if info, err := e.Info(); err == nil {
			j.modified = info.ModTime()
			j.hidden, _, j.created = fileAttrs(info)
		}
		j.ids = jarModIDs(p)
		out = append(out, j)
	}
	return out
}

var (
	modrinthMu      sync.Mutex
	modrinthProject = map[string]string{} // sha1 -> modrinth project id
)

// modrinthLookup checks many sha1 hashes at once. Returns hash -> project title ("" = not on modrinth).
func modrinthLookup(hashes []string) (map[string]string, bool) {
	found := map[string]string{}
	if len(hashes) == 0 {
		return found, true
	}
	body, _ := json.Marshal(map[string]any{"hashes": hashes, "algorithm": "sha1"})
	req, err := http.NewRequest("POST", "https://api.modrinth.com/v2/version_files", bytes.NewReader(body))
	if err != nil {
		return found, false
	}
	req.Header.Set("Content-Type", "application/json")
	req.Header.Set("User-Agent", "KettehPot/"+version+" (github.com/KettehDev)")
	resp, err := httpClient.Do(req)
	if err != nil {
		return found, false
	}
	defer resp.Body.Close()
	if resp.StatusCode != 200 {
		return found, false
	}
	var versions map[string]struct {
		ProjectID string `json:"project_id"`
	}
	if json.NewDecoder(resp.Body).Decode(&versions) != nil {
		return found, false
	}
	projIDs := map[string]bool{}
	modrinthMu.Lock()
	for h, v := range versions {
		found[h] = "on Modrinth"
		if v.ProjectID != "" {
			projIDs[v.ProjectID] = true
			modrinthProject[h] = v.ProjectID // for "Open on Modrinth" links
		}
	}
	modrinthMu.Unlock()
	// titles, in one request
	if len(projIDs) > 0 {
		var ids []string
		for id := range projIDs {
			ids = append(ids, strconv.Quote(id))
		}
		var projects []struct {
			ID    string `json:"id"`
			Title string `json:"title"`
		}
		if getJSON("https://api.modrinth.com/v2/projects?ids=["+strings.Join(ids, ",")+"]", &projects) {
			titles := map[string]string{}
			for _, p := range projects {
				titles[p.ID] = p.Title
			}
			for h, v := range versions {
				if t := titles[v.ProjectID]; t != "" {
					found[h] = t
				}
			}
		}
	}
	return found, true
}

// ---------------------------------------------------------------- picker for KettehLyzer

func pickModsFolder() string {
	var withMods []mcInstance
	for _, in := range findInstances() {
		if in.modsDir != "" {
			withMods = append(withMods, in)
		}
	}
	var opts []choice
	for _, in := range withMods {
		played := "never played"
		if !in.lastPlay.IsZero() {
			played = "played " + ago(in.lastPlay)
		}
		opts = append(opts, choice{in.launcher + " · " + in.name, fmt.Sprintf("%d jars · %s", len(listJarNames(in.modsDir)), played)})
	}
	for {
		n, path, ok := choose("Pick a mods folder", "or paste a mods folder path", opts, true)
		if !ok {
			return ""
		}
		if n >= 0 {
			return withMods[n].modsDir
		}
		if isDir(path) {
			abs, _ := filepath.Abs(path)
			return abs
		}
		if gui {
			emit(map[string]any{"type": "note", "text": "that folder doesn't exist", "color": "Red"})
		} else {
			colorPrint("   that folder doesn't exist", "DarkGray")
		}
	}
}

func listJarNames(dir string) []string {
	var out []string
	entries, _ := os.ReadDir(dir)
	for _, e := range entries {
		if !e.IsDir() && strings.HasSuffix(strings.ToLower(e.Name()), ".jar") {
			out = append(out, e.Name())
		}
	}
	return out
}

// ---------------------------------------------------------------- the tool

func runInstances() {
	insts := findInstances()
	section("Instances found")
	if len(insts) == 0 {
		row("WARN", "Instances", "none found", "no launcher folders on this account")
		return
	}
	for i, in := range insts {
		played := "never launched"
		if !in.lastPlay.IsZero() {
			played = "last played " + ts(in.lastPlay) + "  ·  " + ago(in.lastPlay)
		}
		mods := "no mods folder"
		if in.modsDir != "" {
			mods = fmt.Sprintf("%d jars", len(listJarNames(in.modsDir)))
		}
		level := "INFO"
		if i == 0 && !in.lastPlay.IsZero() {
			level = "OK"
		}
		row(level, cut(in.launcher, 24), cut(in.name, 30)+" · "+mods, played)
	}

	// deep look at anything played in the last 3 days (or just the newest one)
	var recent []mcInstance
	for i, in := range insts {
		if in.modsDir == "" && in.lastPlay.IsZero() {
			continue
		}
		if i == 0 || time.Since(in.lastPlay) < 72*time.Hour {
			recent = append(recent, in)
		}
	}

	var allJars []*jarInfo
	for _, in := range recent {
		section(cut(in.launcher+" · "+in.name, 50))
		row("INFO", "Folder", cut(in.gameDir, 60), "")

		var jars []*jarInfo
		if in.modsDir != "" {
			jars = listJars(in.modsDir)
			allJars = append(allJars, jars...)
			if st, err := os.Stat(in.modsDir); err == nil && !in.lastPlay.IsZero() && st.ModTime().After(in.lastPlay.Add(time.Minute)) {
				row("WARN", "Mods folder changed", "after the last launch", "folder modified "+ts(st.ModTime())+" · "+ago(st.ModTime()))
			}
		}

		li, ok := readLatestLog(filepath.Join(in.gameDir, "logs", "latest.log"))
		if !ok {
			row("INFO", "latest.log", "none", "")
		} else {
			info := strings.TrimSpace(li.loader + " " + li.mc)
			if info == "" {
				info = "read"
			}
			extra := ""
			if li.user != "" {
				noteAccount(li.user)
				extra = "account: " + li.user
			}
			row("INFO", "Last session", info, extra)
		}

		// mods that were loaded last session but no longer have a jar
		if ok && li.hasList && in.modsDir != "" {
			present := map[string]bool{}
			for _, j := range jars {
				for _, id := range j.ids {
					present[id] = true
				}
			}
			var gone []string
			for id, ver := range li.loaded {
				if !present[id] && !isNestedLibrary(id) {
					gone = append(gone, id+" "+ver)
				}
			}
			sort.Strings(gone)
			if len(gone) > 0 {
				row("FAIL", "Removed since launch", fmt.Sprintf("%d mod(s) loaded last session are gone", len(gone)), "")
				for i, g := range gone {
					if i == 12 {
						sub(fmt.Sprintf("... and %d more", len(gone)-12), "DarkGray")
						break
					}
					sub(g, "Red")
				}
			} else {
				row("OK", "Removed since launch", "none", fmt.Sprintf("%d mods were loaded", len(li.loaded)))
			}
			for id := range li.loaded {
				if fl := exeFlags(id); len(fl) > 0 {
					row(fl[0].level, "Loaded mod id", id, fl[0].label)
				}
			}
		}

		// per-jar notes
		for _, j := range jars {
			if j.hidden {
				row("FAIL", cut(j.name, 24), "hidden file", "")
			}
			if strings.HasSuffix(strings.ToLower(j.name), ".disabled") && time.Since(j.modified) < 24*time.Hour {
				row("WARN", cut(j.name, 24), "disabled recently", ago(j.modified))
			}
			if fl := exeFlags(j.name + " " + strings.Join(j.ids, " ")); len(fl) > 0 {
				row(fl[0].level, cut(j.name, 24), fl[0].label, strings.Join(j.ids, ", "))
			}
			if !in.lastPlay.IsZero() && j.created.After(in.lastPlay) {
				row("INFO", cut(j.name, 24), "added after the last launch", ago(j.created))
			}
		}
	}

	// ---------------- Modrinth check on every jar we looked at
	if len(allJars) == 0 {
		return
	}
	section("Modrinth check  ·  " + fmt.Sprint(len(allJars)) + " jars")
	outln("   hashing + asking modrinth...", "DarkGray")
	var hashes []string
	for _, j := range allJars {
		j.sha1 = fileSHA1(j.path)
		if j.sha1 != "" {
			hashes = append(hashes, j.sha1)
		}
	}
	found := map[string]string{}
	okAll := true
	for i := 0; i < len(hashes); i += 300 {
		end := i + 300
		if end > len(hashes) {
			end = len(hashes)
		}
		part, ok := modrinthLookup(hashes[i:end])
		okAll = okAll && ok
		for k, v := range part {
			found[k] = v
		}
	}
	if !okAll {
		row("WARN", "Modrinth", "couldn't reach it", "no internet? jar checks below are incomplete")
	}
	unknown := 0
	for _, j := range allJars {
		if t, ok := found[j.sha1]; ok {
			j.onModrinth, j.modrinth = true, t
			report.WriteString(fmt.Sprintf("   verified  %-48s %s\r\n", j.name, t))
			continue
		}
		unknown++
		if !okAll {
			continue // can't tell without modrinth
		}
		ids := strings.Join(j.ids, ", ")
		if ids == "" {
			ids = "no mod id inside"
		}
		row("WARN", cut(j.name, 24), "not on Modrinth", ids+"  ·  could be curseforge, or edited")
		sub(j.path, "DarkGray")
	}
	verified := len(allJars) - unknown
	if !okAll {
		return
	}
	row("INFO", "Verified on Modrinth", fmt.Sprintf("%d of %d", verified, len(allJars)), "unknown jars are worth a KettehLyzer scan [15]")
}

// libraries that show up as top-level entries in the loader list but ship inside other jars
func isNestedLibrary(id string) bool {
	return strings.HasPrefix(id, "fabric-") || strings.HasPrefix(id, "fabric_") || id == "fabric" || id == "fabric-api" ||
		strings.HasPrefix(id, "cloth") || strings.HasPrefix(id, "mixin") || strings.HasPrefix(id, "org_") ||
		strings.HasPrefix(id, "com_") || strings.HasPrefix(id, "io_") || strings.HasPrefix(id, "net_")
}
