// KettehLyzer (mods folder deep scan), now a toolkit tool
package main

import (
	"archive/zip"
	"bytes"
	"crypto/sha1"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"os"
	"path/filepath"
	"regexp"
	"runtime"
	"sort"
	"strings"
	"sync"
	"time"
)

const lyzerVersion = "2.3"

func klWrite(text, color string) { outln(text, color) }
func klStamp() string            { return time.Now().Format("15:04:05") }
func klInfo(t string)            { klWrite("["+klStamp()+"] "+t, "Gray") }
func klGood(t string)            { klWrite("["+klStamp()+"] "+t, "Green") }
func klWarn(t string)            { klWrite("["+klStamp()+"] "+t, "Yellow") }
func klBad(t string)             { klWrite("["+klStamp()+"] "+t, "Red") }

func klHeader(t string) {
	klWrite("", "Gray")
	klWrite("================================================================", "DarkCyan")
	klWrite(" "+t, "Cyan")
	klWrite("================================================================", "DarkCyan")
}

// ------------------------------------------------------------------ matching tables

var (
	cheatLower   []string
	patternLower []string
	patternRe    *regexp.Regexp
	identRe      = regexp.MustCompile(`[A-Za-z0-9_./$]{5,80}`)
	printableRe  = regexp.MustCompile(`[\x20-\x7E]{4,}`)
	deepExtRe    = regexp.MustCompile(`(?i)\.(class|json|toml|properties|cfg|txt|xml|mf|js|yml|yaml)$`)
	weirdNameRe  = regexp.MustCompile(`^[A-Za-z0-9_$]{1,3}$`)
	zoneSources  = []string{"MediaFire", "Discord", "Dropbox", "Google Drive", "MEGA", "GitHub", "Modrinth", "CurseForge"}
)

func init() {
	for _, s := range cheatStrings {
		cheatLower = append(cheatLower, strings.ToLower(s))
	}
	sorted := append([]string(nil), suspiciousPatterns...)
	sort.SliceStable(sorted, func(i, j int) bool { return len([]rune(sorted[i])) > len([]rune(sorted[j])) })
	quoted := make([]string, len(sorted))
	for i, s := range sorted {
		quoted[i] = regexp.QuoteMeta(s)
	}
	patternRe = regexp.MustCompile("(?i)" + strings.Join(quoted, "|"))
	for _, s := range suspiciousPatterns {
		patternLower = append(patternLower, strings.ToLower(s))
	}
}

// Fullwidth ASCII (U+FF01..U+FF5E) -> normal ASCII, NUL -> space.
func normalize(t string) string {
	return strings.Map(func(r rune) rune {
		if r == 0 {
			return ' '
		}
		if r >= 0xFF01 && r <= 0xFF5E {
			return r - 0xFEE0
		}
		return r
	}, t)
}

// Same as .NET Encoding.ASCII.GetString: bytes above 0x7F become '?'.
func asciiString(b []byte) string {
	out := make([]byte, len(b))
	for i, c := range b {
		if c > 0x7F {
			out[i] = '?'
		} else {
			out[i] = c
		}
	}
	return string(out)
}

func printableStrings(b []byte) []string {
	if len(b) == 0 {
		return nil
	}
	return printableRe.FindAllString(asciiString(b), -1)
}

func utf8Text(b []byte) string { return strings.ToValidUTF8(string(b), "�") }

// ------------------------------------------------------------------ ordered sets

type list struct {
	items []string
	seen  map[string]bool
}

func newList() *list { return &list{seen: map[string]bool{}} }

func (l *list) add(s string) {
	if !l.seen[s] {
		l.seen[s] = true
		l.items = append(l.items, s)
	}
}

// case-insensitive set (keeps first spelling seen)
type ciSet struct{ m map[string]string }

func newCISet() *ciSet { return &ciSet{m: map[string]string{}} }

func (c *ciSet) add(s string) {
	k := strings.ToLower(s)
	if _, ok := c.m[k]; !ok {
		c.m[k] = s
	}
}

func (c *ciSet) sorted(max int) []string {
	out := make([]string, 0, len(c.m))
	for _, v := range c.m {
		out = append(out, v)
	}
	sort.Slice(out, func(i, j int) bool {
		a, b := strings.ToLower(out[i]), strings.ToLower(out[j])
		if a == b {
			return out[i] < out[j]
		}
		return a < b
	})
	if max > 0 && len(out) > max {
		out = out[:max]
	}
	return out
}

// counts how many files each "note" appeared in
type notes struct {
	order []string
	files map[string][]string
}

func newNotes() *notes { return &notes{files: map[string][]string{}} }

func (n *notes) add(label, file string) {
	if _, ok := n.files[label]; !ok {
		n.order = append(n.order, label)
	}
	for _, f := range n.files[label] {
		if f == file {
			return
		}
	}
	n.files[label] = append(n.files[label], file)
}

func (n *notes) summary() string {
	parts := make([]string, 0, len(n.order))
	for _, l := range n.order {
		parts = append(parts, fmt.Sprintf("%s ×%d", l, len(n.files[l])))
	}
	return strings.Join(parts, ", ")
}

// ------------------------------------------------------------------ zip helpers

func readEntry(f *zip.File, max int64) []byte {
	rc, err := f.Open()
	if err != nil {
		return nil
	}
	defer rc.Close()
	b, _ := io.ReadAll(io.LimitReader(rc, max))
	return b
}

// ------------------------------------------------------------------ result

type result struct {
	Name, Path, SHA1, Status, Source, VerifiedAs, ScanError string
	Signatures, CheatStrings, AllStrings, HitFiles          []string
	Bypass, Obfuscation                                     []string
	BypassNotes, ObfNotes                                   *notes
}

func newResult(path string) *result {
	return &result{Name: filepath.Base(path), Path: path, Status: "UNKNOWN", Source: "Unknown",
		BypassNotes: newNotes(), ObfNotes: newNotes()}
}

// ------------------------------------------------------------------ pass 2: signatures

type sigScan struct {
	pats, strs, files *list
	all               *ciSet
}

func (s *sigScan) matchBlob(text, entry string) {
	if text == "" {
		return
	}
	n := normalize(text)
	low := strings.ToLower(n)
	for i, c := range cheatStrings {
		if strings.Contains(low, cheatLower[i]) {
			s.strs.add(c)
			if entry != "" {
				s.files.add(entry)
			}
		}
	}
	// same words as patternRe, but a plain search: the case-insensitive regex was ~40x slower
	for i, p := range patternLower {
		if strings.Contains(low, p) {
			s.pats.add(suspiciousPatterns[i])
			if entry != "" {
				s.files.add(entry)
			}
		}
	}
}

func (s *sigScan) matchName(name, label string) {
	low := strings.ToLower(name)
	for i, c := range cheatStrings {
		if strings.Contains(low, cheatLower[i]) {
			s.strs.add(c)
			s.files.add(label)
		}
	}
	for i, p := range suspiciousPatterns {
		if strings.Contains(low, patternLower[i]) {
			s.pats.add(p)
			s.files.add(label)
		}
	}
}

func scanSigs(r *result, zr *zip.Reader) {
	s := &sigScan{pats: newList(), strs: newList(), files: newList(), all: newCISet()}

	// the jar's own filename (renamed ghost clients)
	jarName := strings.TrimSuffix(r.Name, filepath.Ext(r.Name))
	s.all.add(jarName)
	s.all.add(r.Name)
	s.matchName(jarName, "[JAR NAME] "+jarName)

	for _, f := range zr.File {
		name := f.Name
		if name == "" || strings.HasSuffix(name, "/") {
			continue
		}
		low := strings.ToLower(name)
		s.all.add(name)
		s.matchName(name, name)

		// nested jars, scanned in memory
		if strings.HasSuffix(low, ".jar") {
			if f.UncompressedSize64 <= 20<<20 {
				if nb := readEntry(f, 20<<20); len(nb) > 0 {
					if nz, err := zip.NewReader(bytes.NewReader(nb), int64(len(nb))); err == nil {
						for _, nf := range nz.File {
							if nf.Name == "" || strings.HasSuffix(nf.Name, "/") {
								continue
							}
							nName := name + "!" + nf.Name
							s.all.add(nName)
							bb := readEntry(nf, 2<<20)
							if len(bb) == 0 {
								continue
							}
							dumped := printableStrings(bb)
							for _, raw := range dumped {
								if len(raw) >= 5 && len(raw) <= 100 {
									s.all.add(raw)
								}
							}
							if len(dumped) > 500 {
								dumped = dumped[:500]
							}
							s.matchBlob(strings.Join(dumped, "\n"), nName)
						}
					}
				}
			}
			continue
		}

		if !deepExtRe.MatchString(low) {
			continue
		}
		b := readEntry(f, 2<<20)
		if len(b) == 0 {
			continue
		}
		dumped := printableStrings(b)
		for _, raw := range dumped {
			if len(raw) >= 5 && len(raw) <= 100 {
				s.all.add(raw)
			}
		}
		if len(dumped) > 800 {
			dumped = dumped[:800]
		}
		s.matchBlob(strings.Join(dumped, "\n"), name)
		// full-width letters (ＡｕｔｏＣｒｙｓｔａｌ) aren't plain ascii, so look at the utf-8 text only when they're there
		if bytes.Contains(b, []byte{0xEF, 0xBC}) || bytes.Contains(b, []byte{0xEF, 0xBD}) {
			s.matchBlob(utf8Text(b), name)
		}
	}

	r.Signatures = s.pats.items
	r.CheatStrings = s.strs.items
	r.HitFiles = s.files.items
	r.AllStrings = s.all.sorted(1500)
}

// ------------------------------------------------------------------ pass 3: bypass / injection

var bypassNameChecks = []string{
	"javaagent", "agentmain", "premain", "instrumentation", "nativehook", "injector",
	"injection", "dll", "jnidispatch", "loadlibrary", "createremotethread", "virtualalloc",
}

type check struct {
	re     *regexp.Regexp
	label  string
	strong bool // strong = changes the mod's status; weak = listed as a note only
}

var bypassChecks = []check{
	{regexp.MustCompile(`(?i)javaagent`), "javaagent", true},
	{regexp.MustCompile(`(?i)\bInstrumentation\b`), "Instrumentation", true},
	{regexp.MustCompile(`(?i)\bAgentBuilder\b`), "AgentBuilder", true},
	{regexp.MustCompile(`(?i)\bClassFileTransformer\b`), "ClassFileTransformer", true},
	{regexp.MustCompile(`(?i)\bVirtualAlloc\b`), "VirtualAlloc", true},
	{regexp.MustCompile(`(?i)\bCreateRemoteThread\b`), "CreateRemoteThread", true},
	{regexp.MustCompile(`(?i)\bSetWindowsHookEx\b`), "SetWindowsHookEx", true},
	{regexp.MustCompile(`(?i)\bLoadLibrary(?:A|W)?\b`), "LoadLibrary", true},
	{regexp.MustCompile(`(?i)defineClass`), "defineClass", true},
	{regexp.MustCompile(`(?i)discord(?:app)?\.com/api/webhooks`), "Discord Webhook", true},
	// very common in normal mods, so these are notes only
	{regexp.MustCompile(`(?i)\bJNI\b`), "JNI", false},
	{regexp.MustCompile(`(?i)\bJNA\b`), "JNA", false},
	{regexp.MustCompile(`(?i)Runtime\.getRuntime\(\)\.exec`), "Runtime.exec", false},
	{regexp.MustCompile(`(?i)ProcessBuilder`), "ProcessBuilder", false},
	{regexp.MustCompile(`(?i)URLClassLoader`), "URLClassLoader", false},
	{regexp.MustCompile(`(?i)ClassLoader`), "ClassLoader", false},
	{regexp.MustCompile(`(?i)https?://`), "HTTP URL", false},
	{regexp.MustCompile(`(?i)URLConnection`), "URLConnection", false},
	{regexp.MustCompile(`(?i)HttpClient`), "HttpClient", false},
	{regexp.MustCompile(`(?i)HttpURLConnection`), "HttpURLConnection", false},
	{regexp.MustCompile(`(?i)\bPOST\b`), "HTTP POST", false},
	{regexp.MustCompile(`(?i)webhook`), "Webhook", false},
}

func scanBypass(r *result, zr *zip.Reader) {
	hits := newList()
	for _, f := range zr.File {
		name := f.Name
		if strings.HasSuffix(name, "/") {
			continue
		}
		low := strings.ToLower(name)
		for _, needle := range bypassNameChecks {
			if strings.Contains(low, needle) {
				hits.add("Entry: " + name + " -> " + needle)
			}
		}
		if !(strings.HasSuffix(low, ".class") || strings.HasSuffix(low, ".json") ||
			strings.HasSuffix(low, ".mf") || strings.HasSuffix(low, ".txt")) {
			continue
		}
		b := readEntry(f, 5<<20)
		if len(b) == 0 {
			continue
		}
		n := normalize(utf8Text(b))
		lowN := strings.ToLower(n)
		for _, c := range bypassChecks {
			// cheap keyword test first, the regex only confirms word boundaries
			if strings.Contains(lowN, checkKeyword(c.label)) && c.re.MatchString(n) {
				if c.strong {
					hits.add(c.label + " in " + name)
				} else {
					r.BypassNotes.add(c.label, name)
				}
			}
		}
	}
	r.Bypass = hits.items
}

// ------------------------------------------------------------------ pass 4: obfuscation

var obfChecks = []check{
	{regexp.MustCompile(`(?i)invokedynamic`), "invokedynamic", false},
	{regexp.MustCompile(`(?i)java/lang/reflect`), "reflection", false},
	{regexp.MustCompile(`(?i)defineClass`), "dynamic class definition", false},
	{regexp.MustCompile(`(?i)Base64`), "Base64", false},
	{regexp.MustCompile(`(?i)Cipher`), "Cipher", false},
	{regexp.MustCompile(`(?i)MessageDigest`), "MessageDigest", false},
}

func scanObf(r *result, zr *zip.Reader) {
	hits := newList()
	classCount, shortCount, weirdCount := 0, 0, 0
	for _, f := range zr.File {
		if !strings.HasSuffix(strings.ToLower(f.Name), ".class") {
			continue
		}
		classCount++
		base := filepath.Base(f.Name)
		base = strings.TrimSuffix(base, filepath.Ext(base))
		if len([]rune(base)) <= 2 {
			shortCount++
		}
		if weirdNameRe.MatchString(base) {
			weirdCount++
		}
	}
	if classCount > 20 {
		ratio := float64(shortCount) / float64(classCount)
		if ratio >= 0.35 {
			hits.add(fmt.Sprintf("High short-class-name ratio: %.0f%% (%d/%d)", ratio*100, shortCount, classCount))
		}
	}
	if weirdCount >= 20 {
		hits.add(fmt.Sprintf("Many unusually short/opaque class names: %d", weirdCount))
	}
	for _, f := range zr.File {
		if !strings.HasSuffix(strings.ToLower(f.Name), ".class") {
			continue
		}
		b := readEntry(f, 2<<20)
		if len(b) == 0 {
			continue
		}
		a := asciiString(b)
		lowA := strings.ToLower(a)
		for _, c := range obfChecks {
			if strings.Contains(lowA, checkKeyword(c.label)) && c.re.MatchString(a) {
				r.ObfNotes.add(c.label, f.Name)
			}
		}
	}
	r.Obfuscation = hits.items
}

// ------------------------------------------------------------------ hashing / sources

func fileSHA1(path string) string {
	f, err := os.Open(path)
	if err != nil {
		return ""
	}
	defer f.Close()
	h := sha1.New()
	if _, err := io.Copy(h, f); err != nil {
		return ""
	}
	return hex.EncodeToString(h.Sum(nil))
}

func downloadSource(path string) string {
	zone := readZoneIdentifier(path)
	if zone == "" {
		return "Unknown"
	}
	low := strings.ToLower(zone)
	for _, s := range zoneSources {
		if strings.Contains(low, strings.ToLower(s)) {
			return s
		}
	}
	return "Unknown"
}

var httpClient = &http.Client{Timeout: 10 * time.Second}

func getJSON(url string, into any) bool {
	req, err := http.NewRequest("GET", url, nil)
	if err != nil {
		return false
	}
	req.Header.Set("User-Agent", "KettehPot/"+version+" (github.com/KettehDev)")
	resp, err := httpClient.Do(req)
	if err != nil {
		return false
	}
	defer resp.Body.Close()
	if resp.StatusCode != 200 {
		return false
	}
	return json.NewDecoder(resp.Body).Decode(into) == nil
}

func modrinth(hash string) (bool, string) {
	var v struct {
		ProjectID string `json:"project_id"`
	}
	if !getJSON("https://api.modrinth.com/v2/version_file/"+hash, &v) {
		return false, ""
	}
	if v.ProjectID != "" {
		var p struct {
			Title string `json:"title"`
		}
		if getJSON("https://api.modrinth.com/v2/project/"+v.ProjectID, &p) && p.Title != "" {
			return true, p.Title
		}
	}
	return true, "Verified Modrinth file"
}

// ------------------------------------------------------------------ report printing

func printFindings(r *result) {
	if len(r.Signatures) > 0 {
		klWrite("    Suspicious signatures:", "Yellow")
		for _, h := range r.Signatures {
			klWrite("      • "+h, "Yellow")
		}
	}
	if len(r.CheatStrings) > 0 {
		klWrite("    Cheat strings detected:", "Red")
		for _, h := range r.CheatStrings {
			klWrite("      • "+h, "Red")
		}
	}
	if len(r.Bypass) > 0 {
		klWrite("    Bypass / injection indicators:", "Magenta")
		for _, h := range r.Bypass {
			klWrite("      • "+h, "Magenta")
		}
	}
	if len(r.Obfuscation) > 0 {
		klWrite("    Obfuscation indicators:", "DarkYellow")
		for _, h := range r.Obfuscation {
			klWrite("      • "+h, "DarkYellow")
		}
	}
	if len(r.HitFiles) > 0 {
		klWrite("    Matching archive entries:", "DarkGray")
		for i, h := range r.HitFiles {
			if i == 30 {
				klWrite(fmt.Sprintf("      • ... and %d more", len(r.HitFiles)-30), "DarkGray")
				break
			}
			klWrite("      • "+h, "DarkGray")
		}
	}
}

func printNotes(r *result) {
	if len(r.BypassNotes.order) > 0 {
		klWrite("    Notes (common in normal mods): "+r.BypassNotes.summary(), "DarkGray")
	}
	if len(r.ObfNotes.order) > 0 {
		klWrite("    Code notes: "+r.ObfNotes.summary(), "DarkGray")
	}
}

func statusColor(s string) string {
	switch s {
	case "VERIFIED":
		return "Green"
	case "FLAGGED":
		return "Red"
	case "BYPASS":
		return "Magenta"
	case "OBFUSCATED":
		return "DarkYellow"
	}
	return "Yellow"
}

// ------------------------------------------------------------------ main

func runLyzer() {
	modsPath := pickModsFolder()
	if modsPath == "" {
		toolCancelled = true
		return
	}
	scanModsFolder(modsPath)
}

func scanModsFolder(modsPath string) {
	klWrite("", "Gray")
	klInfo("Mods path: " + modsPath)

	entries, _ := os.ReadDir(modsPath)
	var results []*result
	for _, e := range entries {
		if !e.IsDir() && strings.HasSuffix(strings.ToLower(e.Name()), ".jar") {
			results = append(results, newResult(filepath.Join(modsPath, e.Name())))
		}
	}
	sort.Slice(results, func(i, j int) bool { return strings.ToLower(results[i].Name) < strings.ToLower(results[j].Name) })

	klWrite("", "Gray")
	klInfo(fmt.Sprintf("Found %d JAR(s) in %s", len(results), modsPath))
	if len(results) == 0 {
		klWarn("No JAR files were found.")
		if gui {
			emit(map[string]any{"type": "lyzer_empty", "path": modsPath})
		}
		return
	}
	scanStarted := time.Now()
	lyzerBegin(modsPath, results)

	// ---------------- PASS 1
	klHeader("PASS 1 — HASH VERIFICATION")
	var hashes []string
	for i, r := range results {
		klInfo(fmt.Sprintf("[%d/%d] Hashing %s", i+1, len(results), r.Name))
		r.SHA1 = fileSHA1(r.Path)
		lyzerTick(1, i+1, len(results), r.Name)
		if r.SHA1 == "" {
			r.ScanError = "Could not calculate SHA-1"
			klWarn("  SHA-1 failed")
			continue
		}
		hashes = append(hashes, r.SHA1)
	}
	// one request for every jar instead of two per jar
	klInfo("Checking all hashes on Modrinth...")
	found := map[string]string{}
	reached := true
	for i := 0; i < len(hashes); i += 300 {
		end := i + 300
		if end > len(hashes) {
			end = len(hashes)
		}
		part, ok := modrinthLookup(hashes[i:end])
		reached = reached && ok
		for k, v := range part {
			found[k] = v
		}
	}
	if !reached {
		klWarn("  Couldn't reach Modrinth, every jar counts as unknown")
	}
	for _, r := range results {
		if r.SHA1 == "" {
			continue
		}
		if name, ok := found[r.SHA1]; ok {
			r.Status, r.Source, r.VerifiedAs = "VERIFIED", "Modrinth", name
			klGood("  VERIFIED: " + r.Name + " -> " + name)
			continue
		}
		r.Source = downloadSource(r.Path)
		klWarn("  UNKNOWN: " + r.Name)
	}
	lyzerStatuses(1, results)
	verified := 0
	for _, r := range results {
		if r.Status == "VERIFIED" {
			verified++
		}
	}
	klWrite("", "Gray")
	klInfo(fmt.Sprintf("Verified (hash): %d  |  Deep-scanning ALL: %d", verified, len(results)))

	// open every jar once for the remaining passes
	readers := make([]*zip.ReadCloser, len(results))
	for i, r := range results {
		zr, err := zip.OpenReader(r.Path)
		if err != nil {
			r.ScanError = "Not a readable JAR/ZIP: " + err.Error()
			continue
		}
		readers[i] = zr
	}
	defer func() {
		for _, z := range readers {
			if z != nil {
				z.Close()
			}
		}
	}()

	// ---------------- PASS 2
	klHeader("PASS 2 — CHEAT-SIGNATURE SCAN")
	parallelEachTick(2, results, func(i int) {
		if readers[i] != nil {
			scanSigs(results[i], &readers[i].Reader)
		}
	})
	for i, r := range results {
		if readers[i] == nil {
			klWarn("  Signature scan error: " + r.Name)
			continue
		}
		if len(r.Signatures) > 0 || len(r.CheatStrings) > 0 {
			r.Status = "FLAGGED"
			klBad("  FLAGGED: " + r.Name)
			if r.Source == "Modrinth" {
				klWarn("  (was hash-verified via Modrinth — hash match ignored due to cheat strings)")
			}
			printFindings(r)
		} else {
			klGood("  Clean signature pass: " + r.Name)
		}
	}
	lyzerStatuses(2, results)
	flagged := 0
	for _, r := range results {
		if r.Status == "FLAGGED" {
			flagged++
		}
	}
	klWrite("", "Gray")
	klInfo(fmt.Sprintf("Flagged: %d", flagged))

	// ---------------- PASS 3
	klHeader("PASS 3 — BYPASS / INJECTION SCAN")
	parallelEachTick(3, results, func(i int) {
		if readers[i] != nil {
			scanBypass(results[i], &readers[i].Reader)
		}
	})
	for i, r := range results {
		if readers[i] == nil {
			klWarn("  Bypass scan error: " + r.Name)
			continue
		}
		if len(r.Bypass) > 0 {
			if r.Status != "FLAGGED" {
				r.Status = "BYPASS"
			}
			klWarn("  Bypass / injection indicators: " + r.Name)
			for _, h := range r.Bypass {
				klWrite("    • "+h, "Magenta")
			}
		} else {
			klGood("  Bypass clean: " + r.Name)
		}
	}
	lyzerStatuses(3, results)
	bypassCount := 0
	for _, r := range results {
		if len(r.Bypass) > 0 {
			bypassCount++
		}
	}
	klWrite("", "Gray")
	klInfo(fmt.Sprintf("Bypass flagged: %d", bypassCount))

	// ---------------- PASS 4
	klHeader("PASS 4 — OBFUSCATION SCAN")
	parallelEachTick(4, results, func(i int) {
		if readers[i] != nil {
			scanObf(results[i], &readers[i].Reader)
		}
	})
	for i, r := range results {
		if readers[i] == nil {
			klWarn("  Obfuscation scan error: " + r.Name)
			continue
		}
		if len(r.Obfuscation) > 0 {
			if r.Status == "UNKNOWN" || r.Status == "VERIFIED" {
				r.Status = "OBFUSCATED"
			}
			klWarn("  Obfuscation indicators: " + r.Name)
			for _, h := range r.Obfuscation {
				klWrite("    • "+h, "DarkYellow")
			}
		} else {
			klGood("  Obfuscation clean: " + r.Name)
		}
	}

	lyzerStatuses(4, results)
	lyzerPublish(modsPath, results, scanStarted)

	// ---------------- FINAL REPORT
	klHeader("FINAL REPORT")
	count := func(st string) int {
		n := 0
		for _, r := range results {
			if r.Status == st {
				n++
			}
		}
		return n
	}
	klWrite("", "Gray")
	for _, r := range results {
		klWrite("["+r.Status+"] "+r.Name, statusColor(r.Status))
		if r.SHA1 != "" {
			klWrite("  SHA-1 : "+r.SHA1, "DarkGray")
		}
		if r.Source != "" && r.Source != "Unknown" {
			klWrite("  Source: "+r.Source, "DarkGray")
		}
		if r.VerifiedAs != "" {
			klWrite("  Match : "+r.VerifiedAs, "DarkGray")
		}
		if r.Status == "FLAGGED" || len(r.Signatures) > 0 || len(r.CheatStrings) > 0 ||
			len(r.Bypass) > 0 || len(r.Obfuscation) > 0 {
			printFindings(r)
		}
		printNotes(r)
		if r.ScanError != "" {
			klWrite("  Scan error: "+r.ScanError, "Yellow")
		}
		klWrite("", "Gray")
	}

	klHeader("SCAN SUMMARY")
	klWrite(fmt.Sprintf(" Total JARs       : %d", len(results)), "White")
	klWrite(fmt.Sprintf(" Verified         : %d", count("VERIFIED")), "Green")
	klWrite(fmt.Sprintf(" Flagged          : %d", count("FLAGGED")), "Red")
	klWrite(fmt.Sprintf(" Bypass detected  : %d", bypassCount), "Magenta")
	klWrite(fmt.Sprintf(" Obfuscated       : %d", count("OBFUSCATED")), "DarkYellow")
	klWrite(fmt.Sprintf(" Unknown          : %d", count("UNKNOWN")), "Yellow")

	lyzerFindings(results)

	allCheat, allSig := newList(), newList()
	for _, r := range results {
		for _, s := range r.CheatStrings {
			allCheat.add(s)
		}
		for _, s := range r.Signatures {
			allSig.add(s)
		}
	}
	klWrite("", "Gray")
	klWrite(fmt.Sprintf(" Unique cheat strings detected : %d", len(allCheat.items)), "White")
	klWrite(fmt.Sprintf(" Unique signatures detected    : %d", len(allSig.items)), "White")

	if count("FLAGGED") > 0 {
		klWrite("", "Gray")
		klBad("FLAGGED MOD DETAILS")
		for _, r := range results {
			if r.Status != "FLAGGED" {
				continue
			}
			klWrite("", "Gray")
			klWrite(" >>> "+r.Name, "Red")
			if len(r.CheatStrings) > 0 {
				klWrite("     Cheat strings:", "Yellow")
				for _, s := range r.CheatStrings {
					klWrite("       • "+s, "Yellow")
				}
			}
			if len(r.Signatures) > 0 {
				klWrite("     Signatures:", "Yellow")
				for _, s := range r.Signatures {
					klWrite("       • "+s, "Yellow")
				}
			}
		}
	}

	// ---------------- optional export
	klWrite("", "Gray")
	if gui {
		klInfo("Full results + every string are on the KettehLyzer dashboard in your browser.")
	} else if askYesNo("   upload all mod strings to a .txt? (y/n)") {
		exportReport(results, modsPath, allCheat.items, allSig.items)
	} else {
		klInfo("Skipped string export.")
	}

	klWrite("", "Gray")
	klWrite(" Scan complete.", "Cyan")
}

func sortedCopy(xs []string) []string {
	out := append([]string(nil), xs...)
	sort.Slice(out, func(i, j int) bool { return strings.ToLower(out[i]) < strings.ToLower(out[j]) })
	return out
}

func exportReport(results []*result, modsPath string, cheat, sigs []string) {
	var b strings.Builder
	line := func(s string) { b.WriteString(s + "\r\n") }
	bar := strings.Repeat("=", 70)

	line("KETTEHLYZER v" + lyzerVersion + " — Full String Export")
	line("Generated : " + time.Now().Format("2006-01-02 15:04:05"))
	line("Mods path : " + modsPath)
	line(fmt.Sprintf("Total JARs: %d", len(results)))
	line("")
	line(bar)
	line("")
	section := func(title string, items []string) {
		line(title)
		line(strings.Repeat("-", 40))
		if len(items) == 0 {
			line("  (none)")
		}
		for _, s := range sortedCopy(items) {
			line("  • " + s)
		}
		line("")
	}
	section("UNIQUE CHEAT STRINGS (all mods combined)", cheat)
	section("UNIQUE SIGNATURES (all mods combined)", sigs)
	line(bar)
	line("")
	line("PER-MOD BREAKDOWN")
	line("")

	for _, r := range results {
		line(bar)
		line("MOD      : " + r.Name)
		line("Status   : " + r.Status)
		if r.SHA1 != "" {
			line("SHA-1    : " + r.SHA1)
		}
		if r.Source != "" && r.Source != "Unknown" {
			line("Source   : " + r.Source)
		}
		if r.VerifiedAs != "" {
			line("Match    : " + r.VerifiedAs)
		}
		line("")
		group := func(title string, items []string) {
			if len(items) == 0 {
				return
			}
			line("  " + title + ":")
			for _, s := range sortedCopy(items) {
				line("    • " + s)
			}
			line("")
		}
		group("Cheat strings", r.CheatStrings)
		group("Suspicious signatures", r.Signatures)
		group("Bypass / injection indicators", r.Bypass)
		group("Obfuscation indicators", r.Obfuscation)
		group("Matching archive entries", r.HitFiles)
		noteGroup := func(title string, n *notes) {
			if len(n.order) == 0 {
				return
			}
			line("  " + title + ":")
			for _, l := range n.order {
				line(fmt.Sprintf("    • %s (%d files)", l, len(n.files[l])))
				for _, f := range n.files[l] {
					line("        " + f)
				}
			}
			line("")
		}
		noteGroup("Notes (common in normal mods)", r.BypassNotes)
		noteGroup("Code notes", r.ObfNotes)
		if len(r.AllStrings) > 0 {
			line(fmt.Sprintf("  ALL EXTRACTED STRINGS FROM THIS MOD (%d):", len(r.AllStrings)))
			for _, s := range r.AllStrings {
				line("    " + s)
			}
			line("")
		}
		if r.ScanError != "" {
			line("  Scan error: " + r.ScanError)
			line("")
		}
	}
	line(bar)
	line("End of report.")

	dir := outputDir()
	path := filepath.Join(dir, "KettehLyzer_Strings_"+time.Now().Format("2006-01-02_15-04-05")+".txt")
	if err := writeText(path, b.String()); err != nil {
		klBad("Failed to write report: " + err.Error())
		return
	}
	klGood("Exported all mod strings to:")
	klWrite("  "+path, "Cyan")
	if openInNotepad(path) {
		klInfo("Opened the report in Notepad.")
	} else {
		klWarn("Could not open Notepad automatically. File is saved at the path above.")
	}
}

// lyzerFindings turns the scan into toolkit flags (summary + staff discord).
func lyzerFindings(results []*result) {
	for _, r := range results {
		verified := r.Source == "Modrinth"
		var hits []string
		seen := map[string]bool{}
		for _, h := range append(append([]string{}, r.CheatStrings...), r.Signatures...) {
			k := strings.ToLower(normalize(h))
			if !seen[k] {
				seen[k] = true
				hits = append(hits, h)
			}
		}
		if len(hits) > 3 {
			hits = append(hits[:3], fmt.Sprintf("+%d", len(hits)-3))
		}
		switch {
		case len(r.CheatStrings) > 0 && !verified:
			flag("FAIL", r.Name+" · cheat strings: "+strings.Join(hits, ", "))
		case len(r.CheatStrings) > 0:
			flag("WARN", r.Name+" · cheat strings but verified on Modrinth ("+r.VerifiedAs+"): "+strings.Join(hits, ", "))
		case len(r.Signatures) > 0 && !verified:
			flag("WARN", r.Name+" · suspicious words: "+strings.Join(hits, ", "))
		}
		if len(r.Bypass) > 0 && !verified {
			b := r.Bypass
			if len(b) > 2 {
				b = append(b[:2:2], fmt.Sprintf("+%d", len(r.Bypass)-2))
			}
			flag("WARN", r.Name+" · bypass / injection: "+strings.Join(b, ", "))
		}
		if len(r.Obfuscation) > 0 && !verified {
			flag("WARN", r.Name+" · obfuscated")
		}
	}
}

// parallelEach runs fn(0..n-1) on every CPU core.
func parallelEach(n int, fn func(int)) {
	workers := runtime.NumCPU()
	if workers > n {
		workers = n
	}
	next := make(chan int)
	var wg sync.WaitGroup
	for w := 0; w < workers; w++ {
		wg.Add(1)
		go func() {
			defer wg.Done()
			for i := range next {
				func() {
					defer func() { recover() }()
					fn(i)
				}()
			}
		}()
	}
	for i := 0; i < n; i++ {
		next <- i
	}
	close(next)
	wg.Wait()
}

// checkKeyword is a lowercase word every match of that check must contain.
func checkKeyword(label string) string {
	switch label {
	case "Discord Webhook":
		return "/api/webhooks"
	case "HTTP URL":
		return "http"
	case "HTTP POST":
		return "post"
	case "Runtime.exec":
		return "getruntime"
	case "reflection":
		return "java/lang/reflect"
	case "dynamic class definition":
		return "defineclass"
	}
	return strings.ToLower(label)
}
