//go:build windows

package main

import (
	"errors"
	"syscall"
	"unsafe"
)

var procDnsGetCacheDataTable = syscall.NewLazyDLL("dnsapi.dll").NewProc("DnsGetCacheDataTable")

type dnsCacheEntry struct {
	Next  *dnsCacheEntry
	Name  *uint16
	Type  uint16
	Len   uint16
	Flags uint32
}

// dnsCache lists the host names in Windows' DNS cache (what the PC looked up recently).
func dnsCache() ([]string, error) {
	if procDnsGetCacheDataTable.Find() != nil {
		return nil, errors.New("dnsapi missing")
	}
	var first *dnsCacheEntry
	r, _, _ := procDnsGetCacheDataTable.Call(uintptr(unsafe.Pointer(&first)))
	if r == 0 {
		return nil, errors.New("couldn't read the dns cache")
	}
	var out []string
	for e, n := first, 0; e != nil && n < 20000; e, n = e.Next, n+1 {
		if e.Name == nil {
			continue
		}
		l := 0
		for *(*uint16)(unsafe.Add(unsafe.Pointer(e.Name), l*2)) != 0 && l < 512 {
			l++
		}
		out = append(out, syscall.UTF16ToString(unsafe.Slice(e.Name, l)))
	}
	return out, nil
}
