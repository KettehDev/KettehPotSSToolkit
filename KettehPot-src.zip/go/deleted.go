// Deleted Files: the NTFS change journal (USN) remembers deletes and renames,
// even after the recycle bin is emptied.
package main

import (
	"encoding/binary"
	"fmt"
	"path/filepath"
	"regexp"
	"sort"
	"strings"
	"time"
	"unicode/utf16"
)

const (
	usnCreate  = 0x00000100
	usnDelete  = 0x00000200
	usnRenOld  = 0x00001000
	usnRenNew  = 0x00002000
	usnClose   = 0x80000000
	usnDataOvr = 0x00000001
)

type usnRecord struct {
	FileRef, ParentRef uint64
	Usn                int64
	Time               time.Time
	Reason             uint32
	Attrs              uint32
	Name               string
}

// parseUSNRecords walks USN_RECORD_V2 entries in a buffer.
func parseUSNRecords(b []byte, fn func(usnRecord)) {
	for off := 0; off+60 <= len(b); {
		recLen := int(binary.LittleEndian.Uint32(b[off:]))
		if recLen < 60 || off+recLen > len(b) {
			return
		}
		major := binary.LittleEndian.Uint16(b[off+4:])
		if major == 2 {
			r := b[off : off+recLen]
			nameLen := int(binary.LittleEndian.Uint16(r[56:]))
			nameOff := int(binary.LittleEndian.Uint16(r[58:]))
			if nameOff+nameLen <= len(r) {
				u := make([]uint16, nameLen/2)
				for i := range u {
					u[i] = binary.LittleEndian.Uint16(r[nameOff+i*2:])
				}
				fn(usnRecord{
					FileRef:   binary.LittleEndian.Uint64(r[8:]),
					ParentRef: binary.LittleEndian.Uint64(r[16:]),
					Usn:       int64(binary.LittleEndian.Uint64(r[24:])),
					Time:      filetime(binary.LittleEndian.Uint64(r[32:])),
					Reason:    binary.LittleEndian.Uint32(r[40:]),
					Attrs:     binary.LittleEndian.Uint32(r[52:]),
					Name:      string(utf16.Decode(u)),
				})
			}
		}
		off += (recLen + 7) &^ 7
	}
}

var (
	interestingExt = regexp.MustCompile(`(?i)\.(jar|exe|dll|zip|rar|7z|bat|cmd|ps1|vbs|ahk|py|pyw|sys|scr|pf|evtx)$|consolehost_history`)
	churnDirs      = regexp.MustCompile(`(?i)^[a-z]:\\(windows|programdata\\microsoft|program files( \(x86\))?\\(windowsapps|microsoft|common files|google|mozilla))|\\appdata\\local\\(microsoft|google|packages|discord\\packages|nvidia|temp\\.{0,40}(\.tmp|\{))`)
	strongExt      = regexp.MustCompile(`(?i)\.(jar|exe|dll|ahk|pf|evtx)$`)
)

type fileEvent struct {
	when    time.Time
	kind    string // deleted / renamed / created+deleted
	name    string
	newName string
	dir     string
	level   string
	why     string
}

func usnInteresting(name string) bool { return interestingExt.MatchString(name) }

func judgeFile(ev *fileEvent) {
	low := strings.ToLower(ev.name + " " + ev.newName + " " + ev.dir)
	ev.level = "INFO"
	switch {
	case strings.Contains(low, "consolehost_history"):
		ev.level, ev.why = "FAIL", "powershell history file"
	case strings.HasSuffix(strings.ToLower(ev.name), ".evtx"):
		ev.level, ev.why = "FAIL", "event log file"
	case strings.HasSuffix(strings.ToLower(ev.name), ".pf") && ev.kind != "renamed":
		ev.level, ev.why = "WARN", "prefetch file"
	case len(exeFlags(ev.name+" "+ev.newName)) > 0:
		ev.level, ev.why = exeFlags(ev.name + " " + ev.newName)[0].level, exeFlags(ev.name + " " + ev.newName)[0].label
	case strings.HasSuffix(strings.ToLower(ev.name), ".jar") && (strings.Contains(low, `\mods`) || strings.Contains(low, "minecraft") || strings.Contains(low, "lunar") || strings.Contains(low, "feather")):
		ev.level, ev.why = "FAIL", "mod removed from a minecraft folder"
	case ev.kind == "renamed" && strongExt.MatchString(ev.name) && !strings.EqualFold(filepath.Ext(ev.name), filepath.Ext(ev.newName)):
		ev.level, ev.why = "WARN", "extension changed"
	case strings.HasSuffix(strings.ToLower(ev.name), ".jar"):
		ev.level, ev.why = "WARN", "jar deleted"
	case strings.HasSuffix(strings.ToLower(ev.name), ".ahk"):
		ev.level, ev.why = "WARN", "autohotkey script"
	case strongExt.MatchString(ev.name) && (strings.Contains(low, `\downloads`) || strings.Contains(low, `\desktop`) || strings.Contains(low, `\documents`)):
		ev.level, ev.why = "WARN", "program deleted from user folders"
	}
	// windows / app updaters churn through dlls and exes constantly
	if ev.level != "FAIL" && churnDirs.MatchString(ev.dir) {
		ev.level, ev.why = "INFO", ""
	}
}

func runDeleted() {
	since := time.Now().Add(-24 * time.Hour)
	var all []fileEvent
	for _, d := range listDrives() {
		if d.Type != driveFixed && d.Type != driveRemovable {
			continue
		}
		if !strings.EqualFold(d.FS, "NTFS") {
			continue
		}
		section("Drive " + d.Letter + "  ·  change journal")
		created := map[uint64]bool{}
		oldNames := map[uint64]usnRecord{}
		var oldest time.Time
		var evs []fileEvent
		count := 0
		j, err := usnWalk(d.Letter, func(r usnRecord) {
			count++
			if oldest.IsZero() && !r.Time.IsZero() {
				oldest = r.Time
			}
			if r.Time.Before(since) || r.Attrs&0x10 != 0 { // directories skipped
				return
			}
			if !usnInteresting(r.Name) {
				switch {
				case r.Reason&usnRenOld != 0:
					oldNames[r.FileRef] = r // could be renamed TO something interesting
				case r.Reason&usnRenNew != 0 && r.Reason&usnClose != 0:
					// something.jar -> something.txt
					if old, ok := oldNames[r.FileRef]; ok && usnInteresting(old.Name) {
						evs = append(evs, fileEvent{when: r.Time, kind: "renamed", name: old.Name, newName: r.Name, dir: dirOf(d.Letter, r.ParentRef)})
						delete(oldNames, r.FileRef)
					}
				}
				return
			}
			if r.Reason&usnCreate != 0 {
				created[r.FileRef] = true
			}
			switch {
			case r.Reason&usnDelete != 0 && r.Reason&usnClose != 0:
				kind := "deleted"
				if created[r.FileRef] {
					kind = "created+deleted"
				}
				evs = append(evs, fileEvent{when: r.Time, kind: kind, name: r.Name, dir: dirOf(d.Letter, r.ParentRef)})
			case r.Reason&usnRenOld != 0:
				oldNames[r.FileRef] = r
			case r.Reason&usnRenNew != 0 && r.Reason&usnClose != 0:
				if old, ok := oldNames[r.FileRef]; ok && old.Name != r.Name {
					evs = append(evs, fileEvent{when: r.Time, kind: "renamed", name: old.Name, newName: r.Name, dir: dirOf(d.Letter, r.ParentRef)})
					delete(oldNames, r.FileRef)
				}
			}
		})
		if err != nil {
			row("WARN", "Journal "+d.Letter, "couldn't read it", err.Error())
			continue
		}
		// the journal id is the time it was created
		if made := filetime(j.ID); made.After(time.Date(2005, 1, 1, 0, 0, 0, 0, time.UTC)) && made.Before(time.Now().Add(24*time.Hour)) {
			if made.After(bootTime()) || time.Since(made) < 24*time.Hour {
				row("FAIL", "Journal created", ts(made), ago(made)+"  ·  the journal was deleted and made again recently")
			} else {
				row("OK", "Journal created", ts(made), ago(made))
			}
		}
		if !oldest.IsZero() {
			lvl := "INFO"
			note := "how far back this drive's journal goes"
			if time.Since(oldest) < 3*time.Hour {
				lvl, note = "WARN", "very short history, could have been flushed"
			}
			row(lvl, "Covers back to", ts(oldest), ago(oldest)+"  ·  "+note)
		}
		row("INFO", "Records read", fmt.Sprintf("%d", count), sizeText(float64(j.MaxSize))+" max journal size")
		for i := range evs {
			judgeFile(&evs[i])
		}
		all = append(all, evs...)
	}

	section("Deleted / renamed in the last 24h")
	sort.Slice(all, func(i, j int) bool { return all[i].when.After(all[j].when) })
	shown, quiet := 0, 0
	for _, ev := range all {
		full := filepath.Join(ev.dir, ev.name)
		if ev.dir == "" {
			full = ev.name
		}
		what := ev.kind
		if ev.kind == "renamed" {
			what = "renamed -> " + ev.newName
		}
		if ev.level == "INFO" {
			quiet++
			report.WriteString(fmt.Sprintf("   %s  %-16s %s\r\n", ev.when.Format("01-02 15:04:05"), ev.kind, full))
			continue
		}
		shown++
		row(ev.level, cut(ev.name, 24), what, ev.when.Format("01-02 15:04")+" · "+ago(ev.when)+" · "+ev.why)
		sub(full, "DarkGray")
	}
	if shown == 0 {
		row("OK", "Suspicious deletes", "none", "")
	}
	if quiet > 0 {
		outln(fmt.Sprintf("   + %d normal-looking deletes/renames (listed in the saved report)", quiet), "DarkGray")
	}
}

func dirOf(letter string, parent uint64) string {
	if p := resolveFileRef(letter, parent); p != "" {
		return p
	}
	return letter + `\?`
}
