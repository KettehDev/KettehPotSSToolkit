// PowerShell Inspector: every PowerShell command Windows kept a record of in the last 10 hours.
package main

import (
	"encoding/base64"
	"fmt"
	"os"
	"path/filepath"
	"regexp"
	"sort"
	"strings"
	"time"
	"unicode/utf16"
)

const psWindow = 10 * time.Hour

type psCmd struct {
	Time    time.Time
	Sources []string
	Text    string
	Detail  string // who started it / host
	Decoded string // -EncodedCommand payload
	Flags   []psFlag
}

type psFlag struct{ level, label string }

type psRule struct {
	level, label string
	re           *regexp.Regexp
}

var psRules = []psRule{
	{"FAIL", "clears event logs", regexp.MustCompile(`(?i)clear-eventlog|remove-eventlog|wevtutil(\.exe)?\s+(cl|clear-log)\b|limit-eventlog|\[System\.Diagnostics\.Eventing\.Reader\.EventLogSession\].*ClearLog`)},
	{"FAIL", "deletes the USN journal", regexp.MustCompile(`(?i)fsutil(\.exe)?\s+usn\s+deletejournal`)},
	{"FAIL", "touches Prefetch", regexp.MustCompile(`(?i)(remove-item|\bri\b|\bdel\b|\brm\b|\berase\b|\brd\b|rmdir|clear-content|set-itemproperty|move-item|copy-item|rename-item).{0,200}prefetch|prefetch.{0,200}(remove-item|\bdel\b|\brm\b)|EnablePrefetcher`)},
	{"FAIL", "stops / changes an SS service", regexp.MustCompile(`(?i)(stop-service|set-service|suspend-service|\bsc(\.exe)?\s+(stop|config|pause)|net(\.exe)?\s+stop|taskkill).{0,120}\b(sysmain|pcasvc|dps|eventlog|bam|diagtrack|appinfo|dusmsvc|cdpsvc|wsearch|schedule)\b`)},
	{"FAIL", "edits tracking keys (BAM / UserAssist / ShellBags)", regexp.MustCompile(`(?i)(reg(\.exe)?\s+delete|remove-item|remove-itemproperty|clear-itemproperty|set-itemproperty|new-itemproperty).{0,200}(\\bam\\|userassist|shellbag|bagmru|recentdocs|muicache|appcompatcache|compatibility assistant)`)},
	{"FAIL", "wipes free space / shreds files", regexp.MustCompile(`(?i)cipher(\.exe)?\s+/w|sdelete|\bshred\b`)},
	{"FAIL", "touches PowerShell history", regexp.MustCompile(`(?i)clear-history|consolehost_history|historysavepath|set-psreadlineoption.{0,80}historysavestyle|\(get-psreadlineoption\)\.historysavepath`)},
	{"WARN", "changes the system time", regexp.MustCompile(`(?i)set-date|w32tm(\.exe)?\s+/(config|resync)|\btime\s+\d|\bdate\s+\d`)},
	{"WARN", "Defender exclusion / tamper", regexp.MustCompile(`(?i)(add|set)-mppreference|disablerealtimemonitoring|exclusionpath`)},
	{"WARN", "runs downloaded code (iex)", regexp.MustCompile(`(?i)\biex\b|invoke-expression|\|\s*&\s*\(|scriptblock\]::create`)},
	{"WARN", "downloads something", regexp.MustCompile(`(?i)\birm\b|invoke-restmethod|\biwr\b|invoke-webrequest|downloadstring|downloadfile|downloaddata|net\.webclient|start-bitstransfer|bitsadmin|\bcurl(\.exe)?\s|\bwget\s|certutil(\.exe)?\s.{0,40}-urlcache`)},
	{"WARN", "encoded command", regexp.MustCompile(`(?i)(^|\s)-e(n|nc|nco|ncod|ncode|ncoded|ncodedc\w*|c)?\s+[A-Za-z0-9+/=]{12,}`)},
	{"WARN", "hidden window", regexp.MustCompile(`(?i)-w(i|in|ind|indo|indow|indows|indowst\w*)?\s+(hidden|1)\b`)},
	{"WARN", "deletes files", regexp.MustCompile(`(?i)(remove-item|\bri\b|\bdel\b|\berase\b|\brm\b|rmdir|\brd\b)\s.{0,200}(\.jar|\.exe|\.dll|\.ahk|\\mods\b|\.minecraft|\\temp\\|\\downloads\\|recycle)`)},
	{"WARN", "hides files", regexp.MustCompile(`(?i)attrib(\.exe)?\s+\+[hs]|\.attributes\s*=.{0,40}hidden|fileattributes\]::hidden`)},
	{"WARN", "Minecraft / java related", regexp.MustCompile(`(?i)javaw?(\.exe)?\b|-javaagent|\.jar\b|\.minecraft|\\mods\\|inject`)},
	{"WARN", "virtual drive / mounting", regexp.MustCompile(`(?i)mount-diskimage|mount-vhd|\bsubst(\.exe)?\s|mountvol|diskpart`)},
	{"WARN", "kills processes", regexp.MustCompile(`(?i)stop-process|taskkill|\bkill\s`)},
}

var encodedRe = regexp.MustCompile(`(?i)(?:^|\s)-e(?:n|nc|nco|ncod|ncode|ncoded|ncodedc\w*|c)?\s+([A-Za-z0-9+/=]{12,})`)

// decodeEncodedCommand returns the text hidden in powershell -EncodedCommand (UTF-16LE base64).
func decodeEncodedCommand(cmd string) string {
	m := encodedRe.FindStringSubmatch(cmd)
	if m == nil {
		return ""
	}
	b, err := base64.StdEncoding.DecodeString(m[1])
	if err != nil {
		b, err = base64.RawStdEncoding.DecodeString(strings.TrimRight(m[1], "="))
		if err != nil {
			return ""
		}
	}
	if len(b)%2 == 1 {
		b = b[:len(b)-1]
	}
	u := make([]uint16, len(b)/2)
	for i := range u {
		u[i] = uint16(b[2*i]) | uint16(b[2*i+1])<<8
	}
	return string(utf16.Decode(u))
}

func psFlags(text string) []psFlag {
	var out []psFlag
	for _, r := range psRules {
		if r.re.MatchString(text) {
			out = append(out, psFlag{r.level, r.label})
		}
	}
	return out
}

func (c *psCmd) level() string {
	lvl := "INFO"
	for _, f := range c.Flags {
		if f.level == "FAIL" {
			return "FAIL"
		}
		lvl = "WARN"
	}
	return lvl
}

// script blocks PowerShell runs by itself all the time
var psNoise = map[string]bool{
	"prompt":    true,
	"$global:?": true,
	"{ Set-StrictMode -Version 1; $_.PSMessageDetails }":                             true,
	"{ Set-StrictMode -Version 1; $_.ErrorCategory_Message }":                        true,
	"{ Set-StrictMode -Version 1; $_.OriginInfo }":                                   true,
	"{ Set-StrictMode -Version 1; $this.Exception.InnerException.PSMessageDetails }": true,
	"{ $this.ServiceName }":                                                          true,
	"{ $_.ScriptBlock }":                                                             true,
}

var (
	reHostApp  = regexp.MustCompile(`(?m)HostApplication=(.*)$`)
	reCmdLine  = regexp.MustCompile(`(?m)CommandLine=(.*)$`)
	reCtxHost  = regexp.MustCompile(`(?m)Host Application = (.*)$`)
	reCtxUser  = regexp.MustCompile(`(?m)User = (.*)$`)
	reCmdName  = regexp.MustCompile(`(?m)Command Name = (.*)$`)
	reBarePS   = regexp.MustCompile(`(?i)^"?[a-z]:\\[^"]*\\(powershell|pwsh|powershell_ise)(\.exe)?"?\s*$`)
	reSysPaths = regexp.MustCompile(`(?i)^[a-z]:\\(windows|program files( \(x86\))?)\\`)
)

type psCollector struct {
	cmds  []*psCmd
	index map[string]*psCmd
	notes []string
}

func (pc *psCollector) add(t time.Time, source, text, detail string) {
	text = strings.TrimSpace(strings.ReplaceAll(text, "\r\n", "\n"))
	if text == "" || psNoise[text] {
		return
	}
	key := t.Truncate(time.Minute).Format("0601021504") + "|" + text
	if c, ok := pc.index[key]; ok {
		for _, s := range c.Sources {
			if s == source {
				return
			}
		}
		c.Sources = append(c.Sources, source)
		if c.Detail == "" {
			c.Detail = detail
		}
		return
	}
	c := &psCmd{Time: t, Sources: []string{source}, Text: text, Detail: detail}
	c.Decoded = decodeEncodedCommand(text)
	c.Flags = psFlags(text + "\n" + c.Decoded)
	pc.cmds = append(pc.cmds, c)
	pc.index[key] = c
}

func firstMatch(re *regexp.Regexp, s string) string {
	if m := re.FindStringSubmatch(s); m != nil {
		return strings.TrimSpace(m[1])
	}
	return ""
}

func isPowerShellExe(p string) bool {
	b := strings.ToLower(filepath.Base(p))
	return b == "powershell.exe" || b == "pwsh.exe" || b == "powershell_ise.exe"
}

func (pc *psCollector) fromEventLogs() (sessions int) {
	// Windows PowerShell (5.1) classic log: 400 = engine started, 800 = pipeline ran
	if evs, err := queryEvents("Windows PowerShell", sinceQuery(psWindow, 400, 800), 3000); err == nil {
		for _, e := range evs {
			all := e.all()
			if e.ID == 400 {
				host := firstMatch(reHostApp, all)
				if host == "" {
					continue
				}
				sessions++
				if reBarePS.MatchString(host) {
					pc.add(e.Time, "powershell window opened", host, "")
				} else {
					pc.add(e.Time, "powershell started with", host, "")
				}
			} else if cl := firstMatch(reCmdLine, all); cl != "" {
				pc.add(e.Time, "pipeline (800)", cl, firstMatch(reHostApp, all))
			}
		}
	} else {
		pc.notes = append(pc.notes, "couldn't read the 'Windows PowerShell' log")
	}

	// script blocks + module logging, for 5.1 and 7
	for _, ch := range []struct{ name, label string }{
		{"Microsoft-Windows-PowerShell/Operational", "script block"},
		{"PowerShellCore/Operational", "script block (pwsh 7)"},
	} {
		evs, err := queryEvents(ch.name, sinceQuery(psWindow, 4103, 4104), 5000)
		if err != nil {
			continue
		}
		type part struct {
			t     time.Time
			lvl   int
			path  string
			parts map[string]string
			total int
		}
		blocks := map[string]*part{}
		var order []string
		for _, e := range evs {
			if e.ID == 4103 {
				ctx := e.Data["ContextInfo"]
				name := firstMatch(reCmdName, ctx)
				payload := strings.TrimSpace(e.Data["Payload"])
				if name == "" && payload == "" {
					continue
				}
				pc.add(e.Time, "module log (4103)", strings.TrimSpace(name+"  "+payload), firstMatch(reCtxUser, ctx)+"  "+firstMatch(reCtxHost, ctx))
				continue
			}
			id := e.Data["ScriptBlockId"]
			if id == "" {
				id = e.Time.String()
			}
			b, ok := blocks[id]
			if !ok {
				b = &part{t: e.Time, lvl: e.Level, path: e.Data["Path"], parts: map[string]string{}}
				blocks[id] = b
				order = append(order, id)
			}
			if e.Time.Before(b.t) {
				b.t = e.Time
			}
			fmt.Sscan(e.Data["MessageTotal"], &b.total)
			b.parts[e.Data["MessageNumber"]] = e.Data["ScriptBlockText"]
		}
		for _, id := range order {
			b := blocks[id]
			if b.path != "" && reSysPaths.MatchString(b.path) {
				continue // windows' own modules loading
			}
			var sb strings.Builder
			n := b.total
			if n < 1 {
				n = len(b.parts)
			}
			for i := 1; i <= n; i++ {
				sb.WriteString(b.parts[itoa(i)])
			}
			label := ch.label
			if b.lvl == 3 {
				label += " · auto-logged as suspicious"
			}
			detail := ""
			if b.path != "" {
				detail = "from " + b.path
			}
			pc.add(b.t, label, sb.String(), detail)
		}
	}

	// process creation (only if the PC has command line auditing on)
	if evs, err := queryEvents("Security", sinceQuery(psWindow, 4688), 5000); err == nil {
		for _, e := range evs {
			if isPowerShellExe(e.Data["NewProcessName"]) && e.Data["CommandLine"] != "" {
				pc.add(e.Time, "process started (4688)", e.Data["CommandLine"], "parent: "+e.Data["ParentProcessName"])
			}
		}
	}
	if evs, err := queryEvents("Microsoft-Windows-Sysmon/Operational", sinceQuery(psWindow, 1), 5000); err == nil {
		for _, e := range evs {
			if isPowerShellExe(e.Data["Image"]) {
				pc.add(e.Time, "sysmon process", e.Data["CommandLine"], "parent: "+e.Data["ParentCommandLine"])
			}
		}
	}
	return sessions
}

type psHistory struct {
	path     string
	modified time.Time
	lines    []string
	hidden   bool
}

func historyFiles() []psHistory {
	var out []psHistory
	var dirs []string
	users := filepath.Join(os.Getenv("SystemDrive")+`\`, "Users")
	if entries, err := os.ReadDir(users); err == nil {
		for _, u := range entries {
			if u.IsDir() {
				dirs = append(dirs, filepath.Join(users, u.Name(), `AppData\Roaming\Microsoft\Windows\PowerShell\PSReadLine`))
			}
		}
	}
	if a := os.Getenv("APPDATA"); a != "" {
		dirs = append(dirs, filepath.Join(a, `Microsoft\Windows\PowerShell\PSReadLine`))
	}
	seen := map[string]bool{}
	for _, d := range dirs {
		files, _ := os.ReadDir(d)
		for _, f := range files {
			p := filepath.Join(d, f.Name())
			if f.IsDir() || !strings.HasSuffix(strings.ToLower(f.Name()), ".txt") || seen[strings.ToLower(p)] {
				continue
			}
			seen[strings.ToLower(p)] = true
			info, err := f.Info()
			if err != nil {
				continue
			}
			h := psHistory{path: p, modified: info.ModTime()}
			h.hidden, _, _ = fileAttrs(info)
			if b, err := os.ReadFile(p); err == nil {
				for _, l := range strings.Split(strings.ReplaceAll(string(b), "\r\n", "\n"), "\n") {
					if strings.TrimSpace(l) != "" {
						h.lines = append(h.lines, l)
					}
				}
			}
			out = append(out, h)
		}
	}
	return out
}

func runPowerShell() {
	since := time.Now().Add(-psWindow)
	pc := &psCollector{index: map[string]*psCmd{}}

	section("Event logs  ·  last 10 hours")
	outln("   reading powershell logs...", "DarkGray")
	sessions := pc.fromEventLogs()
	sort.SliceStable(pc.cmds, func(i, j int) bool { return pc.cmds[i].Time.After(pc.cmds[j].Time) })

	row("INFO", "PowerShell sessions", fmt.Sprintf("%d started", sessions), "since "+since.Format("15:04"))
	row("INFO", "Commands found", fmt.Sprintf("%d", len(pc.cmds)), "")
	if v, ok := regDWORD(hklm, `SOFTWARE\Policies\Microsoft\Windows\PowerShell\ScriptBlockLogging`, "EnableScriptBlockLogging"); !ok || v != 1 {
		outln("          │   script block logging is off (windows default), so only suspicious", "DarkGray")
		outln("          │   blocks, launches and typed history get recorded", "DarkGray")
	}
	for _, n := range pc.notes {
		row("WARN", "Event log", n, "")
	}

	flagged := 0
	for _, c := range pc.cmds {
		if len(c.Flags) > 0 {
			flagged++
		}
	}
	if len(pc.cmds) > 0 {
		section("Commands  ·  newest first")
		shown := 0
		for _, c := range pc.cmds {
			// on screen: everything flagged + the latest plain ones
			if len(c.Flags) == 0 && shown >= 25 {
				continue
			}
			shown++
			lvl := c.level()
			color := map[string]string{"FAIL": "Red", "WARN": "Yellow", "INFO": "Gray"}[lvl]
			outn("   "+c.Time.Format("15:04:05")+"  ", "DarkGray")
			outln(cut(strings.ReplaceAll(c.Text, "\n", " ⏎ "), 96), color)
			outln("            "+strings.Join(c.Sources, " · "), "DarkGray")
			if c.Decoded != "" {
				outln("            decoded: "+cut(strings.ReplaceAll(c.Decoded, "\n", " ⏎ "), 86), "Cyan")
			}
			for _, f := range c.Flags {
				outln("            ✗ "+f.label, map[string]string{"FAIL": "Red", "WARN": "Yellow"}[f.level])
				flag(f.level, f.label+" · "+cut(strings.ReplaceAll(c.Text, "\n", " "), 70))
			}
		}
		if hidden := len(pc.cmds) - shown; hidden > 0 {
			outln(fmt.Sprintf("            ... %d more unflagged in the txt", hidden), "DarkGray")
		}
	}

	section("Typed history (PSReadLine)")
	hist := historyFiles()
	recentTyped := 0
	if len(hist) == 0 {
		if sessions > 0 {
			row("WARN", "History file", "missing", "powershell was used in the last 10h but there's no history file")
		} else {
			row("INFO", "History file", "none", "")
		}
	}
	for _, h := range hist {
		label := filepath.Base(h.path)
		user := ""
		if parts := strings.Split(h.path, `\`); len(parts) > 3 && strings.EqualFold(parts[1], "Users") {
			user = parts[2] + " · "
		}
		if h.modified.After(since) {
			recentTyped++
			row("WARN", cut(label, 24), fmt.Sprintf("%d lines · typed in within 10h", len(h.lines)), user+"last write "+h.modified.Format("15:04:05"))
			start := len(h.lines) - 8
			if start < 0 {
				start = 0
			}
			for _, l := range h.lines[start:] {
				sub(cut(l, 90), "White")
			}
		} else {
			row("OK", cut(label, 24), fmt.Sprintf("%d lines · nothing new", len(h.lines)), user+"last write "+ago(h.modified))
		}
		if h.hidden {
			row("WARN", "History hidden", label, "the history file is set to hidden")
		}
		if len(h.lines) == 0 {
			row("WARN", "History empty", label, "exists but has nothing in it (cleared?)")
		}
	}

	// ---------------------------------------------------------------- the y/n
	blank()
	outln(fmt.Sprintf("   %d commands  ·  %d flagged  ·  %d history file(s) used in the last 10h", len(pc.cmds), flagged, recentTyped), "White")
	blank()
	if askYesNo("   PowerShell Inspector has finished, Would you like to open a txt file with all last ran commands? (y/n)") {
		path := filepath.Join(outputDir(), "ketteh_powershell_"+time.Now().Format("2006-01-02_15-04-05")+".txt")
		if err := writeText(path, psReport(pc, hist, since, sessions)); err != nil {
			colorPrint("   couldn't write it: "+err.Error(), "Red")
			return
		}
		colorPrint("   saved -> "+path, "Green")
		if !openInNotepad(path) {
			colorPrint("   couldn't open notepad, the file is at the path above", "Yellow")
		}
	}
}

func psReport(pc *psCollector, hist []psHistory, since time.Time, sessions int) string {
	var b strings.Builder
	w := func(s string) { b.WriteString(s + "\n") }
	bar := strings.Repeat("═", 78)
	thin := strings.Repeat("─", 78)
	host, _ := os.Hostname()

	w("KETTEHPOT v" + version + "  ·  PowerShell Inspector")
	w(credits + "  ·  discord: zoe_mahhh")
	w(bar)
	w("computer : " + host + "   user: " + currentUser())
	w("window   : last 10 hours  (" + ts(since) + "  ->  " + ts(time.Now()) + ")")
	w(fmt.Sprintf("found    : %d commands from the event logs, %d powershell sessions started", len(pc.cmds), sessions))
	w("")

	var flagged []*psCmd
	for _, c := range pc.cmds {
		if len(c.Flags) > 0 {
			flagged = append(flagged, c)
		}
	}
	w(bar)
	w(fmt.Sprintf(" FLAGGED  (%d)", len(flagged)))
	w(bar)
	if len(flagged) == 0 {
		w("  nothing flagged")
	}
	for _, c := range flagged {
		labels := make([]string, len(c.Flags))
		for i, f := range c.Flags {
			labels[i] = strings.ToLower(f.level) + ": " + f.label
		}
		w("  [" + ts(c.Time) + "]  " + strings.Join(labels, ", "))
		w("      " + cut(strings.ReplaceAll(c.Text, "\n", " ⏎ "), 200))
	}
	w("")

	w(bar)
	w(fmt.Sprintf(" ALL COMMANDS  ·  newest first  (%d)", len(pc.cmds)))
	w(bar)
	if len(pc.cmds) == 0 {
		w("  no powershell commands in the event logs for the last 10 hours")
	}
	for _, c := range pc.cmds {
		w("")
		w("[" + ts(c.Time) + "]  " + strings.Join(c.Sources, " · "))
		if c.Detail != "" {
			w("  " + strings.TrimSpace(c.Detail))
		}
		for _, l := range strings.Split(c.Text, "\n") {
			w("    " + l)
		}
		if c.Decoded != "" {
			w("  decoded -EncodedCommand:")
			for _, l := range strings.Split(strings.ReplaceAll(c.Decoded, "\r\n", "\n"), "\n") {
				w("    " + l)
			}
		}
		for _, f := range c.Flags {
			w("  !! " + strings.ToLower(f.level) + ": " + f.label)
		}
		w("  " + thin[:40])
	}
	w("")

	w(bar)
	w(" TYPED HISTORY  (PSReadLine)")
	w(bar)
	w("  windows doesn't store a time for each typed line, only when the file was last")
	w("  written. files written in the last 10 hours show their newest lines (last = newest).")
	if len(hist) == 0 {
		w("")
		w("  no history files found")
	}
	for _, h := range hist {
		w("")
		w("  " + h.path)
		w(fmt.Sprintf("  %d lines  ·  last written %s (%s)", len(h.lines), ts(h.modified), ago(h.modified)))
		if !h.modified.After(since) {
			w("  nothing typed in the last 10 hours")
			continue
		}
		w("  " + thin[:40])
		start := len(h.lines) - 300
		if start < 0 {
			start = 0
		} else {
			w(fmt.Sprintf("  (showing the newest 300 of %d)", len(h.lines)))
		}
		for i, l := range h.lines[start:] {
			mark := "   "
			if fl := psFlags(l); len(fl) > 0 {
				mark = " !!"
			}
			w(fmt.Sprintf("%s %5d  %s", mark, start+i+1, l))
		}
	}
	w("")
	w(bar)
	w("end of powershell inspector  </3")
	return b.String()
}
