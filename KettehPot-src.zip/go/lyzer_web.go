// KettehLyzer dashboard: live scan progress + the full results, served at /lyzer and
// opened in the normal browser. Also the standalone "KettehLyzer" mode.
package main

import (
	_ "embed"
	"encoding/json"
	"fmt"
	"os"
	"os/exec"
	"path/filepath"
	"runtime"
	"sync"
	"sync/atomic"
	"time"
)

//go:embed web/lyzer.html
var lyzerHTML string

var (
	lyzerMu      sync.Mutex
	lyzerJSON    []byte // newest finished scan
	lyzerSeq     int
	lyzerViewers int32  // dashboard tabs connected right now
	guiBase      string // http://127.0.0.1:port
	guiToken     string
	lyzerOpened  bool
	lyzerPaths   = map[string]bool{}
)

// openBrowser opens a URL in the default browser.
func openBrowser(url string) {
	switch runtime.GOOS {
	case "windows":
		exec.Command("rundll32", "url.dll,FileProtocolHandler", url).Start()
	case "darwin":
		exec.Command("open", url).Start()
	default:
		exec.Command("xdg-open", url).Start()
	}
}

func lyzerURL() string { return guiBase + "/lyzer?t=" + guiToken }

// lyzerBegin tells the dashboard a scan started, opening it if nobody is looking.
func lyzerBegin(path string, results []*result) {
	if !gui {
		return
	}
	names := make([]string, len(results))
	for i, r := range results {
		names[i] = r.Name
	}
	emit(map[string]any{"type": "lyzer_start", "path": path, "jars": names, "at": time.Now().Unix()})
	if atomic.LoadInt32(&lyzerViewers) == 0 && os.Getenv("KETTEH_NO_BROWSER") == "" {
		openBrowser(lyzerURL())
		lyzerOpened = true
	}
}

// lyzerTick: one jar finished a pass.
func lyzerTick(pass, done, total int, name string) {
	emit(map[string]any{"type": "lyzer_tick", "pass": pass, "done": done, "total": total, "name": name})
}

// lyzerStatuses: every jar's status after a pass (colours the sonar blips).
func lyzerStatuses(pass int, results []*result) {
	st := map[string]string{}
	for _, r := range results {
		st[r.Name] = r.Status
	}
	emit(map[string]any{"type": "lyzer_status", "pass": pass, "status": st})
}

// parallelEachTick is parallelEach that reports each finished jar to the dashboard.
func parallelEachTick(pass int, results []*result, fn func(int)) {
	var done int32
	parallelEach(len(results), func(i int) {
		fn(i)
		n := atomic.AddInt32(&done, 1)
		lyzerTick(pass, int(n), len(results), results[i].Name)
	})
}

type lyzerJar struct {
	Name        string              `json:"name"`
	ModrinthID  string              `json:"modrinthId"`
	Path        string              `json:"path"`
	Size        int64               `json:"size"`
	Modified    int64               `json:"modified"`
	SHA1        string              `json:"sha1"`
	Status      string              `json:"status"`
	Source      string              `json:"source"`
	VerifiedAs  string              `json:"verifiedAs"`
	ScanError   string              `json:"scanError"`
	Signatures  []string            `json:"signatures"`
	Cheat       []string            `json:"cheatStrings"`
	Bypass      []string            `json:"bypass"`
	Obfuscation []string            `json:"obfuscation"`
	HitFiles    []string            `json:"hitFiles"`
	BypassNotes map[string][]string `json:"bypassNotes"`
	ObfNotes    map[string][]string `json:"obfNotes"`
	Strings     []string            `json:"strings"`
}

// lyzerPublish stores the finished scan for the dashboard and tells it to load it.
func lyzerPublish(path string, results []*result, started time.Time) {
	if !gui {
		return
	}
	jars := make([]lyzerJar, 0, len(results))
	counts := map[string]int{}
	for _, r := range results {
		j := lyzerJar{Name: r.Name, Path: r.Path, SHA1: r.SHA1, Status: r.Status, Source: r.Source, VerifiedAs: r.VerifiedAs,
			ScanError: r.ScanError, Signatures: nz(r.Signatures), Cheat: nz(r.CheatStrings), Bypass: nz(r.Bypass),
			Obfuscation: nz(r.Obfuscation), HitFiles: nz(r.HitFiles), Strings: nz(r.AllStrings),
			BypassNotes: map[string][]string{}, ObfNotes: map[string][]string{}}
		if st, err := os.Stat(r.Path); err == nil {
			j.Size, j.Modified = st.Size(), st.ModTime().Unix()
		}
		modrinthMu.Lock()
		j.ModrinthID = modrinthProject[r.SHA1]
		modrinthMu.Unlock()
		if r.BypassNotes != nil {
			for _, l := range r.BypassNotes.order {
				j.BypassNotes[l] = r.BypassNotes.files[l]
			}
		}
		if r.ObfNotes != nil {
			for _, l := range r.ObfNotes.order {
				j.ObfNotes[l] = r.ObfNotes.files[l]
			}
		}
		counts[r.Status]++
		jars = append(jars, j)
	}
	host, _ := os.Hostname()
	b, _ := json.Marshal(map[string]any{
		"path": path, "host": host, "jars": jars, "took": time.Since(started).Seconds(),
		"at": time.Now().Unix(), "version": version, "credits": credits,
	})
	lyzerMu.Lock()
	lyzerPaths = map[string]bool{}
	for _, r := range results {
		lyzerPaths[r.Path] = true
	}
	lyzerJSON = b
	lyzerSeq++
	id := lyzerSeq
	lyzerMu.Unlock()
	emit(map[string]any{"type": "lyzer_done", "id": id, "path": path, "counts": counts})
}

func nz(xs []string) []string {
	if xs == nil {
		return []string{}
	}
	return xs
}

// runLyzerStandalone: KettehLyzer on its own, the dashboard in the browser is the whole app.
func runLyzerStandalone() bool {
	url, err := startGUI()
	if err != nil {
		return false
	}
	gui = true
	colorsOn = false
	ssStart = time.Now()
	link := lyzerURL()
	_ = url
	fmt.Println()
	fmt.Println("   KettehLyzer is open in your browser:")
	fmt.Println("   " + link)
	fmt.Println()
	fmt.Println("   Keep this window open while you use it. Closing the browser tab quits.")
	if os.Getenv("KETTEH_NO_BROWSER") == "" {
		openBrowser(link)
	}
	lyzerOpened = true
	if !waitConnected(60 * time.Second) {
		fmt.Println("   the browser never connected, try opening the link above yourself")
		waitConnected(10 * time.Minute)
	}
	helloEvent()
	emit(map[string]any{"type": "ready", "key": ""})
	// start straight away with the folder picker
	if t, ok := toolByKey("15"); ok {
		runMu.Lock()
		running = true
		runMu.Unlock()
		go func() {
			defer func() {
				runMu.Lock()
				running = false
				runMu.Unlock()
				guiTool = ""
				emit(map[string]any{"type": "idle", "key": ""})
			}()
			runTool(t)
		}()
	}
	watchWindow()
	return true
}

// lyzerKnows reports whether p is a jar from the newest scan.
func lyzerKnows(p string) bool {
	lyzerMu.Lock()
	defer lyzerMu.Unlock()
	return p != "" && lyzerPaths[p]
}

// revealInExplorer opens the folder with the file selected.
func revealInExplorer(p string) {
	switch runtime.GOOS {
	case "windows":
		exec.Command("explorer.exe", "/select,", p).Start()
	case "darwin":
		exec.Command("open", "-R", p).Start()
	default:
		exec.Command("xdg-open", filepath.Dir(p)).Start()
	}
}
