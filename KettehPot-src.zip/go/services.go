// Service Checker (the original KettehServiceChecker, now a toolkit tool)
package main

import (
	"crypto/sha256"
	"encoding/binary"
	"encoding/hex"
	"fmt"
	"io"
	"os"
	"path/filepath"
	"regexp"
	"sort"
	"strings"
	"time"
	"unicode/utf16"
)

func runServices() {
	boot := bootTime()
	drives := listDrives()
	checkSystem(boot)
	checkDrives(drives)
	checkServices(boot)
	checkRegistry()
	checkEvents(boot)
	checkPrefetch(boot)
	checkRecycleBin(boot, drives)
	checkHistory(boot)
}

func checkSystem(boot time.Time) {
	section("System")
	host, _ := os.Hostname()
	row("INFO", "Computer", host, "user: "+currentUser())
	if caption, build := osInfo(); caption != "" {
		row("INFO", "Windows", caption, "build "+build)
	}
	zone, _ := time.Now().Zone()
	row("INFO", "Scan time", ts(time.Now()), zone)
	up := time.Since(boot)
	upText := fmt.Sprintf("%dd %02dh %02dm", int(up.Hours())/24, int(up.Hours())%24, int(up.Minutes())%60)
	if up < 15*time.Minute {
		row("WARN", "Last boot", ts(boot), "up "+upText+"  ·  rebooted very recently")
	} else {
		row("INFO", "Last boot", ts(boot), "up "+upText)
	}
}

func checkDrives(drives []driveInfo) {
	section("Drives")
	for _, d := range drives {
		label := "no label"
		if d.Label != "" {
			label = `"` + d.Label + `"`
		}
		fs := d.FS
		if fs == "" {
			fs = "no fs"
		}
		space := ""
		if d.Total > 0 {
			space = fmt.Sprintf("%s free of %s", sizeText(float64(d.Free)), sizeText(float64(d.Total)))
		}
		level := "INFO"
		if d.Type == driveRemovable {
			level = "WARN"
		}
		row(level, d.Letter, fs+" · "+driveTypeName(d.Type)+" · "+label, space)
	}
	if len(drives) == 0 {
		row("WARN", "Drives", "none found", "")
	}
}

var services = []struct{ name, desc string }{
	{"SysMain", "SysMain / Superfetch"},
	{"PcaSvc", "Program Compatibility Assistant"},
	{"DPS", "Diagnostic Policy Service"},
	{"EventLog", "Windows Event Log"},
	{"Schedule", "Task Scheduler"},
	{"DusmSvc", "Data Usage"},
	{"Appinfo", "Application Information"},
	{"CDPSvc", "Connected Devices Platform"},
	{"DcomLaunch", "DCOM Server Process Launcher"},
	{"PlugPlay", "Plug and Play"},
	{"WSearch", "Windows Search"},
	{"DiagTrack", "Connected User Experiences"},
}

// services optimizers often stop; stopped (not disabled) is only a warning for these
var optionalService = map[string]bool{"WSearch": true, "DiagTrack": true, "DusmSvc": true, "CDPSvc": true}

func checkServices(boot time.Time) {
	section("Services")
	for _, s := range services {
		info, ok := queryService(s.name)
		if !ok {
			row("FAIL", s.name, "missing", s.desc)
			continue
		}
		mode := startTypeName(info.StartType)
		if info.State == stateRunning {
			started, have := processStart(info.PID)
			switch {
			case have && mode == "auto" && started.Sub(boot) > 10*time.Minute:
				// auto services start with Windows; one that started much later was restarted
				row("WARN", s.name, "running · restarted after boot",
					"since "+started.Format("15:04:05")+"  ·  "+ago(started))
			case have:
				row("OK", s.name, "running", "since "+started.Format("15:04:05")+"  ·  "+s.desc)
			default:
				row("OK", s.name, "running", s.desc)
			}
			continue
		}
		// disabled = automatic fail, whatever the service
		level := "WARN"
		desc := s.desc
		switch {
		case mode == "disabled":
			level, desc = "FAIL", s.desc+"  ·  disabled = automatic fail"
		case mode == "auto" && !optionalService[s.name]:
			level = "FAIL"
		}
		row(level, s.name, stateName(info.State)+" · "+mode, desc)
	}

	// Background Activity Moderator is a kernel driver, not a normal service
	const bamDesc = "Background Activity Moderator (driver)"
	if info, ok := queryService("bam"); !ok {
		row("WARN", "bam", "driver not found", bamDesc)
	} else if info.State == stateRunning {
		row("OK", "bam", "running", bamDesc)
	} else {
		row("FAIL", "bam", stateName(info.State)+" · "+startTypeName(info.StartType), bamDesc)
	}
}

func checkRegistry() {
	section("Registry")

	if v, ok := regDWORD(hkcu, `Software\Policies\Microsoft\Windows\System`, "DisableCMD"); ok && (v == 1 || v == 2) {
		row("FAIL", "Command Prompt", "disabled by policy", fmt.Sprintf("DisableCMD = %d", v))
	} else {
		row("OK", "Command Prompt", "allowed", "")
	}

	pf, ok := regDWORD(hklm, `SYSTEM\CurrentControlSet\Control\Session Manager\Memory Management\PrefetchParameters`, "EnablePrefetcher")
	switch {
	case ok && pf == 0:
		row("FAIL", "Prefetch", "disabled", "EnablePrefetcher = 0")
	case ok && pf == 1:
		row("WARN", "Prefetch", "boot prefetch off (apps still tracked)", "EnablePrefetcher = 1")
	case ok && pf == 2:
		row("FAIL", "Prefetch", "app prefetch off (boot only)", "EnablePrefetcher = 2")
	case ok:
		row("OK", "Prefetch", "enabled", fmt.Sprintf("EnablePrefetcher = %d", pf))
	default:
		row("OK", "Prefetch", "enabled", "default")
	}

	feed, fOK := regDWORD(hklm, `SOFTWARE\Policies\Microsoft\Windows\System`, "EnableActivityFeed")
	pub, pOK := regDWORD(hklm, `SOFTWARE\Policies\Microsoft\Windows\System`, "PublishUserActivities")
	if (fOK && feed == 0) || (pOK && pub == 0) {
		row("WARN", "Activity history", "disabled by policy", "")
	} else {
		row("OK", "Activity history", "allowed", "")
	}

	if v, ok := regDWORD(hkcu, `Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced`, "Start_TrackProgs"); ok && v == 0 {
		row("WARN", "UserAssist tracking", "turned off", "Start_TrackProgs = 0")
	} else {
		row("OK", "UserAssist tracking", "on", "")
	}

	if v, ok := regDWORD(hklm, `SOFTWARE\Policies\Microsoft\Windows\PowerShell\ScriptBlockLogging`, "EnableScriptBlockLogging"); ok && v == 1 {
		row("INFO", "PowerShell logging", "script block logging on", "")
	} else {
		row("INFO", "PowerShell logging", "not configured", "windows default")
	}
}

func eventRow(boot time.Time, label, channel string, id int, provider string, tamper bool) {
	when, gotID, ok := lastEvent(channel, id, provider)
	if !ok {
		if tamper {
			row("OK", label, "no records", "")
		} else {
			row("INFO", label, "no records", "")
		}
		return
	}
	level := "INFO"
	if tamper {
		level = "WARN"
		if !when.Before(boot) {
			level = "FAIL"
		}
	}
	row(level, label, ts(when), fmt.Sprintf("%s  ·  id %d", ago(when), gotID))
}

func checkEvents(boot time.Time) {
	section("Event logs")
	eventRow(boot, "Security log cleared", "Security", 1102, "", true)
	eventRow(boot, "System log cleared", "System", 104, "", true)
	eventRow(boot, "USN journal deleted", "Application", 3079, "", true)
	eventRow(boot, "System time changed", "System", 1, "Microsoft-Windows-Kernel-General", false)
	eventRow(boot, "Last shutdown/restart", "System", 1074, "", false)
	eventRow(boot, "Unexpected shutdown", "System", 6008, "", false)
	eventRow(boot, "Event log started", "System", 6005, "", false)
	eventRow(boot, "Device configured", "Microsoft-Windows-Kernel-PnP/Configuration", 400, "", false)
}

type pfFile struct {
	name              string
	created, modified time.Time
	hidden, readOnly  bool
	path              string
}

func fileSHA256(path string) string {
	f, err := os.Open(path)
	if err != nil {
		return ""
	}
	defer f.Close()
	h := sha256.New()
	if _, err := io.Copy(h, f); err != nil {
		return ""
	}
	return hex.EncodeToString(h.Sum(nil))
}

func listIssue(label string, files []pfFile) {
	if len(files) == 0 {
		row("OK", label, "none", "")
		return
	}
	row("WARN", label, fmt.Sprintf("%d found", len(files)), "")
	for i, f := range files {
		if i == 10 {
			sub(fmt.Sprintf("... and %d more", len(files)-10), "DarkGray")
			break
		}
		sub(f.name, "White")
	}
}

func checkPrefetch(boot time.Time) {
	section("Prefetch")
	dir := prefetchDir()
	entries, err := os.ReadDir(dir)
	if err != nil {
		if os.IsNotExist(err) {
			row("FAIL", "Prefetch folder", "missing", dir)
		} else {
			row("WARN", "Prefetch folder", "can't read it", err.Error())
		}
		return
	}
	var files []pfFile
	for _, e := range entries {
		if e.IsDir() || !strings.EqualFold(filepath.Ext(e.Name()), ".pf") {
			continue
		}
		info, err := e.Info()
		if err != nil {
			continue
		}
		hidden, ro, created := fileAttrs(info)
		files = append(files, pfFile{e.Name(), created, info.ModTime(), hidden, ro, filepath.Join(dir, e.Name())})
	}
	if len(files) == 0 {
		row("FAIL", "Prefetch files", "none", "the folder is empty")
		return
	}
	if len(files) < 30 {
		row("WARN", "Prefetch files", fmt.Sprintf("%d files", len(files)), "unusually low, could have been cleared")
	} else {
		row("OK", "Prefetch files", fmt.Sprintf("%d files", len(files)), "")
	}

	newest, oldest := files[0], files[0]
	for _, f := range files {
		if f.modified.After(newest.modified) {
			newest = f
		}
		if f.created.Before(oldest.created) {
			oldest = f
		}
	}
	row("INFO", "Newest entry", newest.name, ago(newest.modified))
	if !oldest.created.Before(boot) {
		row("WARN", "Oldest entry", ts(oldest.created), "everything was created after the last boot")
	} else {
		row("INFO", "Oldest entry", ts(oldest.created), ago(oldest.created))
	}

	var hidden, readOnly []pfFile
	byHash := map[string][]string{}
	var hashOrder []string
	for _, f := range files {
		if f.hidden {
			hidden = append(hidden, f)
		}
		if f.readOnly {
			readOnly = append(readOnly, f)
		}
		if h := fileSHA256(f.path); h != "" {
			if _, seen := byHash[h]; !seen {
				hashOrder = append(hashOrder, h)
			}
			byHash[h] = append(byHash[h], f.name)
		}
	}
	listIssue("Hidden files", hidden)
	listIssue("Read-only files", readOnly)

	var dupes [][]string
	for _, h := range hashOrder {
		if len(byHash[h]) > 1 {
			dupes = append(dupes, byHash[h])
		}
	}
	if len(dupes) == 0 {
		row("OK", "Duplicate files", "none", "")
		return
	}
	row("WARN", "Duplicate files", fmt.Sprintf("%d set(s)", len(dupes)), "identical prefetch files usually mean copies")
	for _, set := range dupes {
		sub(strings.Join(set, "  =  "), "White")
	}
}

// ---------------------------------------------------------------- recycle bin

type binItem struct {
	name    string
	size    int64
	deleted time.Time
}

// Reads a $I file: the record Windows keeps for each deleted file.
func readRecycleInfo(path string) (binItem, bool) {
	b, err := os.ReadFile(path)
	if err != nil || len(b) < 24 {
		return binItem{}, false
	}
	ver := int64(binary.LittleEndian.Uint64(b[0:]))
	size := int64(binary.LittleEndian.Uint64(b[8:]))
	ft := int64(binary.LittleEndian.Uint64(b[16:]))
	// FILETIME (100ns since 1601) -> unix
	deleted := time.Unix(0, (ft-116444736000000000)*100)

	var u16 []uint16
	if ver == 2 && len(b) >= 28 {
		n := int(binary.LittleEndian.Uint32(b[24:]))
		if n > 1 && 28+(n-1)*2 <= len(b) {
			for i := 0; i < n-1; i++ {
				u16 = append(u16, binary.LittleEndian.Uint16(b[28+i*2:]))
			}
		}
	} else {
		end := len(b)
		if end > 24+520 {
			end = 24 + 520
		}
		for i := 24; i+1 < end; i += 2 {
			c := binary.LittleEndian.Uint16(b[i:])
			if c == 0 {
				break
			}
			u16 = append(u16, c)
		}
	}
	return binItem{string(utf16.Decode(u16)), size, deleted}, true
}

var riskyExt = regexp.MustCompile(`(?i)\.(jar|exe|dll|zip|rar|7z|bat|cmd|ps1|vbs|ahk|py|sys)$`)

func checkRecycleBin(boot time.Time, drives []driveInfo) {
	section("Recycle bin")
	anyBin := false
	for _, d := range drives {
		if d.Type != driveFixed && d.Type != driveRemovable {
			continue
		}
		bin := filepath.Join(driveRoot(d.Letter), "$Recycle.Bin")
		st, err := os.Stat(bin)
		if err != nil {
			continue
		}
		anyBin = true
		lastChange := st.ModTime()
		var items []binItem
		sids, _ := os.ReadDir(bin)
		for _, sid := range sids {
			if !sid.IsDir() {
				continue
			}
			if si, err := sid.Info(); err == nil && si.ModTime().After(lastChange) {
				lastChange = si.ModTime()
			}
			files, _ := os.ReadDir(filepath.Join(bin, sid.Name()))
			for _, f := range files {
				if f.IsDir() || !strings.HasPrefix(f.Name(), "$I") {
					continue
				}
				if it, ok := readRecycleInfo(filepath.Join(bin, sid.Name(), f.Name())); ok {
					items = append(items, it)
				}
			}
		}

		label := "Bin " + d.Letter
		if len(items) == 0 {
			if !lastChange.Before(boot) {
				row("WARN", label, "empty", "emptied since last boot  ·  "+ago(lastChange))
			} else {
				row("OK", label, "empty", "last change "+ago(lastChange))
			}
			continue
		}
		row("INFO", label, fmt.Sprintf("%d item(s)", len(items)), "last change "+ago(lastChange))
		sort.Slice(items, func(i, j int) bool { return items[i].deleted.After(items[j].deleted) })
		for i, it := range items {
			if i == 6 {
				sub(fmt.Sprintf("... and %d more", len(items)-6), "DarkGray")
				break
			}
			color := "DarkGray"
			if riskyExt.MatchString(it.name) {
				color = "Yellow"
			}
			sub(fmt.Sprintf("%s  %s  (%s)", it.deleted.Format("01-02 15:04"), it.name, sizeText(float64(it.size))), color)
		}
	}
	if !anyBin {
		row("WARN", "Recycle bin", "not found on any drive", "")
	}
}

func checkHistory(boot time.Time) {
	section("PowerShell history")
	path := filepath.Join(os.Getenv("APPDATA"), `Microsoft\Windows\PowerShell\PSReadLine\ConsoleHost_history.txt`)
	info, err := os.Stat(path)
	if err != nil {
		row("INFO", "History file", "not found", "never used, or deleted")
		return
	}
	lines := 0
	if b, err := os.ReadFile(path); err == nil {
		lines = strings.Count(string(b), "\n")
		if len(b) > 0 && b[len(b)-1] != '\n' {
			lines++
		}
	}
	row("INFO", "History file", fmt.Sprintf("%d commands", lines),
		fmt.Sprintf("%s  ·  modified %s", sizeText(float64(info.Size())), ago(info.ModTime())))
	hidden, ro, created := fileAttrs(info)
	if hidden || ro {
		var a []string
		if hidden {
			a = append(a, "hidden")
		}
		if ro {
			a = append(a, "read-only")
		}
		row("WARN", "Attributes", strings.Join(a, ", "), "hidden or read-only history file")
	} else {
		row("OK", "Attributes", "normal", "")
	}
	if !created.IsZero() && !created.Before(boot) {
		row("WARN", "Created", ts(created), "history file is newer than the last boot")
	}
}
