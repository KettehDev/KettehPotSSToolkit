// Memory Strings: the "string check" SSers do by hand in System Informer, done automatically.
// javaw  -> cheat client names still sitting in Minecraft's memory
// DPS / PcaSvc / explorer -> exes and jars that ran or were opened this session
package main

import (
	"fmt"
	"path/filepath"
	"regexp"
	"sort"
	"strings"
	"time"
	"unicode/utf16"
)

type needle struct {
	text  string
	level string // FAIL = client name, WARN = module name (can show up in chat)
	label string
}

// distinctive client names and packages: these don't show up in a clean game
var clientNeedles = []needle{
	{"meteordevelopment", "FAIL", "Meteor Client"}, {"meteor-client", "FAIL", "Meteor Client"},
	{"net/wurstclient", "FAIL", "Wurst"}, {"wurstclient", "FAIL", "Wurst"},
	{"net/ccbluex", "FAIL", "LiquidBounce"}, {"liquidbounce", "FAIL", "LiquidBounce"},
	{"thunderhack", "FAIL", "ThunderHack"}, {"rusherhack", "FAIL", "RusherHack"},
	{"bleachhack", "FAIL", "BleachHack"}, {"clickcrystals", "FAIL", "ClickCrystals"},
	{"aristois", "FAIL", "Aristois"}, {"impactclient", "FAIL", "Impact"},
	{"kamiblue", "FAIL", "KAMI Blue"}, {"lambda-client", "FAIL", "Lambda"},
	{"boze.dev", "FAIL", "Boze"}, {"bozeclient", "FAIL", "Boze"},
	{"novoline", "FAIL", "Novoline"}, {"prestigeclient", "FAIL", "Prestige"},
	{"argon client", "FAIL", "Argon"}, {"argonclient", "FAIL", "Argon"},
	{"krypton client", "FAIL", "Krypton"}, {"kryptonclient", "FAIL", "Krypton"},
	{"doomsdayclient", "FAIL", "Doomsday"}, {"whiteout client", "FAIL", "Whiteout"},
	{"slinky.gg", "FAIL", "Slinky"}, {"vape.gg", "FAIL", "Vape"}, {"manthe.industries", "FAIL", "Vape"},
	{"entropy.club", "FAIL", "Entropy"}, {"drip.lite", "FAIL", "Drip"}, {"dripclient", "FAIL", "Drip"},
	{"virelclient", "FAIL", "Virel"}, {"catalystclient", "FAIL", "Catalyst"},
	{"grimbypass", "FAIL", "Grim bypass"}, {"injector.dll", "FAIL", "injector"},
	{"self destruct", "FAIL", "self-destruct feature (cheat clients)"}, {"selfdestruct", "FAIL", "self-destruct feature (cheat clients)"},
	// module names: suspicious, but can appear in chat / anticheat alerts
	{"killaura", "WARN", "KillAura module"}, {"triggerbot", "WARN", "TriggerBot module"},
	{"aimassist", "WARN", "AimAssist module"}, {"autocrystal", "WARN", "AutoCrystal module"},
	{"crystalaura", "WARN", "CrystalAura module"}, {"anchoraura", "WARN", "AnchorAura module"},
	{"autoanchor", "WARN", "AutoAnchor module"}, {"autototem", "WARN", "AutoTotem module"},
	{"reachmodule", "WARN", "Reach module"},
	{"clickgui", "WARN", "ClickGUI (cheat menu)"}, {"autoclicker", "WARN", "autoclicker"},
}

// ---------------------------------------------------------------- multi-needle search

var lower [256]byte

func init() {
	for i := range lower {
		lower[i] = byte(i)
		if i >= 'A' && i <= 'Z' {
			lower[i] = byte(i + 32)
		}
	}
}

type matcher struct {
	pats  [][]byte // lowercase; utf-16 versions after the ascii ones
	ref   []int    // pattern -> needle index
	wide  []bool
	first [65536][]int32
}

func newMatcher(ns []needle) *matcher {
	m := &matcher{}
	add := func(p []byte, i int, wide bool) {
		k := int(p[0])<<8 | int(p[1])
		m.first[k] = append(m.first[k], int32(len(m.pats)))
		m.pats = append(m.pats, p)
		m.ref = append(m.ref, i)
		m.wide = append(m.wide, wide)
	}
	for i, n := range ns {
		a := []byte(strings.ToLower(n.text))
		add(a, i, false)
		w := make([]byte, 0, len(a)*2)
		for _, c := range a {
			w = append(w, c, 0)
		}
		add(w, i, true)
	}
	return m
}

// scan calls hit(needle index, offset) for every match in b.
func (m *matcher) scan(b []byte, hit func(int, int)) {
	if len(b) < 2 {
		return
	}
	prev := lower[b[0]]
	for i := 1; i < len(b); i++ {
		cur := lower[b[i]]
		list := m.first[int(prev)<<8|int(cur)]
		prev = cur
		if list == nil {
			continue
		}
		start := i - 1
		for _, pi := range list {
			p := m.pats[pi]
			if start+len(p) > len(b) {
				continue
			}
			ok := true
			for j := 2; j < len(p); j++ {
				if lower[b[start+j]] != p[j] {
					ok = false
					break
				}
			}
			if ok {
				hit(m.ref[pi], start)
			}
		}
	}
}

// context returns the readable text around a hit (ascii or utf-16).
func context(b []byte, at int, wide bool) string {
	step := 1
	if wide {
		step = 2
	}
	printable := func(i int) bool {
		if i < 0 || i+step-1 >= len(b) {
			return false
		}
		c := b[i]
		if wide && b[i+1] != 0 {
			return false
		}
		return c >= 0x20 && c < 0x7f
	}
	s := at
	for n := 0; n < 60 && printable(s-step); n++ {
		s -= step
	}
	e := at
	for n := 0; n < 120 && printable(e); n++ {
		e += step
	}
	var out []byte
	for i := s; i < e; i += step {
		out = append(out, b[i])
	}
	return string(out)
}

// ---------------------------------------------------------------- string extraction (DPS / PcaSvc / explorer)

var (
	rePathStr = regexp.MustCompile(`(?i)[a-z]:\\[^<>"|?*\x00-\x1f]{1,240}?\.(exe|jar|dll|bat|cmd|ahk|ps1|vbs|py)\b`)
	reDPS     = regexp.MustCompile(`!!([^!\\]{1,120}\.exe)!(\d{4}/\d\d/\d\d:\d\d:\d\d:\d\d)`)
)

// extractStrings pulls printable ascii + utf-16 runs (len >= min) out of a buffer.
// Only runs holding a backslash or "!" are kept, which is every path and every DPS entry.
func extractStrings(b []byte, min int, fn func(string)) {
	// ascii
	start, keep := -1, false
	for i := 0; i <= len(b); i++ {
		ok := i < len(b) && b[i] >= 0x20 && b[i] < 0x7f
		if ok {
			if start < 0 {
				start, keep = i, false
			}
			if b[i] == '\\' || b[i] == '!' {
				keep = true
			}
			continue
		}
		if start >= 0 && keep && i-start >= min {
			fn(string(b[start:i]))
		}
		start = -1
	}
	// utf-16le, both alignments
	for align := 0; align < 2; align++ {
		run := make([]uint16, 0, 256)
		keep := false
		flush := func() {
			if keep && len(run) >= min {
				fn(string(utf16.Decode(run)))
			}
			run, keep = run[:0], false
		}
		for i := align; i+1 < len(b); i += 2 {
			c := uint16(b[i]) | uint16(b[i+1])<<8
			if c >= 0x20 && c < 0xd800 && c != 0xfffe && c != 0xffff {
				if len(run) < 4096 {
					run = append(run, c)
				}
				if c == '\\' || c == '!' {
					keep = true
				}
				continue
			}
			flush()
		}
		flush()
	}
}

type memPath struct {
	path    string
	when    string // DPS gives a timestamp
	sources map[string]bool
}

// ---------------------------------------------------------------- the tool

func runMemory() {
	scanJavaw()
	section("Windows services  ·  programs seen this session")
	paths := map[string]*memPath{}
	addPath := func(p, src, when string) {
		p = strings.TrimSpace(p)
		key := strings.ToLower(p)
		mp, ok := paths[key]
		if !ok {
			mp = &memPath{path: p, sources: map[string]bool{}}
			paths[key] = mp
		}
		mp.sources[src] = true
		if when != "" && mp.when == "" {
			mp.when = when
		}
	}
	targets := []struct{ label, svc, proc string }{
		{"DPS", "DPS", ""},
		{"PcaSvc", "PcaSvc", ""},
		{"explorer", "", "explorer.exe"},
	}
	for _, t := range targets {
		var pid uint32
		if t.svc != "" {
			if info, ok := queryService(t.svc); ok && info.State == stateRunning {
				pid = info.PID
			}
		} else {
			for _, p := range listProcesses() {
				if strings.EqualFold(p.Name, t.proc) {
					pid = p.PID
					break
				}
			}
		}
		if pid == 0 {
			row("WARN", t.label, "not running", "can't read its memory")
			continue
		}
		started := time.Now()
		found := 0
		read, err := memWalk(pid, 768<<20, func(b []byte) bool {
			extractStrings(b, 8, func(s string) {
				for _, m := range reDPS.FindAllStringSubmatch(s, -1) {
					addPath(m[1], t.label, m[2])
					found++
				}
				for _, m := range rePathStr.FindAllString(s, -1) {
					addPath(m, t.label, "")
					found++
				}
			})
			return true
		})
		if err != nil {
			row("WARN", t.label, "couldn't read its memory", "run the toolkit as admin")
			continue
		}
		row("INFO", t.label, fmt.Sprintf("%d paths", found), fmt.Sprintf("%s read in %.1fs  ·  pid %d", sizeText(float64(read)), time.Since(started).Seconds(), pid))
	}

	// judge
	var list []*memPath
	for _, p := range paths {
		list = append(list, p)
	}
	sort.Slice(list, func(i, j int) bool { return strings.ToLower(list[i].path) < strings.ToLower(list[j].path) })
	bad := 0
	for _, p := range list {
		name := filepath.Base(strings.ReplaceAll(p.path, `\`, "/"))
		var srcs []string
		for s := range p.sources {
			srcs = append(srcs, s)
		}
		sort.Strings(srcs)
		extra := strings.Join(srcs, " + ")
		if p.when != "" {
			extra += " · ran " + p.when
		}
		full := len(p.path) > 2 && p.path[1] == ':'
		gone := full && !exists(p.path)
		fl := exeFlags(name)
		lowp := strings.ToLower(p.path)
		switch {
		case len(fl) > 0:
			bad++
			row(fl[0].level, cut(name, 24), fl[0].label, extra)
			sub(p.path, "DarkGray")
		case gone && (strings.HasSuffix(lowp, ".exe") || strings.HasSuffix(lowp, ".jar") || strings.HasSuffix(lowp, ".ahk")) && reUserDirs.MatchString(p.path):
			bad++
			row("WARN", cut(name, 24), "ran this session, file gone now", extra)
			sub(p.path, "DarkGray")
		case gone && strings.HasSuffix(lowp, ".jar"):
			bad++
			row("WARN", cut(name, 24), "jar opened this session, gone now", extra)
			sub(p.path, "DarkGray")
		default:
			report.WriteString(fmt.Sprintf("   seen  %-60s %s\r\n", p.path, extra))
		}
	}
	if bad == 0 {
		row("OK", "Deleted / flagged paths", "none", fmt.Sprintf("%d paths checked (all listed in the saved report)", len(list)))
	}
}

func scanJavaw() {
	section("Minecraft memory  ·  cheat strings")
	var pids []procInfo
	for _, p := range listProcesses() {
		if strings.EqualFold(p.Name, "javaw.exe") {
			pids = append(pids, p)
		}
	}
	if len(pids) == 0 {
		row("WARN", "javaw.exe", "not running", "open Minecraft and run this again")
		return
	}
	m := newMatcher(clientNeedles)
	for _, p := range pids {
		hits := map[int]int{}
		samples := map[int]string{}
		started := time.Now()
		outln(fmt.Sprintf("   scanning javaw (pid %d), this can take a bit...", p.PID), "DarkGray")
		read, err := memWalk(p.PID, 6<<30, func(b []byte) bool {
			m.scan(b, func(ni, at int) {
				hits[ni]++
				if _, ok := samples[ni]; !ok {
					wide := at+1 < len(b) && b[at+1] == 0
					samples[ni] = context(b, at, wide)
				}
			})
			return true
		})
		if err != nil {
			row("WARN", fmt.Sprintf("javaw %d", p.PID), "couldn't read its memory", "run the toolkit as admin")
			continue
		}
		row("INFO", fmt.Sprintf("javaw %d", p.PID), sizeText(float64(read))+" scanned", fmt.Sprintf("%.1fs", time.Since(started).Seconds()))
		if len(hits) == 0 {
			row("OK", "Cheat strings", "none found", "")
			continue
		}
		var idx []int
		for i := range hits {
			idx = append(idx, i)
		}
		sort.Slice(idx, func(a, b int) bool {
			if clientNeedles[idx[a]].level != clientNeedles[idx[b]].level {
				return clientNeedles[idx[a]].level == "FAIL"
			}
			return hits[idx[a]] > hits[idx[b]]
		})
		for _, i := range idx {
			n := clientNeedles[i]
			row(n.level, cut(n.label, 24), fmt.Sprintf("\"%s\" found %dx", n.text, hits[i]), "")
			sub(cut(samples[i], 100), "DarkGray")
		}
	}
}
