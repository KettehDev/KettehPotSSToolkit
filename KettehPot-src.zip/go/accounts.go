// Accounts: every Minecraft account this PC has used, from launcher account files and old game logs.
// Only Minecraft names are read, never emails or login tokens.
package main

import (
	"bufio"
	"compress/gzip"
	"encoding/json"
	"fmt"
	"io"
	"os"
	"path/filepath"
	"regexp"
	"sort"
	"strings"
	"time"
)

var reMCName = regexp.MustCompile(`^[A-Za-z0-9_]{3,16}$`)

type mcAccount struct {
	name     string
	sources  map[string]bool
	lastSeen time.Time
}

type accountBook struct{ m map[string]*mcAccount }

func (b *accountBook) add(name, source string, when time.Time) {
	if !reMCName.MatchString(name) {
		return
	}
	key := strings.ToLower(name)
	a, ok := b.m[key]
	if !ok {
		a = &mcAccount{name: name, sources: map[string]bool{}}
		b.m[key] = a
	}
	a.sources[source] = true
	if when.After(a.lastSeen) {
		a.lastSeen = when
	}
}

// names pulls Minecraft names out of a launcher account file: values under these keys only.
func jsonNames(v any, keys map[string]bool, out *[]string) {
	switch x := v.(type) {
	case map[string]any:
		for k, val := range x {
			if s, ok := val.(string); ok && keys[k] {
				*out = append(*out, s)
			}
			jsonNames(val, keys, out)
		}
	case []any:
		for _, val := range x {
			jsonNames(val, keys, out)
		}
	}
}

func readAccountFile(b *accountBook, path, source string, keys ...string) {
	data, err := os.ReadFile(path)
	if err != nil {
		return
	}
	var v any
	if json.Unmarshal(data, &v) != nil {
		return
	}
	ks := map[string]bool{}
	for _, k := range keys {
		ks[k] = true
	}
	var names []string
	jsonNames(v, ks, &names)
	when := time.Time{}
	if st, err := os.Stat(path); err == nil {
		when = st.ModTime()
	}
	for _, n := range names {
		b.add(n, source, when)
	}
}

var reSettingUser = regexp.MustCompile(`Setting user: (\w{3,16})`)

// logNames finds "Setting user: X" in latest.log and the zipped logs next to it.
func logNames(b *accountBook, logsDir, source string) {
	entries, err := os.ReadDir(logsDir)
	if err != nil {
		return
	}
	type lf struct {
		path string
		mod  time.Time
	}
	var files []lf
	for _, e := range entries {
		n := strings.ToLower(e.Name())
		if e.IsDir() || !(strings.HasSuffix(n, ".log") || strings.HasSuffix(n, ".log.gz")) {
			continue
		}
		if info, err := e.Info(); err == nil {
			files = append(files, lf{filepath.Join(logsDir, e.Name()), info.ModTime()})
		}
	}
	sort.Slice(files, func(i, j int) bool { return files[i].mod.After(files[j].mod) })
	if len(files) > 150 {
		files = files[:150] // newest 150 sessions is plenty
	}
	for _, f := range files {
		fh, err := os.Open(f.path)
		if err != nil {
			continue
		}
		var r io.Reader = fh
		if strings.HasSuffix(strings.ToLower(f.path), ".gz") {
			gz, err := gzip.NewReader(fh)
			if err != nil {
				fh.Close()
				continue
			}
			r = gz
		}
		sc := bufio.NewScanner(io.LimitReader(r, 256<<10)) // the user line is near the top
		sc.Buffer(make([]byte, 64<<10), 1<<20)
		for sc.Scan() {
			if m := reSettingUser.FindStringSubmatch(sc.Text()); m != nil {
				b.add(m[1], source+" logs", f.mod)
				break
			}
		}
		fh.Close()
	}
}

func runAccounts() {
	b := &accountBook{m: map[string]*mcAccount{}}
	ad, home := appData(), homeDir()

	// launcher account files (names only)
	readAccountFile(b, filepath.Join(ad, ".minecraft", "launcher_accounts.json"), "Minecraft Launcher", "name")
	readAccountFile(b, filepath.Join(ad, ".minecraft", "launcher_accounts_microsoft_store.json"), "Minecraft Launcher", "name")
	for _, l := range []struct{ dir, name string }{
		{filepath.Join(ad, "PrismLauncher"), "Prism"}, {filepath.Join(ad, "PolyMC"), "PolyMC"},
		{filepath.Join(home, "MultiMC"), "MultiMC"}, {filepath.Join(home, "Desktop", "MultiMC"), "MultiMC"},
	} {
		readAccountFile(b, filepath.Join(l.dir, "accounts.json"), l.name, "name")
	}
	readAccountFile(b, filepath.Join(home, ".lunarclient", "settings", "game", "accounts.json"), "Lunar", "username", "name")
	readAccountFile(b, filepath.Join(ad, ".feather", "accounts.json"), "Feather", "username", "name")
	readAccountFile(b, filepath.Join(ad, ".minecraft", "TlauncherProfiles.json"), "TLauncher", "displayName")

	// every instance's logs
	for _, in := range findInstances() {
		logNames(b, filepath.Join(in.gameDir, "logs"), in.launcher)
	}
	logNames(b, filepath.Join(home, ".lunarclient", "logs", "game"), "Lunar")

	var list []*mcAccount
	for _, a := range b.m {
		list = append(list, a)
	}
	sort.Slice(list, func(i, j int) bool { return list[i].lastSeen.After(list[j].lastSeen) })

	section("Minecraft accounts used on this PC")
	if len(list) == 0 {
		row("INFO", "Accounts", "none found", "no launcher account files or logs")
		return
	}
	for _, a := range list {
		noteAccount(a.name)
		var src []string
		for s := range a.sources {
			src = append(src, s)
		}
		sort.Strings(src)
		when := "never played?"
		if !a.lastSeen.IsZero() {
			when = "last seen " + ago(a.lastSeen)
		}
		row("INFO", a.name, cut(strings.Join(src, ", "), 44), when)
	}
	if len(list) > 1 {
		row("WARN", "More than one account", fmt.Sprintf("%d accounts", len(list)), "check the others for bans (alts)")
	}
}
