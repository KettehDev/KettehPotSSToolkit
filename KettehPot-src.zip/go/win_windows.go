//go:build windows

package main

import (
	"encoding/binary"
	"errors"
	"os"
	"path/filepath"
	"strconv"
	"strings"
	"syscall"
	"time"
	"unsafe"
)

var (
	kernel32 = syscall.NewLazyDLL("kernel32.dll")
	advapi32 = syscall.NewLazyDLL("advapi32.dll")
	shell32  = syscall.NewLazyDLL("shell32.dll")
	ole32    = syscall.NewLazyDLL("ole32.dll")
	wevtapi  = syscall.NewLazyDLL("wevtapi.dll")
	ntdll    = syscall.NewLazyDLL("ntdll.dll")

	procGetTickCount64             = kernel32.NewProc("GetTickCount64")
	procGetLogicalDrives           = kernel32.NewProc("GetLogicalDrives")
	procGetDriveTypeW              = kernel32.NewProc("GetDriveTypeW")
	procGetVolumeInformationW      = kernel32.NewProc("GetVolumeInformationW")
	procGetDiskFreeSpaceExW        = kernel32.NewProc("GetDiskFreeSpaceExW")
	procSetErrorMode               = kernel32.NewProc("SetErrorMode")
	procQueryDosDeviceW            = kernel32.NewProc("QueryDosDeviceW")
	procOpenFileById               = kernel32.NewProc("OpenFileById")
	procGetFinalPathNameByHandleW  = kernel32.NewProc("GetFinalPathNameByHandleW")
	procQueryFullProcessImageNameW = kernel32.NewProc("QueryFullProcessImageNameW")
	procModule32FirstW             = kernel32.NewProc("Module32FirstW")
	procModule32NextW              = kernel32.NewProc("Module32NextW")

	procOpenSCManagerW       = advapi32.NewProc("OpenSCManagerW")
	procOpenServiceW         = advapi32.NewProc("OpenServiceW")
	procQueryServiceStatusEx = advapi32.NewProc("QueryServiceStatusEx")
	procQueryServiceConfigW  = advapi32.NewProc("QueryServiceConfigW")
	procCloseServiceHandle   = advapi32.NewProc("CloseServiceHandle")
	procGetUserNameW         = advapi32.NewProc("GetUserNameW")
	procRegEnumValueW        = advapi32.NewProc("RegEnumValueW")

	procEvtQuery  = wevtapi.NewProc("EvtQuery")
	procEvtNext   = wevtapi.NewProc("EvtNext")
	procEvtRender = wevtapi.NewProc("EvtRender")
	procEvtClose  = wevtapi.NewProc("EvtClose")

	procRtlGetCompressionWorkSpaceSize = ntdll.NewProc("RtlGetCompressionWorkSpaceSize")
	procRtlDecompressBufferEx          = ntdll.NewProc("RtlDecompressBufferEx")
	procNtQueryInformationProcess      = ntdll.NewProc("NtQueryInformationProcess")
)

func utf16Ptr(s string) *uint16 { p, _ := syscall.UTF16PtrFromString(s); return p }

// ---------------------------------------------------------------- console

func setupConsole(title string) bool {
	kernel32.NewProc("SetConsoleOutputCP").Call(65001)
	kernel32.NewProc("SetConsoleCP").Call(65001)
	kernel32.NewProc("SetConsoleTitleW").Call(uintptr(unsafe.Pointer(utf16Ptr(title))))
	// don't pop "no disk in drive" dialogs when touching empty card readers
	procSetErrorMode.Call(0x0001 | 0x8000)
	h, err := syscall.GetStdHandle(syscall.STD_OUTPUT_HANDLE)
	if err != nil {
		return false
	}
	var mode uint32
	if r, _, _ := kernel32.NewProc("GetConsoleMode").Call(uintptr(h), uintptr(unsafe.Pointer(&mode))); r == 0 {
		return false
	}
	r, _, _ := kernel32.NewProc("SetConsoleMode").Call(uintptr(h), uintptr(mode|0x0004))
	return r != 0
}

func isAdmin() bool {
	f, err := os.Open(`\\.\PHYSICALDRIVE0`)
	if err != nil {
		return false
	}
	f.Close()
	return true
}

func currentUser() string {
	buf := make([]uint16, 257)
	n := uint32(len(buf))
	if r, _, _ := procGetUserNameW.Call(uintptr(unsafe.Pointer(&buf[0])), uintptr(unsafe.Pointer(&n))); r != 0 {
		return syscall.UTF16ToString(buf)
	}
	return os.Getenv("USERNAME")
}

// ---------------------------------------------------------------- system

func bootTime() time.Time {
	ms, _, _ := procGetTickCount64.Call()
	return time.Now().Add(-time.Duration(ms) * time.Millisecond).Truncate(time.Second)
}

func osInfo() (string, string) {
	const cv = `SOFTWARE\Microsoft\Windows NT\CurrentVersion`
	name, _ := regString(hklm, cv, "ProductName")
	build, _ := regString(hklm, cv, "CurrentBuild")
	if b, err := strconv.Atoi(build); err == nil && b >= 22000 {
		name = strings.Replace(name, "Windows 10", "Windows 11", 1)
	}
	if dv, ok := regString(hklm, cv, "DisplayVersion"); ok && name != "" {
		name += " " + dv
	}
	return name, build
}

// ---------------------------------------------------------------- registry

func openKey(root regRoot, path string) (syscall.Handle, bool) {
	r := syscall.Handle(syscall.HKEY_CURRENT_USER)
	if root == hklm {
		r = syscall.Handle(syscall.HKEY_LOCAL_MACHINE)
	}
	var k syscall.Handle
	if syscall.RegOpenKeyEx(r, utf16Ptr(path), 0, syscall.KEY_READ, &k) != nil {
		return 0, false
	}
	return k, true
}

func regString(root regRoot, path, name string) (string, bool) {
	k, ok := openKey(root, path)
	if !ok {
		return "", false
	}
	defer syscall.RegCloseKey(k)
	var typ, n uint32
	if syscall.RegQueryValueEx(k, utf16Ptr(name), nil, &typ, nil, &n) != nil || n == 0 {
		return "", false
	}
	buf := make([]uint16, n/2+1)
	if syscall.RegQueryValueEx(k, utf16Ptr(name), nil, &typ, (*byte)(unsafe.Pointer(&buf[0])), &n) != nil {
		return "", false
	}
	if typ != syscall.REG_SZ && typ != syscall.REG_EXPAND_SZ {
		return "", false
	}
	return syscall.UTF16ToString(buf), true
}

func regDWORD(root regRoot, path, name string) (uint32, bool) {
	k, ok := openKey(root, path)
	if !ok {
		return 0, false
	}
	defer syscall.RegCloseKey(k)
	var typ, v uint32
	n := uint32(4)
	if syscall.RegQueryValueEx(k, utf16Ptr(name), nil, &typ, (*byte)(unsafe.Pointer(&v)), &n) != nil || typ != syscall.REG_DWORD {
		return 0, false
	}
	return v, true
}

// regSubkeys lists subkey names; ok=false when the key can't be opened.
func regSubkeys(root regRoot, path string) ([]string, bool) {
	k, ok := openKey(root, path)
	if !ok {
		return nil, false
	}
	defer syscall.RegCloseKey(k)
	var out []string
	for i := uint32(0); ; i++ {
		buf := make([]uint16, 512)
		n := uint32(len(buf))
		if syscall.RegEnumKeyEx(k, i, &buf[0], &n, nil, nil, nil, nil) != nil {
			break
		}
		out = append(out, syscall.UTF16ToString(buf[:n]))
	}
	return out, true
}

func regValues(root regRoot, path string) ([]regValue, bool) {
	k, ok := openKey(root, path)
	if !ok {
		return nil, false
	}
	defer syscall.RegCloseKey(k)
	var out []regValue
	name := make([]uint16, 32768)
	data := make([]byte, 64*1024)
	for i := uint32(0); i < 100000; i++ {
		nn := uint32(len(name))
		dn := uint32(len(data))
		var typ uint32
		r, _, _ := procRegEnumValueW.Call(uintptr(k), uintptr(i), uintptr(unsafe.Pointer(&name[0])), uintptr(unsafe.Pointer(&nn)),
			0, uintptr(unsafe.Pointer(&typ)), uintptr(unsafe.Pointer(&data[0])), uintptr(unsafe.Pointer(&dn)))
		if r == 234 { // ERROR_MORE_DATA
			data = make([]byte, dn+16)
			i--
			continue
		}
		if r != 0 {
			break
		}
		out = append(out, regValue{syscall.UTF16ToString(name[:nn]), typ, append([]byte(nil), data[:dn]...)})
	}
	return out, true
}

func sidToName(sid string) string {
	s, err := syscall.StringToSid(sid)
	if err != nil {
		return ""
	}
	acc, dom, _, err := s.LookupAccount("")
	if err != nil {
		return ""
	}
	if dom != "" {
		return dom + `\` + acc
	}
	return acc
}

// ---------------------------------------------------------------- drives

func driveRoot(letter string) string { return letter + `\` }

func driveLetters() []string {
	mask, _, _ := procGetLogicalDrives.Call()
	var out []string
	for i := 0; i < 26; i++ {
		if mask&(1<<uint(i)) != 0 {
			out = append(out, string(rune('A'+i))+":")
		}
	}
	return out
}

func driveType(letter string) int {
	t, _, _ := procGetDriveTypeW.Call(uintptr(unsafe.Pointer(utf16Ptr(driveRoot(letter)))))
	return int(t)
}

func listDrives() []driveInfo {
	var out []driveInfo
	for _, letter := range driveLetters() {
		t := driveType(letter)
		if t == driveCDROM || t < 2 {
			continue
		}
		root := utf16Ptr(driveRoot(letter))
		d := driveInfo{Letter: letter, Type: t}
		vol := make([]uint16, 261)
		fs := make([]uint16, 261)
		if r, _, _ := procGetVolumeInformationW.Call(uintptr(unsafe.Pointer(root)),
			uintptr(unsafe.Pointer(&vol[0])), 261, 0, 0, 0, uintptr(unsafe.Pointer(&fs[0])), 261); r != 0 {
			d.Label = syscall.UTF16ToString(vol)
			d.FS = syscall.UTF16ToString(fs)
		}
		var avail, total, free uint64
		if r, _, _ := procGetDiskFreeSpaceExW.Call(uintptr(unsafe.Pointer(root)),
			uintptr(unsafe.Pointer(&avail)), uintptr(unsafe.Pointer(&total)), uintptr(unsafe.Pointer(&free))); r != 0 {
			d.Free, d.Total = free, total
		}
		out = append(out, d)
	}
	return out
}

// deviceMap: `\device\harddiskvolume3` -> "C:"
func deviceMap() map[string]string {
	m := map[string]string{}
	for _, letter := range driveLetters() {
		buf := make([]uint16, 1024)
		r, _, _ := procQueryDosDeviceW.Call(uintptr(unsafe.Pointer(utf16Ptr(letter))), uintptr(unsafe.Pointer(&buf[0])), uintptr(len(buf)))
		if r != 0 {
			m[strings.ToLower(syscall.UTF16ToString(buf))] = letter
		}
	}
	return m
}

// volumeSerials: volume serial number -> "C:" (prefetch paths use \VOLUME{created-serial})
func volumeSerials() map[uint32]string {
	m := map[uint32]string{}
	for _, letter := range driveLetters() {
		t := driveType(letter)
		if t == driveCDROM || t < 2 {
			continue
		}
		var serial uint32
		if r, _, _ := procGetVolumeInformationW.Call(uintptr(unsafe.Pointer(utf16Ptr(driveRoot(letter)))),
			0, 0, uintptr(unsafe.Pointer(&serial)), 0, 0, 0, 0); r != 0 {
			m[serial] = letter
		}
	}
	return m
}

// ---------------------------------------------------------------- services

func queryService(name string) (svcInfo, bool) {
	scm, _, _ := procOpenSCManagerW.Call(0, 0, 0x0001)
	if scm == 0 {
		return svcInfo{}, false
	}
	defer procCloseServiceHandle.Call(scm)
	svc, _, _ := procOpenServiceW.Call(scm, uintptr(unsafe.Pointer(utf16Ptr(name))), 0x0001|0x0004)
	if svc == 0 {
		return svcInfo{}, false
	}
	defer procCloseServiceHandle.Call(svc)
	var st [9]uint32
	var need uint32
	if r, _, _ := procQueryServiceStatusEx.Call(svc, 0, uintptr(unsafe.Pointer(&st[0])), unsafe.Sizeof(st), uintptr(unsafe.Pointer(&need))); r == 0 {
		return svcInfo{}, false
	}
	info := svcInfo{State: int(st[1]), PID: st[7], StartType: -1}
	buf := make([]byte, 8192)
	if r, _, _ := procQueryServiceConfigW.Call(svc, uintptr(unsafe.Pointer(&buf[0])), uintptr(len(buf)), uintptr(unsafe.Pointer(&need))); r != 0 {
		info.StartType = int(*(*uint32)(unsafe.Pointer(&buf[4])))
	}
	return info, true
}

// ---------------------------------------------------------------- processes

func processStart(pid uint32) (time.Time, bool) {
	if pid == 0 {
		return time.Time{}, false
	}
	h, err := syscall.OpenProcess(0x1000, false, pid)
	if err != nil {
		return time.Time{}, false
	}
	defer syscall.CloseHandle(h)
	var c, e, k, u syscall.Filetime
	if syscall.GetProcessTimes(h, &c, &e, &k, &u) != nil {
		return time.Time{}, false
	}
	return time.Unix(0, c.Nanoseconds()), true
}

func listProcesses() []procInfo {
	snap, err := syscall.CreateToolhelp32Snapshot(syscall.TH32CS_SNAPPROCESS, 0)
	if err != nil {
		return nil
	}
	defer syscall.CloseHandle(snap)
	var e syscall.ProcessEntry32
	e.Size = uint32(unsafe.Sizeof(e))
	var out []procInfo
	for err = syscall.Process32First(snap, &e); err == nil; err = syscall.Process32Next(snap, &e) {
		out = append(out, procInfo{e.ProcessID, e.ParentProcessID, syscall.UTF16ToString(e.ExeFile[:])})
	}
	return out
}

func processImage(pid uint32) string {
	h, err := syscall.OpenProcess(0x1000, false, pid)
	if err != nil {
		return ""
	}
	defer syscall.CloseHandle(h)
	buf := make([]uint16, 32768)
	n := uint32(len(buf))
	if r, _, _ := procQueryFullProcessImageNameW.Call(uintptr(h), 0, uintptr(unsafe.Pointer(&buf[0])), uintptr(unsafe.Pointer(&n))); r == 0 {
		return ""
	}
	return syscall.UTF16ToString(buf[:n])
}

func processCmdline(pid uint32) string {
	h, err := syscall.OpenProcess(0x1000, false, pid)
	if err != nil {
		return ""
	}
	defer syscall.CloseHandle(h)
	size := uint32(64 * 1024)
	for tries := 0; tries < 3; tries++ {
		buf := make([]byte, size)
		var ret uint32
		st, _, _ := procNtQueryInformationProcess.Call(uintptr(h), 60, uintptr(unsafe.Pointer(&buf[0])), uintptr(size), uintptr(unsafe.Pointer(&ret)))
		if st == 0xC0000004 && ret > size { // STATUS_INFO_LENGTH_MISMATCH
			size = ret + 64
			continue
		}
		if st != 0 || ret < 16 {
			return ""
		}
		length := int(binary.LittleEndian.Uint16(buf[0:]))
		ptr := uintptr(binary.LittleEndian.Uint64(buf[8:]))
		base := uintptr(unsafe.Pointer(&buf[0]))
		off := int(ptr - base)
		if ptr < base || off+length > len(buf) {
			return ""
		}
		u := make([]uint16, length/2)
		for i := range u {
			u[i] = binary.LittleEndian.Uint16(buf[off+i*2:])
		}
		return syscall.UTF16ToString(u)
	}
	return ""
}

type moduleEntry32 struct {
	Size         uint32
	ModuleID     uint32
	ProcessID    uint32
	GlblcntUsage uint32
	ProccntUsage uint32
	ModBaseAddr  uintptr
	ModBaseSize  uint32
	HModule      uintptr
	Module       [256]uint16
	ExePath      [260]uint16
}

func processModules(pid uint32) ([]string, bool) {
	var snap syscall.Handle
	var err error
	for tries := 0; tries < 5; tries++ {
		snap, err = syscall.CreateToolhelp32Snapshot(0x8|0x10, pid)
		if err == nil {
			break
		}
		time.Sleep(50 * time.Millisecond)
	}
	if err != nil {
		return nil, false
	}
	defer syscall.CloseHandle(snap)
	var e moduleEntry32
	e.Size = uint32(unsafe.Sizeof(e))
	var out []string
	r, _, _ := procModule32FirstW.Call(uintptr(snap), uintptr(unsafe.Pointer(&e)))
	for r != 0 {
		out = append(out, syscall.UTF16ToString(e.ExePath[:]))
		r, _, _ = procModule32NextW.Call(uintptr(snap), uintptr(unsafe.Pointer(&e)))
	}
	return out, true
}

// ---------------------------------------------------------------- event logs

// queryEvents returns up to max events (newest first) matching an XPath query.
func queryEvents(channel, query string, max int) ([]winEvent, error) {
	return evtQuery(channel, query, max, true)
}

// queryEventsOldest returns the single oldest record still in a log.
func queryEventsOldest(channel string) ([]winEvent, error) {
	return evtQuery(channel, "*", 1, false)
}

func evtQuery(channel, query string, max int, newestFirst bool) ([]winEvent, error) {
	flags := uintptr(0x1) // EvtQueryChannelPath
	if newestFirst {
		flags |= 0x200 // EvtQueryReverseDirection
	}
	rs, _, e := procEvtQuery.Call(0, uintptr(unsafe.Pointer(utf16Ptr(channel))), uintptr(unsafe.Pointer(utf16Ptr(query))), flags)
	if rs == 0 {
		return nil, e
	}
	defer procEvtClose.Call(rs)

	var out []winEvent
	handles := make([]uintptr, 64)
	buf := make([]uint16, 16*1024)
	for len(out) < max {
		var got uint32
		if r, _, _ := procEvtNext.Call(rs, uintptr(len(handles)), uintptr(unsafe.Pointer(&handles[0])), 10000, 0, uintptr(unsafe.Pointer(&got))); r == 0 || got == 0 {
			break
		}
		for i := 0; i < int(got); i++ {
			ev := handles[i]
			var used, props uint32
			r, _, _ := procEvtRender.Call(0, ev, 1, uintptr(len(buf)*2), uintptr(unsafe.Pointer(&buf[0])), uintptr(unsafe.Pointer(&used)), uintptr(unsafe.Pointer(&props)))
			if r == 0 && used > uint32(len(buf)*2) {
				buf = make([]uint16, used/2+16)
				r, _, _ = procEvtRender.Call(0, ev, 1, uintptr(len(buf)*2), uintptr(unsafe.Pointer(&buf[0])), uintptr(unsafe.Pointer(&used)), uintptr(unsafe.Pointer(&props)))
			}
			procEvtClose.Call(ev)
			if r == 0 || len(out) >= max {
				continue
			}
			if we, ok := parseEventXML(syscall.UTF16ToString(buf[:used/2])); ok {
				out = append(out, we)
			}
		}
	}
	return out, nil
}

func lastEvent(channel string, id int, provider string) (time.Time, int, bool) {
	q := "*[System[(EventID=" + strconv.Itoa(id) + ")]]"
	if provider != "" {
		q = "*[System[Provider[@Name='" + provider + "'] and (EventID=" + strconv.Itoa(id) + ")]]"
	}
	evs, err := queryEvents(channel, q, 1)
	if err != nil || len(evs) == 0 {
		return time.Time{}, 0, false
	}
	return evs[0].Time, evs[0].ID, true
}

// ---------------------------------------------------------------- files

func prefetchDir() string {
	root := os.Getenv("SystemRoot")
	if root == "" {
		root = `C:\Windows`
	}
	return filepath.Join(root, "Prefetch")
}

func fileAttrs(info os.FileInfo) (hidden, readOnly bool, created time.Time) {
	if a, ok := info.Sys().(*syscall.Win32FileAttributeData); ok {
		hidden = a.FileAttributes&syscall.FILE_ATTRIBUTE_HIDDEN != 0
		readOnly = a.FileAttributes&syscall.FILE_ATTRIBUTE_READONLY != 0
		created = time.Unix(0, a.CreationTime.Nanoseconds())
	}
	return
}

func readZoneIdentifier(path string) string {
	b, err := os.ReadFile(path + ":Zone.Identifier")
	if err != nil {
		return ""
	}
	return string(b)
}

type guid struct {
	d1     uint32
	d2, d3 uint16
	d4     [8]byte
}

var folderDesktop = guid{0xB4BFCC3A, 0xDB2C, 0x424C, [8]byte{0xB0, 0x29, 0x7F, 0xE9, 0x9A, 0x87, 0xC6, 0x41}}

func desktopDir() string {
	var p *uint16
	r, _, _ := shell32.NewProc("SHGetKnownFolderPath").Call(uintptr(unsafe.Pointer(&folderDesktop)), 0, 0, uintptr(unsafe.Pointer(&p)))
	if r == 0 && p != nil {
		defer ole32.NewProc("CoTaskMemFree").Call(uintptr(unsafe.Pointer(p)))
		n := 0
		for *(*uint16)(unsafe.Add(unsafe.Pointer(p), n*2)) != 0 {
			n++
		}
		if s := syscall.UTF16ToString(unsafe.Slice(p, n)); isDir(s) {
			return s
		}
	}
	if d := filepath.Join(os.Getenv("USERPROFILE"), "Desktop"); isDir(d) {
		return d
	}
	wd, _ := os.Getwd()
	return wd
}

// ---------------------------------------------------------------- prefetch decompression

// decompressMAM unpacks a Windows 10/11 prefetch file ("MAM\x04" + Xpress Huffman).
func decompressMAM(b []byte) ([]byte, error) {
	if len(b) < 8 || string(b[:3]) != "MAM" {
		return b, nil // already plain (Windows 7/8)
	}
	size := binary.LittleEndian.Uint32(b[4:])
	if size == 0 || size > 64<<20 {
		return nil, errors.New("bad size")
	}
	const xpressHuff = 4
	var wsBuf, wsFrag uint32
	if st, _, _ := procRtlGetCompressionWorkSpaceSize.Call(xpressHuff, uintptr(unsafe.Pointer(&wsBuf)), uintptr(unsafe.Pointer(&wsFrag))); st != 0 {
		return nil, errors.New("no workspace size")
	}
	ws := make([]byte, wsFrag+16)
	dst := make([]byte, size)
	var final uint32
	st, _, _ := procRtlDecompressBufferEx.Call(xpressHuff, uintptr(unsafe.Pointer(&dst[0])), uintptr(size),
		uintptr(unsafe.Pointer(&b[8])), uintptr(len(b)-8), uintptr(unsafe.Pointer(&final)), uintptr(unsafe.Pointer(&ws[0])))
	if st != 0 {
		return nil, errors.New("decompress failed: 0x" + strconv.FormatUint(uint64(st), 16))
	}
	return dst[:final], nil
}

// ---------------------------------------------------------------- USN journal

const (
	fsctlQueryUsnJournal = 0x000900f4
	fsctlReadUsnJournal  = 0x000900bb
)

// usnWalk reads every record in a drive's change journal, oldest first.
func usnWalk(letter string, fn func(usnRecord)) (usnJournal, error) {
	h, err := syscall.CreateFile(utf16Ptr(`\\.\`+letter), syscall.GENERIC_READ,
		syscall.FILE_SHARE_READ|syscall.FILE_SHARE_WRITE, nil, syscall.OPEN_EXISTING, 0, 0)
	if err != nil {
		return usnJournal{}, err
	}
	defer syscall.CloseHandle(h)

	q := make([]byte, 80)
	var n uint32
	if err := syscall.DeviceIoControl(h, fsctlQueryUsnJournal, nil, 0, &q[0], uint32(len(q)), &n, nil); err != nil {
		return usnJournal{}, err
	}
	j := usnJournal{
		ID:       binary.LittleEndian.Uint64(q[0:]),
		FirstUsn: int64(binary.LittleEndian.Uint64(q[8:])),
		NextUsn:  int64(binary.LittleEndian.Uint64(q[16:])),
		MaxSize:  binary.LittleEndian.Uint64(q[40:]),
	}

	in := make([]byte, 40)
	buf := make([]byte, 1<<20)
	next := j.FirstUsn
	for next < j.NextUsn {
		binary.LittleEndian.PutUint64(in[0:], uint64(next))
		binary.LittleEndian.PutUint32(in[8:], 0xFFFFFFFF) // every reason
		binary.LittleEndian.PutUint32(in[12:], 0)
		binary.LittleEndian.PutUint64(in[16:], 0)
		binary.LittleEndian.PutUint64(in[24:], 0)
		binary.LittleEndian.PutUint64(in[32:], j.ID)
		if err := syscall.DeviceIoControl(h, fsctlReadUsnJournal, &in[0], uint32(len(in)), &buf[0], uint32(len(buf)), &n, nil); err != nil {
			return j, err
		}
		if n <= 8 {
			break
		}
		nn := int64(binary.LittleEndian.Uint64(buf[0:]))
		parseUSNRecords(buf[8:n], fn)
		if nn <= next {
			break
		}
		next = nn
	}
	return j, nil
}

var (
	idHints = map[string]syscall.Handle{}
	idCache = map[string]string{}
)

// resolveFileRef turns an NTFS file reference into a full path, if it still exists.
func resolveFileRef(letter string, ref uint64) string {
	key := letter + strconv.FormatUint(ref, 16)
	if p, ok := idCache[key]; ok {
		return p
	}
	hint, ok := idHints[letter]
	if !ok {
		var err error
		hint, err = syscall.CreateFile(utf16Ptr(letter+`\`), 0, syscall.FILE_SHARE_READ|syscall.FILE_SHARE_WRITE|syscall.FILE_SHARE_DELETE,
			nil, syscall.OPEN_EXISTING, syscall.FILE_FLAG_BACKUP_SEMANTICS, 0)
		if err != nil {
			hint = 0
		}
		idHints[letter] = hint
	}
	path := ""
	if hint != 0 {
		var desc [24]byte
		binary.LittleEndian.PutUint32(desc[0:], 24)
		binary.LittleEndian.PutUint32(desc[4:], 0) // FileIdType
		binary.LittleEndian.PutUint64(desc[8:], ref)
		h, _, _ := procOpenFileById.Call(uintptr(hint), uintptr(unsafe.Pointer(&desc[0])), 0,
			syscall.FILE_SHARE_READ|syscall.FILE_SHARE_WRITE|syscall.FILE_SHARE_DELETE, 0, syscall.FILE_FLAG_BACKUP_SEMANTICS)
		if h != 0 && h != uintptr(syscall.InvalidHandle) {
			buf := make([]uint16, 1024)
			n, _, _ := procGetFinalPathNameByHandleW.Call(h, uintptr(unsafe.Pointer(&buf[0])), uintptr(len(buf)), 0)
			if n > 0 && int(n) < len(buf) {
				path = strings.TrimPrefix(syscall.UTF16ToString(buf[:n]), `\\?\`)
			}
			syscall.CloseHandle(syscall.Handle(h))
		}
	}
	idCache[key] = path
	return path
}
