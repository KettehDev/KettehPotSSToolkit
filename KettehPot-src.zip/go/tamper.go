// Tamper Check: signs someone cleaned up before the SS.
// Log wipes, journal deletes, clock changes, cleaners, Defender exclusions / detections.
package main

import (
	"fmt"
	"os"
	"path/filepath"
	"regexp"
	"strings"
	"time"
)

const tamperWindow = 7 * 24 * time.Hour

func runTamper() {
	boot := bootTime()
	level := func(t time.Time) string {
		if t.After(boot) || time.Since(t) < 24*time.Hour {
			return "FAIL"
		}
		return "WARN"
	}

	// ---------------- logs cleared
	section("Event logs cleared  ·  last 7 days")
	cleared := 0
	if evs, err := queryEvents("System", sinceQuery(tamperWindow, 104), 50); err == nil {
		for _, e := range evs {
			ch := e.Data["Channel"]
			if ch == "" {
				ch = firstNonEmpty(e.List...)
			}
			who := e.Data["SubjectUserName"]
			cleared++
			row(level(e.Time), "Log cleared", orDash(ch), ts(e.Time)+" · "+ago(e.Time)+userSuffix(who))
		}
	} else {
		row("WARN", "System log", "couldn't read it", "run as admin")
	}
	if evs, err := queryEvents("Security", sinceQuery(tamperWindow, 1102), 50); err == nil {
		for _, e := range evs {
			cleared++
			row(level(e.Time), "Log cleared", "Security", ts(e.Time)+" · "+ago(e.Time))
		}
	}
	if cleared == 0 {
		row("OK", "Logs cleared", "none", "")
	}
	// a log whose oldest record is newer than the boot was emptied some other way
	for _, ch := range []string{"System", "Application", "Windows PowerShell"} {
		if evs, err := queryEventsOldest(ch); err == nil && len(evs) > 0 {
			oldest := evs[0].Time
			if oldest.After(boot) && time.Since(boot) > time.Hour {
				row("FAIL", ch+" log", "starts after boot", "oldest record "+ts(oldest)+" · the log was wiped")
			} else if time.Since(oldest) < 24*time.Hour && time.Since(boot) > 24*time.Hour {
				row("WARN", ch+" log", "only goes back "+ago(oldest), "")
			}
		}
	}

	// ---------------- USN journal deleted
	section("Change journal")
	if evs, err := queryEvents("Application", sinceQuery(tamperWindow, 3079), 20); err == nil && len(evs) > 0 {
		for _, e := range evs {
			row(level(e.Time), "USN journal deleted", ts(e.Time), ago(e.Time)+" · "+cut(firstNonEmpty(e.List...), 40))
		}
	} else {
		row("OK", "USN journal deleted", "no records", "")
	}

	// ---------------- clock changes
	section("System time changes  ·  last 7 days")
	changes := 0
	if evs, err := queryEvents("System", "*[System[Provider[@Name='Microsoft-Windows-Kernel-General'] and EventID=1 and TimeCreated[timediff(@SystemTime) <= "+itoa(int(tamperWindow/time.Millisecond))+"]]]", 200); err == nil {
		for _, e := range evs {
			nt, e1 := time.Parse(time.RFC3339Nano, e.Data["NewTime"])
			ot, e2 := time.Parse(time.RFC3339Nano, e.Data["OldTime"])
			if e1 != nil || e2 != nil {
				continue
			}
			d := nt.Sub(ot)
			if d < 0 {
				d = -d
			}
			if d < 2*time.Minute {
				continue // normal internet time sync
			}
			changes++
			dir := "forward"
			if nt.Before(ot) {
				dir = "BACK"
			}
			lvl := "WARN"
			if nt.Before(ot) && d > 10*time.Minute {
				lvl = "FAIL"
			}
			row(lvl, "Clock moved "+dir, fmtDur(d), ot.Local().Format("01-02 15:04:05")+" -> "+nt.Local().Format("01-02 15:04:05"))
		}
	}
	if evs, err := queryEvents("Security", sinceQuery(tamperWindow, 4616), 200); err == nil {
		for _, e := range evs {
			p := strings.ToLower(e.Data["ProcessName"])
			if strings.HasSuffix(p, `\svchost.exe`) || p == "" {
				continue
			}
			changes++
			row("WARN", "Time set by", filepath.Base(e.Data["ProcessName"]), ts(e.Time)+userSuffix(e.Data["SubjectUserName"]))
		}
	}
	if changes == 0 {
		row("OK", "Clock changes", "none", "only normal syncs")
	}
	if v, ok := regString(hklm, `SYSTEM\CurrentControlSet\Services\W32Time\Parameters`, "Type"); ok && strings.EqualFold(v, "NoSync") {
		row("WARN", "Internet time sync", "turned off", "W32Time Type = NoSync")
	}

	// ---------------- cleaners
	section("Cleaners / anti-forensics tools")
	pf, pf86, la, ad := os.Getenv("ProgramFiles"), os.Getenv("ProgramFiles(x86)"), os.Getenv("LOCALAPPDATA"), appData()
	cleaners := []struct {
		name  string
		paths []string
	}{
		{"CCleaner", []string{filepath.Join(pf, "CCleaner"), filepath.Join(pf86, "CCleaner")}},
		{"BleachBit", []string{filepath.Join(pf, "BleachBit"), filepath.Join(pf86, "BleachBit"), filepath.Join(la, "BleachBit")}},
		{"PrivaZer", []string{filepath.Join(pf, "PrivaZer"), filepath.Join(pf86, "PrivaZer")}},
		{"Wise Care / Wise Disk Cleaner", []string{filepath.Join(pf86, "Wise"), filepath.Join(pf, "Wise")}},
		{"Glary Utilities", []string{filepath.Join(pf86, "Glary Utilities 5"), filepath.Join(pf, "Glary Utilities")}},
		{"Eraser", []string{filepath.Join(pf, "Eraser"), filepath.Join(pf86, "Eraser")}},
		{"Revo Uninstaller", []string{filepath.Join(pf, "VS Revo Group"), filepath.Join(pf86, "VS Revo Group")}},
		{"Advanced SystemCare", []string{filepath.Join(pf86, "IObit", "Advanced SystemCare"), filepath.Join(pf, "IObit", "Advanced SystemCare")}},
		{"RunAsDate", []string{filepath.Join(pf, "RunAsDate"), filepath.Join(pf86, "RunAsDate")}},
		{"Sandboxie", []string{filepath.Join(pf, "Sandboxie"), filepath.Join(pf, "Sandboxie-Plus")}},
	}
	anyCleaner := false
	for _, c := range cleaners {
		for _, p := range c.paths {
			if p == "" || !isDir(p) {
				continue
			}
			anyCleaner = true
			when := newestIn(p, 2)
			lvl, extra := "WARN", p
			if !when.IsZero() && time.Since(when) < 48*time.Hour {
				lvl, extra = "FAIL", "used / updated "+ago(when)+" · "+p
			}
			row(lvl, c.name, "installed", extra)
			break
		}
	}
	// portable copies sitting in user folders
	for _, dir := range []string{filepath.Join(homeDir(), "Downloads"), filepath.Join(homeDir(), "Desktop"), filepath.Join(ad, "..", "Local", "Temp")} {
		walkDepth(dir, 1, func(p string, info os.FileInfo) {
			if !strings.EqualFold(filepath.Ext(p), ".exe") {
				return
			}
			for _, f := range exeFlags(filepath.Base(p)) {
				if strings.Contains(f.label, "cleaner") || strings.Contains(f.label, "time") {
					anyCleaner = true
					row("WARN", cut(filepath.Base(p), 24), f.label, "modified "+ago(info.ModTime()))
					sub(p, "DarkGray")
				}
			}
		})
	}
	if !anyCleaner {
		row("OK", "Cleaners", "none found", "")
	}

	// ---------------- Defender
	section("Windows Defender")
	if v, ok := regDWORD(hklm, `SOFTWARE\Policies\Microsoft\Windows Defender`, "DisableAntiSpyware"); ok && v == 1 {
		row("WARN", "Defender", "disabled by policy", "")
	}
	if v, ok := regDWORD(hklm, `SOFTWARE\Policies\Microsoft\Windows Defender\Real-Time Protection`, "DisableRealtimeMonitoring"); ok && v == 1 {
		row("WARN", "Real-time protection", "disabled by policy", "")
	}
	const defLog = "Microsoft-Windows-Windows Defender/Operational"
	exclusions := 0
	for _, kind := range []string{"Paths", "Processes", "Extensions"} {
		vals, ok := regValues(hklm, `SOFTWARE\Microsoft\Windows Defender\Exclusions\`+kind)
		if !ok {
			continue
		}
		for _, v := range vals {
			exclusions++
			row(exclusionLevel(v.Name), "Exclusion ("+strings.ToLower(kind)+")", cut(v.Name, 50), "")
		}
	}
	// exclusions added recently (also works when the key itself is locked)
	if evs, err := queryEvents(defLog, sinceQuery(tamperWindow, 5007, 5001, 5010, 5012), 300); err == nil {
		for _, e := range evs {
			all := e.all()
			switch e.ID {
			case 5001:
				row(level(e.Time), "Real-time protection", "turned off", ts(e.Time)+" · "+ago(e.Time))
			case 5010, 5012:
				row(level(e.Time), "Defender scanning", "turned off", ts(e.Time)+" · "+ago(e.Time))
			case 5007:
				if m := reExclusionAdd.FindStringSubmatch(e.Data["New Value"] + "\n" + all); m != nil && e.Data["Old Value"] == "" {
					exclusions++
					row(level(e.Time), "Exclusion added", cut(strings.TrimSpace(m[2]), 46), ts(e.Time)+" · "+ago(e.Time))
				}
			}
		}
	} else {
		row("INFO", "Defender log", "couldn't read it", "")
	}
	if exclusions == 0 {
		row("OK", "Exclusions", "none", "")
	}
	// recent detections, cheats often get caught here even after they're deleted
	detections := 0
	if evs, err := queryEvents(defLog, sinceQuery(tamperWindow, 1116, 1117), 100); err == nil {
		seen := map[string]bool{}
		for _, e := range evs {
			threat := e.Data["Threat Name"]
			path := strings.TrimPrefix(e.Data["Path"], "file:_")
			key := threat + path
			if seen[key] {
				continue
			}
			seen[key] = true
			detections++
			lvl := "WARN"
			if reCheatThreat.MatchString(threat + " " + path) {
				lvl = "FAIL"
			}
			row(lvl, "Defender detection", cut(threat, 40), ts(e.Time)+" · "+ago(e.Time))
			if path != "" {
				sub(cut(path, 100), "DarkGray")
			}
		}
	}
	if detections == 0 {
		row("OK", "Detections (7 days)", "none", "")
	}
}

var (
	reExclusionAdd = regexp.MustCompile(`(?i)Exclusions\\(Paths|Processes|Extensions)\\([^=\r\n]+)`)
	reCheatThreat  = regexp.MustCompile(`(?i)hacktool|cheat|inject|gamehack|\.jar|\\mods\\|minecraft|autoclick|riskware`)
	reWideExcl     = regexp.MustCompile(`(?i)^[a-z]:\\?$|\\(downloads|desktop|documents|appdata|temp|users)\\?$|\.minecraft|\\mods|lunarclient|\.feather|modrinth|prism|javaw|java\.exe|\.jar$|^\.?(exe|jar|dll)$`)
)

func exclusionLevel(p string) string {
	if reWideExcl.MatchString(strings.TrimSpace(p)) {
		return "FAIL"
	}
	return "WARN"
}

func firstNonEmpty(xs ...string) string {
	for _, x := range xs {
		if strings.TrimSpace(x) != "" {
			return strings.TrimSpace(x)
		}
	}
	return ""
}

func userSuffix(u string) string {
	if u == "" || u == "-" {
		return ""
	}
	return " · by " + u
}

func fmtDur(d time.Duration) string {
	switch {
	case d >= 24*time.Hour:
		return fmt.Sprintf("%dd %dh", int(d.Hours())/24, int(d.Hours())%24)
	case d >= time.Hour:
		return fmt.Sprintf("%dh %dm", int(d.Hours()), int(d.Minutes())%60)
	}
	return fmt.Sprintf("%dm", int(d.Minutes()))
}

// newestIn returns the newest file modification time a couple of folders deep.
func newestIn(dir string, depth int) time.Time {
	var newest time.Time
	walkDepth(dir, depth, func(_ string, info os.FileInfo) {
		if info.ModTime().After(newest) {
			newest = info.ModTime()
		}
	})
	return newest
}
