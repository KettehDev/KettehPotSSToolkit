//go:build windows

package main

import (
	"os"
	"os/exec"
	"path/filepath"
	"syscall"
)

var (
	procGetConsoleWindow = kernel32.NewProc("GetConsoleWindow")
	procShowWindow       = syscall.NewLazyDLL("user32.dll").NewProc("ShowWindow")
)

// browserPath finds Edge (every Windows 10/11 has it), then Chrome.
func browserPath() string {
	var cands []string
	for _, env := range []string{"ProgramFiles(x86)", "ProgramFiles", "LOCALAPPDATA"} {
		base := os.Getenv(env)
		if base == "" {
			continue
		}
		cands = append(cands,
			filepath.Join(base, `Microsoft\Edge\Application\msedge.exe`),
			filepath.Join(base, `Google\Chrome\Application\chrome.exe`))
	}
	for _, c := range cands {
		if exists(c) {
			return c
		}
	}
	return ""
}

// openAppWindow opens the page as its own app window (no tabs / address bar).
func openAppWindow(url string) bool {
	b := browserPath()
	if b == "" {
		return false
	}
	profile := filepath.Join(os.TempDir(), "KettehPot-window") // own profile = its own clean window
	cmd := exec.Command(b,
		"--app="+url,
		"--user-data-dir="+profile,
		"--window-size=1360,880",
		"--no-first-run",
		"--no-default-browser-check",
		"--do-not-de-elevate", // the toolkit runs as admin; keep the window working
		"--disable-features=Translate,msEdgeSidebarV2,msHubApps",
	)
	return cmd.Start() == nil
}

func showConsole(show bool) {
	h, _, _ := procGetConsoleWindow.Call()
	if h == 0 {
		return
	}
	mode := uintptr(0) // SW_HIDE
	if show {
		mode = 5 // SW_SHOW
	}
	procShowWindow.Call(h, mode)
}
