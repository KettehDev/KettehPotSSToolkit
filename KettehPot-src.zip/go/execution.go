// Execution History: BAM + Prefetch, i.e. what programs ran and when.
package main

import (
	"encoding/binary"
	"fmt"
	"os"
	"path/filepath"
	"regexp"
	"sort"
	"strconv"
	"strings"
	"time"
	"unicode/utf16"
)

func filetime(v uint64) time.Time {
	if v == 0 {
		return time.Time{}
	}
	return time.Unix(0, (int64(v)-116444736000000000)*100)
}

// ---------------------------------------------------------------- prefetch parsing

type pfInfo struct {
	Exe      string
	Hash     string
	Version  uint32
	RunCount uint32
	LastRuns []time.Time
	Path     string // full path of the exe (\VOLUME{..}\...)
	Files    []string
}

func utf16At(b []byte, off, maxChars int) string {
	var u []uint16
	for i := 0; i < maxChars && off+i*2+1 < len(b); i++ {
		c := binary.LittleEndian.Uint16(b[off+i*2:])
		if c == 0 {
			break
		}
		u = append(u, c)
	}
	return string(utf16.Decode(u))
}

// parsePrefetch reads an (already decompressed) SCCA prefetch file, versions 23/26/30/31.
func parsePrefetch(b []byte) (pfInfo, bool) {
	if len(b) < 0x100 || string(b[4:8]) != "SCCA" {
		return pfInfo{}, false
	}
	p := pfInfo{Version: binary.LittleEndian.Uint32(b[0:])}
	p.Exe = utf16At(b, 0x10, 30)
	p.Hash = fmt.Sprintf("%08X", binary.LittleEndian.Uint32(b[0x4C:]))
	u32 := func(o int) uint32 { return binary.LittleEndian.Uint32(b[o:]) }
	u64 := func(o int) uint64 { return binary.LittleEndian.Uint64(b[o:]) }

	strOff, strSize := int(u32(0x64)), int(u32(0x68))
	switch p.Version {
	case 17: // XP
		p.LastRuns = []time.Time{filetime(u64(0x78))}
		p.RunCount = u32(0x90)
	case 23: // 7
		p.LastRuns = []time.Time{filetime(u64(0x80))}
		p.RunCount = u32(0x98)
	case 26, 30, 31: // 8, 10, 11
		for i := 0; i < 8; i++ {
			if t := filetime(u64(0x80 + i*8)); !t.IsZero() {
				p.LastRuns = append(p.LastRuns, t)
			}
		}
		// v30 comes in two layouts; the metrics offset tells them apart
		first, second := 0xD0, 0xC8
		if u32(0x54) == 0x128 {
			first, second = 0xC8, 0xD0
		}
		p.RunCount = u32(first)
		if p.RunCount == 0 || p.RunCount > 1_000_000 {
			p.RunCount = u32(second)
		}
	default:
		return p, false
	}

	if strOff > 0 && strSize > 0 && strOff+strSize <= len(b) {
		u := make([]uint16, strSize/2)
		for i := range u {
			u[i] = binary.LittleEndian.Uint16(b[strOff+i*2:])
		}
		cur := []uint16{}
		for _, c := range u {
			if c == 0 {
				if len(cur) > 0 {
					p.Files = append(p.Files, string(utf16.Decode(cur)))
				}
				cur = cur[:0]
				continue
			}
			cur = append(cur, c)
		}
		exe := strings.ToUpper(p.Exe)
		for _, f := range p.Files {
			base := strings.ToUpper(f[strings.LastIndex(f, `\`)+1:])
			if base == exe || (len(exe) >= 29 && strings.HasPrefix(base, exe)) {
				p.Path = f
				break
			}
		}
	}
	sort.Slice(p.LastRuns, func(i, j int) bool { return p.LastRuns[i].After(p.LastRuns[j]) })
	return p, true
}

var reVolume = regexp.MustCompile(`(?i)^\\VOLUME\{[0-9a-f]+-([0-9a-f]{8})\}`)

// dosPath turns \VOLUME{..-SERIAL}\X or \Device\HarddiskVolume3\X into C:\X.
func dosPath(p string, serials map[uint32]string, devices map[string]string) string {
	if m := reVolume.FindStringSubmatch(p); m != nil {
		if s, err := strconv.ParseUint(m[1], 16, 32); err == nil {
			if letter, ok := serials[uint32(s)]; ok {
				return letter + p[len(m[0]):]
			}
		}
		return p
	}
	low := strings.ToLower(p)
	for dev, letter := range devices {
		if strings.HasPrefix(low, dev+`\`) {
			return letter + p[len(dev):]
		}
	}
	return p
}

// ---------------------------------------------------------------- name checks

type nameRule struct {
	level, label string
	re           *regexp.Regexp
}

var exeRules = []nameRule{
	{"FAIL", "autoclicker", regexp.MustCompile(`(?i)auto.?click|clicker|op.?auto|speed.?auto|gs.?auto`)},
	{"FAIL", "cheat / injector", regexp.MustCompile(`(?i)cheat.?engine|injector|xenos|ghost.?client|vape(lite|v4)?\.exe|slinky|doomsday|whiteout|itami|dream.?client|akrien|novoline|liquidbounce|wurst.?client|thunderhack|clickcrystal|grim.?bypass|krypton|virel`)},
	{"WARN", "possible cheat name", regexp.MustCompile(`(?i)\b(vape|argon|prestige|entropy|drip|sapphire|raven|rise|meteor|aristois|future|kami|sigma|cryptic|donut|inject)\b`)},
	{"WARN", "memory / process tool", regexp.MustCompile(`(?i)process.?hacker|systeminformer|process.?explorer|procexp|x64dbg|x32dbg|ollydbg|ida64|dnspy|recaf|hxd`)},
	{"WARN", "macro / scripting", regexp.MustCompile(`(?i)autohotkey|\bahk\b|macro|tinytask|pulover|jitbit|murgee|keytweak|x-?mouse`)},
	{"WARN", "cleaner / anti-forensics", regexp.MustCompile(`(?i)ccleaner|privazer|bleachbit|wise.?care|glary|eraser|sdelete|file.?shredder|everything.?clean|usn.?clean|prefetch.?clean|lastactivityview|shellbag`)},
	{"WARN", "time changer", regexp.MustCompile(`(?i)runasdate|time.?stop|date.?changer|time.?changer`)},
	{"WARN", "virtual / mounting", regexp.MustCompile(`(?i)imdisk|osfmount|veracrypt|truecrypt|vmware|virtualbox|vbox|sandboxie`)},
}

func exeFlags(name string) []nameRule {
	var out []nameRule
	for _, r := range exeRules {
		if r.re.MatchString(name) {
			out = append(out, r)
		}
	}
	return out
}

var reTempish = regexp.MustCompile(`(?i)\\(temp|tmp|downloads|desktop|appdata\\local\\temp)\\|\$recycle\.bin`)

// ---------------------------------------------------------------- run

type execEntry struct {
	when      time.Time
	name      string
	path      string
	source    string // "BAM" / "Prefetch"
	runs      uint32
	user      string
	deleted   bool
	flags     []nameRule
	removable bool
}

func runExecution() {
	serials := volumeSerials()
	devices := deviceMap()
	removable := map[string]bool{}
	for _, d := range listDrives() {
		if d.Type == driveRemovable || d.Type == driveRemote {
			removable[strings.ToUpper(d.Letter)] = true
		}
	}
	var entries []execEntry
	mk := func(when time.Time, path, source, user string, runs uint32) execEntry {
		name := filepath.Base(strings.ReplaceAll(path, `\`, "/"))
		e := execEntry{when: when, name: name, path: path, source: source, runs: runs, user: user, flags: exeFlags(name)}
		if len(path) > 2 && path[1] == ':' {
			e.removable = removable[strings.ToUpper(path[:2])]
			e.deleted = !exists(path)
		}
		return e
	}

	// ---------------- BAM
	section("BAM  ·  background activity moderator")
	bamRoots := []string{`SYSTEM\CurrentControlSet\Services\bam\State\UserSettings`, `SYSTEM\CurrentControlSet\Services\bam\UserSettings`}
	bamCount := 0
	readAny := false
	for _, root := range bamRoots {
		sids, ok := regSubkeys(hklm, root)
		if !ok {
			continue
		}
		readAny = true
		for _, sid := range sids {
			user := sidToName(sid)
			if user == "" {
				user = sid
			}
			vals, _ := regValues(hklm, root+`\`+sid)
			for _, v := range vals {
				if len(v.Data) < 8 || v.Name == "Version" || v.Name == "SequenceNumber" || !strings.HasPrefix(v.Name, `\`) {
					continue
				}
				when := filetime(binary.LittleEndian.Uint64(v.Data))
				entries = append(entries, mk(when, dosPath(v.Name, serials, devices), "BAM", user, 0))
				bamCount++
			}
		}
	}
	if !readAny {
		row("WARN", "BAM", "couldn't read it", "needs admin, or the bam driver is off")
	} else {
		row("INFO", "BAM entries", fmt.Sprintf("%d", bamCount), "programs run in roughly the last week")
	}

	// ---------------- Prefetch
	section("Prefetch  ·  parsed")
	dir := prefetchDir()
	files, err := os.ReadDir(dir)
	if err != nil {
		row("WARN", "Prefetch", "can't read the folder", err.Error())
	}
	parsed, failed := 0, 0
	for _, f := range files {
		if f.IsDir() || !strings.EqualFold(filepath.Ext(f.Name()), ".pf") {
			continue
		}
		raw, err := os.ReadFile(filepath.Join(dir, f.Name()))
		if err != nil {
			failed++
			continue
		}
		plain, err := decompressMAM(raw)
		if err != nil {
			failed++
			continue
		}
		pf, ok := parsePrefetch(plain)
		if !ok || len(pf.LastRuns) == 0 {
			failed++
			continue
		}
		parsed++
		path := pf.Exe
		if pf.Path != "" {
			path = dosPath(pf.Path, serials, devices)
		}
		e := mk(pf.LastRuns[0], path, "Prefetch", "", pf.RunCount)
		if pf.Path == "" {
			e.deleted = false // no full path, can't tell
		}
		entries = append(entries, e)
	}
	row("INFO", "Prefetch parsed", fmt.Sprintf("%d files", parsed), fmt.Sprintf("%d unreadable", failed))

	// newest first, keep one line per path+source
	sort.Slice(entries, func(i, j int) bool { return entries[i].when.After(entries[j].when) })

	// ---------------- flagged
	section("Flagged programs")
	nFlag := 0
	seen := map[string]bool{}
	for _, e := range entries {
		key := strings.ToLower(e.path)
		if seen[key] {
			continue
		}
		bad := len(e.flags) > 0 || (e.deleted && e.when.After(time.Now().Add(-48*time.Hour)) && strings.HasSuffix(strings.ToLower(e.name), ".exe")) || e.removable
		if !bad {
			continue
		}
		seen[key] = true
		nFlag++
		level, why := "WARN", []string{}
		for _, f := range e.flags {
			why = append(why, f.label)
			if f.level == "FAIL" {
				level = "FAIL"
			}
		}
		if e.deleted {
			why = append(why, "exe deleted since")
		}
		if e.removable {
			why = append(why, "ran from a usb / removable drive")
		}
		row(level, cut(e.name, 24), strings.Join(why, ", "), e.source+" · "+e.when.Format("01-02 15:04")+" · "+ago(e.when))
		sub(e.path, "DarkGray")
	}
	if nFlag == 0 {
		row("OK", "Flagged programs", "none", "")
	}

	// ---------------- timeline
	section("Ran in the last 24 hours")
	cut24 := time.Now().Add(-24 * time.Hour)
	shown := 0
	seen = map[string]bool{}
	for _, e := range entries {
		if e.when.Before(cut24) {
			break
		}
		key := strings.ToLower(e.path)
		if seen[key] {
			continue
		}
		seen[key] = true
		color := "Gray"
		if reTempish.MatchString(e.path) {
			color = "White"
		}
		if e.deleted {
			color = "Yellow"
		}
		if len(e.flags) > 0 {
			color = "Red"
		}
		extra := e.source
		if e.runs > 0 {
			extra += fmt.Sprintf(" · %dx", e.runs)
		}
		if e.deleted {
			extra += " · deleted"
		}
		line := fmt.Sprintf("   %s  %s", e.when.Format("01-02 15:04:05"), pad(cut(e.name, 34), 34))
		if shown < 60 {
			outn(line, color)
			outln("  "+extra, "DarkGray")
		} else {
			report.WriteString(line + "  " + extra + "\r\n") // rest goes in the saved report only
		}
		shown++
	}
	if shown == 0 {
		row("WARN", "Timeline", "nothing ran in the last 24h?", "BAM and prefetch are both empty for today")
	} else if shown > 60 {
		outln(fmt.Sprintf("   ... %d more in the saved report", shown-60), "DarkGray")
	}
}
