// Log Analyzer: reads every launcher's game logs (latest.log + the zipped old ones).
// Finds mods that were loaded in past sessions but are gone now, cheat client traces,
// anticheat kicks, servers joined, and log files that were deleted.
package main

import (
	"bufio"
	"compress/gzip"
	"fmt"
	"io"
	"os"
	"path/filepath"
	"regexp"
	"sort"
	"strconv"
	"strings"
	"time"
)

type logSession struct {
	file   string
	when   time.Time
	user   string
	mods   map[string]string // id -> version
	hits   []logHit
	server []string
}

type logHit struct {
	level, label, line string
}

var (
	reLogName   = regexp.MustCompile(`^(\d{4}-\d\d-\d\d)-(\d+)\.log(\.gz)?$`)
	reConnect   = regexp.MustCompile(`Connecting to ([^\s,]+),? ?(\d+)?`)
	reChatLine  = regexp.MustCompile(`\[CHAT\]|\[System\] \[CHAT\]`)
	reClientLog = regexp.MustCompile(`(?i)meteordevelopment|meteor-client|net\.wurstclient|wurstclient|net\.ccbluex|liquidbounce|aristois|impactclient|futureclient|rusherhack|thunderhack|bleachhack|clickcrystals|novoline|prestigeclient|doomsday|boze|virel|argonclient|kryptonclient|grimbypass`)
	reAgentLog  = regexp.MustCompile(`(?i)javaagent|agentmain|premain-class|instrumentation\.(retransform|redefine)`)
	reBaritone  = regexp.MustCompile(`(?i)\bbaritone\b`)
	reKick      = regexp.MustCompile(`(?i)(disconnect|kicked|lost connection|you are banned|you have been banned|banned from)`)
	reKickWhy   = regexp.MustCompile(`(?i)cheat|hack|unfair|anti-?cheat|vulcan|grim|polar|intave|matrix|spartan|verus|karhu|\bncp\b|\baac\b|watchdog|flying is not enabled|killaura|reach|autoclick|timer|blink|velocity|scaffold|illegal`)
)

func openLog(path string) (io.ReadCloser, error) {
	f, err := os.Open(path)
	if err != nil {
		return nil, err
	}
	if !strings.HasSuffix(strings.ToLower(path), ".gz") {
		return f, nil
	}
	gz, err := gzip.NewReader(f)
	if err != nil {
		f.Close()
		return nil, err
	}
	return struct {
		io.Reader
		io.Closer
	}{gz, f}, nil
}

func parseSession(path string, when time.Time) (*logSession, bool) {
	rc, err := openLog(path)
	if err != nil {
		return nil, false
	}
	defer rc.Close()
	s := &logSession{file: filepath.Base(path), when: when, mods: map[string]string{}}
	sc := bufio.NewScanner(io.LimitReader(rc, 6<<20))
	sc.Buffer(make([]byte, 64<<10), 1<<20)
	inList := false
	seenHit := map[string]bool{}
	hit := func(level, label, line string) {
		if seenHit[label] {
			return
		}
		seenHit[label] = true
		s.hits = append(s.hits, logHit{level, label, strings.TrimSpace(cut(line, 160))})
	}
	for sc.Scan() {
		l := sc.Text()
		if s.user == "" {
			if m := reSettingUser.FindStringSubmatch(l); m != nil {
				s.user = m[1]
			}
		}
		if reLoadingMods.MatchString(l) {
			inList = true
			continue
		}
		if inList {
			if reNestedLine.MatchString(l) {
				continue
			}
			if m := reModLine.FindStringSubmatch(l); m != nil {
				if !builtinIDs[m[1]] {
					s.mods[m[1]] = m[2]
				}
				continue
			}
			inList = false
		}
		if m := reConnect.FindStringSubmatch(l); m != nil && len(s.server) < 10 {
			srv := m[1]
			if m[2] != "" && m[2] != "25565" {
				srv += ":" + m[2]
			}
			s.server = append(s.server, srv)
		}
		chat := reChatLine.MatchString(l)
		switch {
		case !chat && reClientLog.MatchString(l):
			hit("FAIL", "cheat client in the log: "+strings.ToLower(reClientLog.FindString(l)), l)
		case !chat && reAgentLog.MatchString(l):
			hit("FAIL", "java agent / class redefining", l)
		case !chat && reBaritone.MatchString(l):
			hit("WARN", "baritone (auto-walk / mining bot)", l)
		case reKick.MatchString(l) && reKickWhy.MatchString(l):
			hit("WARN", "kicked or banned for cheating / by an anticheat", l)
		}
	}
	return s, true
}

type logFile struct {
	path string
	mod  time.Time
}

// runLogs analyzes ONE place the staff member picks: a logs folder, a single log file,
// or an instance / .minecraft folder.
func runLogs() {
	src, ok := pickLogSource()
	if !ok {
		toolCancelled = true
		return
	}
	analyzeLogs(src)
}

type logSource struct {
	label, logs, mods string
	only              string // a single file name inside logs, "" = every log
}

func pickLogSource() (logSource, bool) {
	var found []logSource
	seen := map[string]bool{}
	for _, in := range findInstances() {
		d := filepath.Join(in.gameDir, "logs")
		if isDir(d) && !seen[strings.ToLower(d)] {
			seen[strings.ToLower(d)] = true
			found = append(found, logSource{label: in.launcher + " · " + in.name, logs: d, mods: in.modsDir})
		}
	}
	for _, d := range []string{filepath.Join(homeDir(), ".lunarclient", "logs", "game"), filepath.Join(homeDir(), ".lunarclient", "logs", "launcher")} {
		if isDir(d) && !seen[strings.ToLower(d)] {
			seen[strings.ToLower(d)] = true
			found = append(found, logSource{label: "Lunar · " + filepath.Base(d), logs: d})
		}
	}
	var opts []choice
	for _, f := range found {
		opts = append(opts, choice{f.label, plural(len(listLogNames(f.logs)), "log")})
	}
	for {
		n, path, ok := choose("Pick what to analyze", "or paste a logs folder, one .log / .log.gz file, or an instance / .minecraft folder", opts, true)
		if !ok {
			return logSource{}, false
		}
		if n >= 0 {
			return found[n], true
		}
		if src, ok := logSourceFromPath(path); ok {
			return src, true
		}
		if gui {
			emit(map[string]any{"type": "note", "text": "no logs there, try another path", "color": "Red"})
		} else {
			colorPrint("   no logs there, try another path", "DarkGray")
		}
	}
}

// logSourceFromPath works out what the pasted path is.
func logSourceFromPath(p string) (logSource, bool) {
	abs, err := filepath.Abs(p)
	if err != nil {
		return logSource{}, false
	}
	low := strings.ToLower(abs)
	if st, err := os.Stat(abs); err == nil && !st.IsDir() {
		if strings.HasSuffix(low, ".log") || strings.HasSuffix(low, ".log.gz") {
			dir := filepath.Dir(abs)
			mods := filepath.Join(filepath.Dir(dir), "mods")
			if !isDir(mods) {
				mods = ""
			}
			return logSource{label: filepath.Base(abs), logs: dir, mods: mods, only: filepath.Base(abs)}, true
		}
		return logSource{}, false
	}
	if !isDir(abs) {
		return logSource{}, false
	}
	// an instance / .minecraft folder: use its logs + mods
	if d := filepath.Join(abs, "logs"); isDir(d) {
		mods := filepath.Join(abs, "mods")
		if !isDir(mods) {
			mods = ""
		}
		return logSource{label: filepath.Base(abs), logs: d, mods: mods}, true
	}
	if len(listLogNames(abs)) > 0 {
		mods := filepath.Join(filepath.Dir(abs), "mods")
		if !isDir(mods) {
			mods = ""
		}
		return logSource{label: filepath.Base(filepath.Dir(abs)) + " · " + filepath.Base(abs), logs: abs, mods: mods}, true
	}
	return logSource{}, false
}

func listLogNames(dir string) []string {
	var out []string
	entries, _ := os.ReadDir(dir)
	for _, e := range entries {
		low := strings.ToLower(e.Name())
		if !e.IsDir() && (strings.HasSuffix(low, ".log") || strings.HasSuffix(low, ".log.gz")) {
			out = append(out, e.Name())
		}
	}
	return out
}

func analyzeLogs(src logSource) {
	entries, _ := os.ReadDir(src.logs)
	var files []logFile
	byDay := map[string][]int{}
	for _, e := range entries {
		if src.only != "" && !strings.EqualFold(e.Name(), src.only) {
			continue
		}
		n := e.Name()
		low := strings.ToLower(n)
		if e.IsDir() || !(strings.HasSuffix(low, ".log") || strings.HasSuffix(low, ".log.gz")) {
			continue
		}
		info, err := e.Info()
		if err != nil {
			continue
		}
		files = append(files, logFile{filepath.Join(src.logs, n), info.ModTime()})
		if m := reLogName.FindStringSubmatch(n); m != nil {
			k, _ := strconv.Atoi(m[2])
			byDay[m[1]] = append(byDay[m[1]], k)
		}
	}
	if len(files) == 0 {
		section(cut(src.label, 52))
		row("WARN", "Logs", "no .log or .log.gz files here", src.logs)
		return
	}
	sort.Slice(files, func(i, j int) bool { return files[i].mod.After(files[j].mod) })
	newest := files[0].mod
	section(cut(src.label, 52))
	if len(files) > 120 {
		files = files[:120]
	}

	var sessions []*logSession
	for _, f := range files {
		if s, ok := parseSession(f.path, f.mod); ok {
			sessions = append(sessions, s)
		}
	}
	row("INFO", "Sessions read", plural(len(sessions), "log"), "newest "+ago(newest))

	// everything found, for the separate discord message
	var dRemoved, dTraces, dSessions, dWho []string
	for _, s := range sessions {
		who := s.user
		if who == "" {
			who = "?"
		}
		srv := ""
		if len(s.server) > 0 {
			srv = "  → " + strings.Join(s.server, ", ")
		}
		dSessions = append(dSessions, fmt.Sprintf("  %s  %-16s %3d mods%s", s.when.Format("01-02 15:04"), who, len(s.mods), srv))
	}

	// ---- deleted logs (only makes sense for a whole folder)
	if src.only == "" {
		var gaps []string
		for day, nums := range byDay {
			sort.Ints(nums)
			for i := 1; i < len(nums); i++ {
				for k := nums[i-1] + 1; k < nums[i]; k++ {
					gaps = append(gaps, fmt.Sprintf("%s-%d", day, k))
				}
			}
			if nums[0] > 1 {
				for k := 1; k < nums[0]; k++ {
					gaps = append(gaps, fmt.Sprintf("%s-%d", day, k))
				}
			}
		}
		sort.Sort(sort.Reverse(sort.StringSlice(gaps)))
		if len(gaps) > 0 {
			level := "WARN"
			if strings.HasPrefix(gaps[0], time.Now().Format("2006-01-02")) {
				level = "FAIL"
			}
			row(level, "Deleted logs", fmt.Sprintf("%d missing", len(gaps)), "e.g. "+strings.Join(gaps[:min(3, len(gaps))], ", ")+".log.gz")
			for _, g := range gaps {
				dTraces = append(dTraces, "✗ deleted log  "+g+".log.gz")
			}
		} else {
			row("OK", "Deleted logs", "none missing", "")
		}

	}

	// ---- mods used in the past that aren't installed now
	if src.mods != "" {
		present := map[string]bool{}
		for _, j := range listJars(src.mods) {
			for _, id := range j.ids {
				present[id] = true
			}
		}
		type gone struct {
			id, ver string
			last    time.Time
		}
		goneMods := map[string]*gone{}
		for _, s := range sessions {
			for id, ver := range s.mods {
				if present[id] || isNestedLibrary(id) {
					continue
				}
				if g, ok := goneMods[id]; !ok || s.when.After(g.last) {
					goneMods[id] = &gone{id, ver, s.when}
				}
			}
		}
		var list []*gone
		for _, g := range goneMods {
			list = append(list, g)
		}
		sort.Slice(list, func(i, j int) bool { return list[i].last.After(list[j].last) })
		shown := 0
		for _, g := range list {
			lvl := "INFO"
			why := "used before, not installed now"
			if fl := exeFlags(g.id); len(fl) > 0 {
				lvl, why = "FAIL", "used before, gone now · "+fl[0].label
			} else if reClientLog.MatchString(g.id) {
				lvl, why = "FAIL", "cheat client, used before, gone now"
			} else if time.Since(g.last) < 7*24*time.Hour {
				lvl = "WARN"
			}
			mark := "  "
			if lvl == "FAIL" {
				mark = "✗ "
			} else if lvl == "WARN" {
				mark = "! "
			}
			dRemoved = append(dRemoved, fmt.Sprintf("%s%-32s last loaded %s", mark, g.id+" "+g.ver, g.last.Format("01-02 15:04")))
			if lvl == "INFO" {
				report.WriteString(fmt.Sprintf("   removed mod  %-30s last loaded %s\r\n", g.id+" "+g.ver, ts(g.last)))
				continue
			}
			shown++
			row(lvl, cut(g.id, 24), why, "last loaded "+g.last.Format("01-02 15:04")+" · "+ago(g.last))
		}
		if shown == 0 {
			row("OK", "Removed mods", "nothing recent", fmt.Sprintf("%d older ones in the saved report", len(list)))
		}
	}

	// ---- cheat traces, agents, kicks
	// one line per kind of trace: newest example + how many logs had it
	type trace struct {
		h     logHit
		s     *logSession
		count int
	}
	traceMap := map[string]*trace{}
	var order []string
	for _, s := range sessions { // newest first
		for _, h := range s.hits {
			if t, ok := traceMap[h.label]; ok {
				t.count++
				continue
			}
			traceMap[h.label] = &trace{h, s, 1}
			order = append(order, h.label)
		}
	}
	for _, k := range order {
		t := traceMap[k]
		extra := t.s.file + " · " + ago(t.s.when)
		if t.count > 1 {
			extra += fmt.Sprintf(" · in %d logs", t.count)
		}
		row(t.h.level, "Log trace", cut(t.h.label, 56), extra)
		sub(t.h.line, "DarkGray")
		mark := "! "
		if t.h.level == "FAIL" {
			mark = "✗ "
		}
		dTraces = append(dTraces, mark+t.h.label+"  ("+extra+")", "    "+t.h.line)
	}
	traces := len(order)
	if traces == 0 {
		row("OK", "Cheat traces / kicks", "none", "")
	}

	// ---- accounts + servers
	users := map[string]bool{}
	servers := map[string]time.Time{}
	for _, s := range sessions {
		if s.user != "" {
			users[s.user] = true
			noteAccount(s.user)
		}
		for _, sv := range s.server {
			if s.when.After(servers[sv]) {
				servers[sv] = s.when
			}
		}
	}
	if len(users) > 0 {
		var u []string
		for k := range users {
			u = append(u, k)
		}
		sort.Strings(u)
		row("INFO", "Accounts in logs", cut(strings.Join(u, ", "), 50), "")
		dWho = append(dWho, "  accounts: "+strings.Join(u, ", "))
	}
	if len(servers) > 0 {
		var sv []string
		for k := range servers {
			sv = append(sv, k)
		}
		sort.Slice(sv, func(i, j int) bool { return servers[sv[i]].After(servers[sv[j]]) })
		for i, k := range sv {
			dWho = append(dWho, fmt.Sprintf("  server  %-34s last joined %s", k, servers[k].Format("01-02 15:04")))
			if i < 5 {
				row("INFO", "Server", cut(k, 40), "last joined "+ago(servers[k]))
			} else {
				report.WriteString(fmt.Sprintf("   server  %-40s last joined %s\r\n", k, ts(servers[k])))
			}
		}
	}

	// one separate discord message with everything above
	sendDetail("Log Analyzer · "+cut(src.label, 40), "📜", []detailSection{
		{"CHEAT TRACES / KICKS / DELETED LOGS", dTraces},
		{"MODS USED BEFORE, NOT INSTALLED NOW", dRemoved},
		{"ACCOUNTS + SERVERS", dWho},
		{"SESSIONS READ · newest first", dSessions},
	})
}
