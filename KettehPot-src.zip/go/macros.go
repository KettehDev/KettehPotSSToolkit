// Macro Check: autoclickers + macro tools running, mouse software installed, and
// macro configs / AutoHotkey scripts that were touched recently.
package main

import (
	"bytes"
	"fmt"
	"os"
	"path/filepath"
	"regexp"
	"sort"
	"strings"
	"time"
)

type mouseSoft struct {
	name    string
	paths   []string // install or config folders, any one existing = installed
	configs []string // folders whose files hold macros
	proc    *regexp.Regexp
	macroRe *regexp.Regexp // what a macro looks like inside those configs
}

func mouseSoftware() []mouseSoft {
	la := os.Getenv("LOCALAPPDATA")
	ad := appData()
	pd := os.Getenv("ProgramData")
	pf := os.Getenv("ProgramFiles")
	pf86 := os.Getenv("ProgramFiles(x86)")
	return []mouseSoft{
		{"Logitech G HUB", []string{filepath.Join(la, "LGHUB"), filepath.Join(pf, "LGHUB")},
			[]string{filepath.Join(la, "LGHUB")}, regexp.MustCompile(`(?i)^lghub`), regexp.MustCompile(`(?i)"macro"|MACRO_|"repeat(While|Toggle|Mode)"|"type"\s*:\s*"MACRO`)},
		{"Logitech Gaming Software", []string{filepath.Join(la, "Logitech", "Logitech Gaming Software"), filepath.Join(pf, "Logitech Gaming Software")},
			[]string{filepath.Join(la, "Logitech", "Logitech Gaming Software", "profiles")}, regexp.MustCompile(`(?i)^lcore`), regexp.MustCompile(`(?i)<macro|<repeat|<multikey`)},
		{"Razer Synapse", []string{filepath.Join(la, "Razer"), filepath.Join(pf86, "Razer"), filepath.Join(pd, "Razer")},
			[]string{filepath.Join(la, "Razer", "Synapse3"), filepath.Join(pd, "Razer", "Synapse3"), filepath.Join(la, "Razer", "RazerAppEngine")}, regexp.MustCompile(`(?i)^razer.*synapse|^razer central`), regexp.MustCompile(`(?i)"macro|MacroId|turbo`)},
		{"Bloody / A4Tech", []string{filepath.Join(pf86, "Bloody7"), filepath.Join(pf, "Bloody7"), filepath.Join(pf86, "Bloody6"), filepath.Join(pf86, "BloodyX")},
			[]string{filepath.Join(pf86, "Bloody7", "Bloody7", "Data", "Mouse"), filepath.Join(pf86, "Bloody7", "Bloody7", "UserLog")}, regexp.MustCompile(`(?i)^bloody`), nil},
		{"SteelSeries GG", []string{filepath.Join(pf, "SteelSeries"), filepath.Join(pd, "SteelSeries")},
			[]string{filepath.Join(pd, "SteelSeries", "GG", "apps", "engine")}, regexp.MustCompile(`(?i)^steelseries`), regexp.MustCompile(`(?i)macro`)},
		{"Corsair iCUE", []string{filepath.Join(pf, "Corsair"), filepath.Join(ad, "Corsair")},
			[]string{filepath.Join(ad, "Corsair", "CUE"), filepath.Join(ad, "Corsair", "CUE5")}, regexp.MustCompile(`(?i)^icue`), regexp.MustCompile(`(?i)macro|repeat`)},
		{"Glorious Core", []string{filepath.Join(pf86, "Glorious Core"), filepath.Join(pf, "Glorious Core")},
			[]string{filepath.Join(ad, "Glorious Core")}, regexp.MustCompile(`(?i)glorious`), regexp.MustCompile(`(?i)macro`)},
		{"ROCCAT Swarm", []string{filepath.Join(pf86, "ROCCAT"), filepath.Join(ad, "ROCCAT")},
			[]string{filepath.Join(ad, "ROCCAT")}, regexp.MustCompile(`(?i)roccat`), regexp.MustCompile(`(?i)macro`)},
		{"HyperX NGENUITY", []string{filepath.Join(la, "Packages", "HyperX")}, nil, regexp.MustCompile(`(?i)ngenuity`), nil},
		{"Redragon / generic", []string{filepath.Join(pf86, "Redragon"), filepath.Join(pf86, "Gaming Mouse")}, nil, regexp.MustCompile(`(?i)redragon|gaming.?mouse`), nil},
		{"X-Mouse Button Control", []string{filepath.Join(pf, "Highresolution Enterprises"), filepath.Join(ad, "Highresolution Enterprises")},
			[]string{filepath.Join(ad, "Highresolution Enterprises", "XMouseButtonControl")}, regexp.MustCompile(`(?i)xmouse`), regexp.MustCompile(`(?i)simulated|repeat|autorepeat`)},
	}
}

var reMacroProc = regexp.MustCompile(`(?i)autohotkey|\bahk|auto.?click|clicker|tinytask|pulover|jitbit|macro|murgee|ghost.?mouse|op.?auto|speed.?auto|keytweak|mouse.?recorder`)

func runMacros() {
	procs := listProcesses()

	// ---------------- running
	section("Running right now")
	hits := 0
	for _, p := range procs {
		n := p.Name
		if !reMacroProc.MatchString(n) && len(exeFlags(n)) == 0 {
			continue
		}
		fl := exeFlags(n)
		level, why := "WARN", "macro / scripting tool"
		if len(fl) > 0 {
			level, why = fl[0].level, fl[0].label
		}
		if level == "WARN" && fl == nil && !reMacroProc.MatchString(n) {
			continue
		}
		hits++
		row(level, cut(n, 24), why, fmt.Sprintf("pid %d", p.PID))
		if img := processImage(p.PID); img != "" {
			sub(img, "DarkGray")
		}
	}
	if hits == 0 {
		row("OK", "Macro / clicker programs", "none running", "")
	}

	// ---------------- mouse software
	section("Mouse / keyboard software")
	running := map[string]bool{}
	for _, p := range procs {
		running[strings.ToLower(p.Name)] = true
	}
	anySoft := false
	for _, s := range mouseSoftware() {
		installed := false
		for _, p := range s.paths {
			if p != "" && isDir(p) {
				installed = true
				break
			}
		}
		isRunning := false
		for n := range running {
			if s.proc.MatchString(n) {
				isRunning = true
				break
			}
		}
		if !installed && !isRunning {
			continue
		}
		anySoft = true
		state := "installed"
		if isRunning {
			state = "installed · running"
		}
		colorPart("   checking "+s.name+"...\r", "DarkGray")
		macros, newest, newestFile := scanMacroConfigs(s)
		colorPart("   "+strings.Repeat(" ", len(s.name)+12)+"\r", "DarkGray")
		switch {
		case macros > 0 && time.Since(newest) < 24*time.Hour:
			row("WARN", s.name, state, fmt.Sprintf("macro settings changed %s", ago(newest)))
			sub(newestFile, "DarkGray")
		case macros > 0:
			row("INFO", s.name, state, fmt.Sprintf("has macro settings · last changed %s", ago(newest)))
		default:
			row("INFO", s.name, state, "")
		}
		if s.name == "Bloody / A4Tech" {
			row("WARN", "Bloody", "known for built-in autoclick / no-recoil modes", "ask them to open it on stream")
		}
	}
	if !anySoft {
		row("OK", "Mouse software", "none found", "")
	}

	// ---------------- AutoHotkey
	section("AutoHotkey")
	ahkInstalled := ""
	for _, p := range []string{filepath.Join(os.Getenv("ProgramFiles"), "AutoHotkey"), filepath.Join(os.Getenv("LOCALAPPDATA"), "Programs", "AutoHotkey")} {
		if isDir(p) {
			ahkInstalled = p
		}
	}
	if ahkInstalled != "" {
		row("WARN", "AutoHotkey", "installed", ahkInstalled)
	} else {
		row("OK", "AutoHotkey", "not installed", "")
	}
	scripts := findAHKScripts()
	if len(scripts) == 0 {
		row("OK", ".ahk scripts", "none in the usual folders", "")
	}
	for i, s := range scripts {
		if i == 15 {
			sub(fmt.Sprintf("... and %d more", len(scripts)-15), "DarkGray")
			break
		}
		level := "INFO"
		why := "changed " + ago(s.mod)
		if time.Since(s.mod) < 48*time.Hour {
			level = "WARN"
		}
		if s.clicky {
			level, why = "FAIL", "sends mouse clicks in a loop · "+why
		}
		row(level, cut(filepath.Base(s.path), 24), why, "")
		sub(s.path, "DarkGray")
	}
}

// folders full of browser cache / logs: thousands of files, never macros
var macroSkipDirs = map[string]bool{
	"cache": true, "code cache": true, "gpucache": true, "dawncache": true, "grshadercache": true,
	"shadercache": true, "blob_storage": true, "crashpad": true, "crashdumps": true, "indexeddb": true,
	"service worker": true, "session storage": true, "local storage": true, "logs": true, "log": true,
	"webcache": true, "dawngraphitecache": true, "cookies": true, "network": true, "temp": true, "updates": true,
}

var macroWords = [][]byte{[]byte("macro"), []byte("repeat"), []byte("turbo"), []byte("simulated")}

func scanMacroConfigs(s mouseSoft) (count int, newest time.Time, newestFile string) {
	deadline := time.Now().Add(6 * time.Second) // never hang on a huge app folder
	files := 0
	for _, dir := range s.configs {
		if dir == "" || !isDir(dir) {
			continue
		}
		filepath.WalkDir(dir, func(p string, d os.DirEntry, err error) error {
			if err != nil {
				return nil
			}
			if d.IsDir() {
				if p != dir && macroSkipDirs[strings.ToLower(d.Name())] {
					return filepath.SkipDir
				}
				return nil
			}
			files++
			if files > 4000 || time.Now().After(deadline) {
				return filepath.SkipAll
			}
			info, err := d.Info()
			if err != nil || info.Size() > 8<<20 {
				return nil
			}
			ext := strings.ToLower(filepath.Ext(p))
			lowP := strings.ToLower(p)
			isMacroFile := strings.Contains(lowP, "macro") || strings.Contains(lowP, "script")
			if s.macroRe == nil && !isMacroFile {
				return nil
			}
			if s.macroRe != nil && !isMacroFile {
				if ext != ".json" && ext != ".xml" && ext != ".db" && ext != ".cfg" && ext != ".ini" && ext != ".dat" {
					return nil
				}
				b, err := os.ReadFile(p)
				if err != nil {
					return nil
				}
				low := bytes.ToLower(b)
				hit := false
				for _, w := range macroWords {
					if bytes.Contains(low, w) {
						hit = true
						break
					}
				}
				// the regex only runs on files that already mention a macro word
				if !hit || !s.macroRe.Match(b) {
					return nil
				}
				count += bytes.Count(low, []byte("macro"))
				if count == 0 {
					count = 1
				}
			} else {
				count++
			}
			if info.ModTime().After(newest) {
				newest, newestFile = info.ModTime(), p
			}
			return nil
		})
	}
	return
}

type ahkScript struct {
	path   string
	mod    time.Time
	clicky bool
}

var reAHKClick = regexp.MustCompile(`(?is)(loop|settimer|while).{0,400}(click|mouseclick|send(input|play|event)?\s*,?\s*\{?(l|r)?button)`)

func findAHKScripts() []ahkScript {
	home := homeDir()
	roots := []string{
		filepath.Join(home, "Desktop"), filepath.Join(home, "Documents"), filepath.Join(home, "Downloads"),
		filepath.Join(home, "OneDrive", "Desktop"), filepath.Join(home, "OneDrive", "Documents"),
		filepath.Join(appData(), "Microsoft", "Windows", "Start Menu", "Programs", "Startup"),
	}
	var out []ahkScript
	seen := map[string]bool{}
	for _, r := range roots {
		walkDepth(r, 3, func(p string, info os.FileInfo) {
			if !strings.EqualFold(filepath.Ext(p), ".ahk") || seen[strings.ToLower(p)] {
				return
			}
			seen[strings.ToLower(p)] = true
			s := ahkScript{path: p, mod: info.ModTime()}
			if info.Size() < 256<<10 {
				if b, err := os.ReadFile(p); err == nil {
					s.clicky = reAHKClick.Match(b)
				}
			}
			out = append(out, s)
		})
	}
	sort.Slice(out, func(i, j int) bool { return out[i].mod.After(out[j].mod) })
	return out
}

// walkDepth visits files up to depth folders deep, skipping big junk folders.
func walkDepth(root string, depth int, fn func(string, os.FileInfo)) {
	entries, err := os.ReadDir(root)
	if err != nil {
		return
	}
	for _, e := range entries {
		p := filepath.Join(root, e.Name())
		if e.IsDir() {
			n := strings.ToLower(e.Name())
			if depth > 0 && n != "node_modules" && n != ".git" && n != "$recycle.bin" && !strings.HasPrefix(n, ".") {
				walkDepth(p, depth-1, fn)
			}
			continue
		}
		if info, err := e.Info(); err == nil {
			fn(p, info)
		}
	}
}
