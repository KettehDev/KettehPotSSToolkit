// Full-list messages: a tool can post ONE extra Discord message with everything it found
// (not just the flags), laid out as a single code block. Re-running the tool edits it.
package main

import (
	"encoding/json"
	"fmt"
	"os"
	"strings"
	"time"
)

type detailSection struct {
	title string
	lines []string
}

var detailMsgIDs = map[string]string{} // tool -> its own discord message

// fitDetail lays sections out as one code block that fits in limit characters,
// trimming the longest lists first and saying how many were cut.
func fitDetail(secs []detailSection, limit int) string {
	keep := make([]int, len(secs))
	clean := make([][]string, len(secs))
	for i, s := range secs {
		keep[i] = len(s.lines)
		for _, l := range s.lines {
			clean[i] = append(clean[i], strings.ReplaceAll(cut(l, 110), "```", "'''"))
		}
	}
	render := func() string {
		var b strings.Builder
		b.WriteString("```\n")
		for i, s := range secs {
			if i > 0 {
				b.WriteString("\n")
			}
			fmt.Fprintf(&b, "── %s (%d) ──\n", s.title, len(clean[i]))
			if len(clean[i]) == 0 {
				b.WriteString("  nothing\n")
			}
			for _, l := range clean[i][:keep[i]] {
				b.WriteString(l + "\n")
			}
			if n := len(clean[i]) - keep[i]; n > 0 {
				fmt.Fprintf(&b, "  … +%d more (in the saved report)\n", n)
			}
		}
		b.WriteString("```")
		return b.String()
	}
	// too long: drop the oldest UNflagged lines of the longest list first, so ✗ / ! lines stay
	flagged := func(l string) bool { return strings.HasPrefix(l, "✗") || strings.HasPrefix(l, "!") }
	dropOne := func() bool {
		big := -1
		for i := range secs {
			if keep[i] > 0 && (big < 0 || keep[i] > keep[big]) {
				big = i
			}
		}
		if big < 0 {
			return false
		}
		k := clean[big][:keep[big]]
		at := len(k) - 1
		for j := len(k) - 1; j >= 0; j-- {
			if !flagged(k[j]) {
				at = j
				break
			}
		}
		// move the dropped line past the kept part, keep order of the rest
		dropped := k[at]
		copy(clean[big][at:], clean[big][at+1:keep[big]])
		clean[big][keep[big]-1] = dropped
		keep[big]--
		return true
	}
	out := render()
	for runeLen(out) > limit {
		over := runeLen(out) - limit
		for n := 1 + over/120; n > 0; n-- { // bigger passes while far over, then one at a time
			if !dropOne() {
				break
			}
		}
		next := render()
		if next == out {
			break
		}
		out = next
	}
	return out
}

// sendDetail posts (or edits) one extra message holding a tool's full lists.
func sendDetail(tool, icon string, secs []detailSection) {
	url := findWebhook()
	if url == "" {
		return
	}
	host, _ := os.Hostname()
	for _, limit := range []int{4000, 1900} {
		payload := map[string]any{
			"username":         "KettehPot",
			"allowed_mentions": map[string]any{"parse": []string{}},
			"embeds": []map[string]any{{
				"title":       icon + " " + tool + " · " + host,
				"description": fitDetail(secs, limit),
				"color":       0x3FD0FF,
				"footer":      map[string]any{"text": "✗ flagged · ! file gone now · " + credits},
				"timestamp":   time.Now().UTC().Format(time.RFC3339),
			}},
		}
		body, _ := json.Marshal(payload)
		var code int
		var err error
		if id := detailMsgIDs[tool]; id != "" {
			code, _, err = hookDo("PATCH", url+"/messages/"+id, body)
			if err == nil && code == 404 {
				delete(detailMsgIDs, tool) // deleted in discord: post a new one
			}
		}
		if detailMsgIDs[tool] == "" {
			var resp []byte
			code, resp, err = hookDo("POST", url+"?wait=true", body)
			if err == nil && code/100 == 2 {
				var m struct {
					ID string `json:"id"`
				}
				json.Unmarshal(resp, &m)
				detailMsgIDs[tool] = m.ID
			}
		}
		if err != nil || code != 400 { // 400 = too big for discord: try again smaller
			switch {
			case err != nil:
				colorPrint("   couldn't send the full list to discord (no internet?)", "DarkGray")
			case code/100 == 2:
				colorPrint("   ↳ full list sent to staff discord", "DarkGray")
			default:
				colorPrint(fmt.Sprintf("   couldn't send the full list to discord (status %d)", code), "DarkGray")
			}
			return
		}
	}
}
