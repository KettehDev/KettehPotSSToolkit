// javaw Inspector: looks inside the running Minecraft process.
// Java agents, extra mod folders, injected DLLs, the launcher that started it.
package main

import (
	"fmt"
	"os"
	"path/filepath"
	"regexp"
	"sort"
	"strings"
	"time"
)

var (
	reAgent      = regexp.MustCompile(`(?i)-javaagent:("[^"]+"|\S+)`)
	reAgentPath  = regexp.MustCompile(`(?i)-agent(path|lib):("[^"]+"|\S+)`)
	reBootCP     = regexp.MustCompile(`(?i)-Xbootclasspath(/[ap])?:("[^"]+"|\S+)`)
	reAddMods    = regexp.MustCompile(`(?i)-D(fabric\.addMods|fabric\.loadMods|fml\.(?:mods|modLists?)|forge\.mods)=("[^"]+"|\S+)`)
	reNoVerify   = regexp.MustCompile(`(?i)(^|\s)-(noverify|Xverify:none|XX:-BytecodeVerification\w*)`)
	reGameDir    = regexp.MustCompile(`--gameDir\s+("[^"]+"|\S+)`)
	reVersionArg = regexp.MustCompile(`--version\s+("[^"]+"|\S+)`)
	reUserArg    = regexp.MustCompile(`--username\s+("[^"]+"|\S+)`)
	reCPArg      = regexp.MustCompile(`(?i)(?:^|\s)(?:-cp|-classpath|--class-path)\s+("[^"]+"|\S+)`)
	reUserDirs   = regexp.MustCompile(`(?i)\\(downloads|desktop|documents|temp|tmp)\\|\\appdata\\local\\temp\\|\$recycle\.bin`)
	reLwjglTemp  = regexp.MustCompile(`(?i)lwjgl|jinput|openal|glfw|jemalloc|jna|jnidispatch|discord.?game.?sdk|sqlite|zstd|lz4|netty|conpty|winpty|rocksdb|imgui`)
	reLauncherOK = regexp.MustCompile(`(?i)\\(\.minecraft|modrinthapp|com\.modrinth\.theseus|prismlauncher|polymc|multimc|curseforge|\.lunarclient|\.feather|gdlauncher\w*|atlauncher|\.tlauncher|badlion client|\.dawn|\.labymod\w*|labymod-neo|\.salwyrr|\.sklauncher|\.hmcl|\.technic|\.ftba?|\.pvplounge|\.essential|essential)\\`)
	// any "dot folder" in roaming is how most launchers store their stuff
	reDotAppData = regexp.MustCompile(`(?i)\\appdata\\roaming\\\.[^\\]+\\`)
	// user folders a cheat gets dropped in (temp is separate: launchers unpack natives there)
	reUserHard = regexp.MustCompile(`(?i)\\(downloads|desktop|documents)\\|\$recycle\.bin`)
	// native libraries java mods unpack at launch: voice chat codecs, UI / image / discord libs
	reJavaNative = regexp.MustCompile(`(?i)(4j|jni|jna|java)\w*\.dll$|^lib\w*(4j|jni)\w*\.dll$|skija|fwebp|fdiscord|fjni|opus|rnnoise|speex|lame|freetype|harfbuzz|bgfx|spout|webp|vorbis|flac|ogg|sodium|bass\.dll|jinput|jemalloc|imgui`)
)

// DLLs that commonly hook into games and are fine
var knownOverlays = []struct {
	re    *regexp.Regexp
	label string
}{
	{regexp.MustCompile(`(?i)discordhook`), "Discord overlay"},
	{regexp.MustCompile(`(?i)gameoverlayrenderer`), "Steam overlay"},
	{regexp.MustCompile(`(?i)graphics-hook`), "OBS game capture"},
	{regexp.MustCompile(`(?i)rtsshooks|rtsscore`), "RivaTuner / MSI Afterburner"},
	{regexp.MustCompile(`(?i)nvspcap|nvcamera|nvd3dumx|nvoglv|nvldumd|nvwgf2um|nvapi`), "NVIDIA driver / ShadowPlay"},
	{regexp.MustCompile(`(?i)atio6axx|atig6pxx|amdxx|aticfx|amdihk|amdenc`), "AMD driver"},
	{regexp.MustCompile(`(?i)ig\w+icd64|igdgmm|igc64|igd\w+64`), "Intel graphics driver"},
	{regexp.MustCompile(`(?i)medal|overwolf|outplayed`), "Medal / Overwolf"},
	{regexp.MustCompile(`(?i)fraps|bandicam|action_x64|playclaw`), "screen recorder"},
	{regexp.MustCompile(`(?i)nahimic|sonic.?studio|a-volute`), "audio software"},
	{regexp.MustCompile(`(?i)razer|logi|lghub|steelseries|corsair`), "peripheral software"},
}

type javaProc struct {
	pid, ppid uint32
	exe       string
	image     string
	cmd       string
	started   time.Time
	parent    string
}

func runJavaw() {
	procs := listProcesses()
	names := map[uint32]string{}
	for _, p := range procs {
		names[p.PID] = p.Name
	}
	var games []javaProc
	for _, p := range procs {
		n := strings.ToLower(p.Name)
		if n != "javaw.exe" && n != "java.exe" {
			continue
		}
		jp := javaProc{pid: p.PID, ppid: p.PPID, exe: p.Name, parent: names[p.PPID]}
		jp.image = processImage(p.PID)
		jp.cmd = processCmdline(p.PID)
		jp.started, _ = processStart(p.PID)
		low := strings.ToLower(jp.cmd)
		// skip java processes that aren't the game (launcher helpers, IDE daemons)
		if jp.cmd != "" && !strings.Contains(low, "minecraft") && !strings.Contains(low, "--gamedir") &&
			!strings.Contains(low, "lunar") && !strings.Contains(low, "net.fabricmc") && !strings.Contains(low, "feather") {
			row("INFO", "java (not the game)", fmt.Sprintf("pid %d", p.PID), cut(jp.cmd, 60))
			continue
		}
		games = append(games, jp)
	}

	if len(games) == 0 {
		section("Minecraft process")
		row("WARN", "javaw.exe", "not running", "open Minecraft and run this again, most checks need the game open")
		return
	}

	for _, jp := range games {
		section(fmt.Sprintf("%s  ·  pid %d", jp.exe, jp.pid))
		up := ""
		if !jp.started.IsZero() {
			up = "started " + jp.started.Format("15:04:05") + " · " + ago(jp.started)
		}
		row("INFO", "Java", cut(orDash(jp.image), 56), up)
		parent := jp.parent
		if parent == "" {
			parent = "(already closed)"
		}
		row("INFO", "Started by", parent, fmt.Sprintf("pid %d", jp.ppid))

		if jp.cmd == "" {
			row("WARN", "Command line", "couldn't read it", "run the toolkit as admin")
		} else {
			inspectJavaArgs(jp)
		}
		inspectModules(jp)
	}
}

func orDash(s string) string {
	if s == "" {
		return "-"
	}
	return s
}

func unq(s string) string { return strings.Trim(s, `"`) }

func inspectJavaArgs(jp javaProc) {
	c := jp.cmd
	if m := reGameDir.FindStringSubmatch(c); m != nil {
		row("INFO", "Game folder", cut(unq(m[1]), 56), "")
	}
	v, u := "", ""
	if m := reVersionArg.FindStringSubmatch(c); m != nil {
		v = unq(m[1])
	}
	if m := reUserArg.FindStringSubmatch(c); m != nil {
		noteAccount(unq(m[1]))
		u = "account: " + unq(m[1])
	}
	if v != "" || u != "" {
		row("INFO", "Version", orDash(v), u)
	}

	clean := true
	for _, m := range reAgent.FindAllStringSubmatch(c, -1) {
		clean = false
		p := unq(m[1])
		if i := strings.Index(strings.ToLower(p), ".jar="); i > 0 {
			p = p[:i+4] // drop agent options
		}
		level, why := "WARN", "java agent (launchers sometimes use these)"
		switch {
		case reUserDirs.MatchString(p):
			level, why = "FAIL", "java agent loaded from a user folder"
		case !exists(p):
			level, why = "FAIL", "java agent whose file is gone now"
		case !reLauncherOK.MatchString(p):
			level, why = "FAIL", "java agent outside every launcher folder"
		}
		if fl := exeFlags(filepath.Base(p)); len(fl) > 0 {
			level, why = "FAIL", "java agent · "+fl[0].label
		}
		row(level, "-javaagent", cut(filepath.Base(p), 40), why)
		sub(p, "DarkGray")
	}
	for _, m := range reAgentPath.FindAllStringSubmatch(c, -1) {
		clean = false
		p := unq(m[2])
		if strings.HasPrefix(strings.ToLower(p), "jdwp") {
			row("WARN", "-agentlib:jdwp", "debugger attached", "lets another program step through / change the game")
			continue
		}
		row("FAIL", "-agent"+m[1], cut(p, 40), "native agent loaded into the game")
	}
	for _, m := range reBootCP.FindAllStringSubmatch(c, -1) {
		clean = false
		row("WARN", "-Xbootclasspath", cut(unq(m[2]), 50), "extra classes loaded before the game")
	}
	for _, m := range reAddMods.FindAllStringSubmatch(c, -1) {
		clean = false
		// some launchers (Dawn, Lunar...) load mods from their own cache with this, so judge each path
		for _, part := range strings.Split(unq(m[2]), ";") { // java on windows separates paths with ;
			if part == "" {
				continue
			}
			level, why := "FAIL", "loads mods from OUTSIDE the mods folder"
			switch {
			case reUserHard.MatchString(part) || reUserDirs.MatchString(part):
				level, why = "FAIL", "loads mods from a user / temp folder"
			case reLauncherOK.MatchString(part):
				level, why = "INFO", "launcher loads its mods from its own folder"
			case reDotAppData.MatchString(part):
				level, why = "WARN", "loads mods from an unknown launcher folder, check what's in it"
			}
			// whatever the folder, cheat-named jars in it are a fail
			var bad []string
			for _, name := range jarNamesIn(part) {
				if len(exeFlags(name)) > 0 || reClientLog.MatchString(name) {
					bad = append(bad, name)
				}
			}
			if len(bad) > 0 {
				level, why = "FAIL", "cheat-named jar loaded through "+m[1]+": "+strings.Join(bad, ", ")
			}
			row(level, "-D"+m[1], cut(part, 50), why)
		}
	}
	if reNoVerify.MatchString(c) {
		clean = false
		row("WARN", "Bytecode verify", "turned off", "common with injected code")
	}

	// classpath entries sitting in odd places
	if m := reCPArg.FindStringSubmatch(c); m != nil {
		var odd []string
		entries := strings.Split(unq(m[1]), ";")
		for _, e := range entries {
			if e == "" {
				continue
			}
			if reUserDirs.MatchString(e) || (!reLauncherOK.MatchString(e) && !strings.Contains(strings.ToLower(e), `\libraries\`) && !strings.Contains(strings.ToLower(e), `\versions\`)) {
				odd = append(odd, e)
			}
		}
		if len(odd) > 0 {
			clean = false
			row("WARN", "Classpath", fmt.Sprintf("%d jar(s) from odd places", len(odd)), fmt.Sprintf("of %d", len(entries)))
			for i, o := range odd {
				if i == 8 {
					sub(fmt.Sprintf("... and %d more", len(odd)-8), "DarkGray")
					break
				}
				sub(o, "Yellow")
			}
		} else {
			row("OK", "Classpath", fmt.Sprintf("%d entries", len(entries)), "all inside launcher folders")
		}
	}
	if clean {
		row("OK", "Startup args", "no agents / extra mod paths", "")
	}
	report.WriteString("   full command line:\r\n   " + c + "\r\n")
}

func inspectModules(jp javaProc) {
	mods, ok := processModules(jp.pid)
	if !ok {
		row("WARN", "Loaded DLLs", "couldn't read them", "run the toolkit as admin")
		return
	}
	win := strings.ToLower(os.Getenv("SystemRoot"))
	if win == "" {
		win = `c:\windows`
	}
	javaHome := ""
	if jp.image != "" {
		javaHome = strings.ToLower(filepath.Dir(filepath.Dir(jp.image)))
	}
	var overlays, odd []string
	oddLevel := map[string]string{}
	for _, m := range mods {
		low := strings.ToLower(m)
		base := filepath.Base(m)
		if strings.HasPrefix(low, win+`\`) || (javaHome != "" && strings.HasPrefix(low, javaHome+`\`)) ||
			strings.HasSuffix(low, ".exe") {
			continue
		}
		matched := false
		for _, o := range knownOverlays {
			if o.re.MatchString(base) {
				overlays = append(overlays, o.label+" · "+base)
				matched = true
				break
			}
		}
		if matched {
			continue
		}
		// LWJGL / java natives get unpacked into temp or the launcher folders at launch
		nativeSpot := strings.Contains(low, `\temp\`) || reLauncherOK.MatchString(m) || reDotAppData.MatchString(m) || strings.Contains(low, "natives")
		if reLwjglTemp.MatchString(base) && nativeSpot {
			continue
		}
		if reJavaNative.MatchString(base) && nativeSpot && len(exeFlags(base)) == 0 {
			overlays = append(overlays, "java native library · "+base)
			continue
		}
		if strings.Contains(low, `\program files`) && !reUserDirs.MatchString(m) {
			overlays = append(overlays, "installed program · "+base)
			continue
		}
		odd = append(odd, m)
		lvl := "WARN"
		if reUserHard.MatchString(m) || len(exeFlags(base)) > 0 {
			lvl = "FAIL"
		}
		if !exists(m) {
			lvl = "FAIL"
		}
		oddLevel[m] = lvl
	}
	row("INFO", "Loaded DLLs", fmt.Sprintf("%d", len(mods)), "")
	sort.Strings(overlays)
	for _, o := range dedupe(overlays) {
		outln("          │   ↳ "+o, "DarkGray")
	}
	if len(odd) == 0 {
		row("OK", "Unknown DLLs", "none", "nothing injected from odd places")
		return
	}
	for _, m := range odd {
		why := "dll from an unusual folder"
		if !exists(m) {
			why = "dll whose file was deleted after loading"
		} else if reUserHard.MatchString(m) {
			why = "dll loaded from a user folder"
		} else if strings.Contains(strings.ToLower(m), `\temp\`) {
			why = "unknown dll from temp"
		}
		if fl := exeFlags(filepath.Base(m)); len(fl) > 0 {
			why = fl[0].label
		}
		row(oddLevel[m], cut(filepath.Base(m), 24), why, "")
		sub(m, "DarkGray")
	}
}

func dedupe(xs []string) []string {
	var out []string
	for i, x := range xs {
		if i == 0 || x != xs[i-1] {
			out = append(out, x)
		}
	}
	return out
}

// jarNamesIn lists jar names in a folder (or the file itself if it's a jar).
func jarNamesIn(p string) []string {
	if strings.HasSuffix(strings.ToLower(p), ".jar") {
		return []string{filepath.Base(p)}
	}
	return listJarNames(p)
}
