package main

import (
	"strings"
	"time"
)

type driveInfo struct {
	Letter      string // "C:"
	Type        int
	FS, Label   string
	Free, Total uint64
}

const (
	driveRemovable = 2
	driveFixed     = 3
	driveRemote    = 4
	driveCDROM     = 5
	driveRAMDisk   = 6
)

func driveTypeName(t int) string {
	switch t {
	case driveRemovable:
		return "removable"
	case driveFixed:
		return "local"
	case driveRemote:
		return "network"
	case driveRAMDisk:
		return "ram disk"
	}
	return "other"
}

type svcInfo struct {
	State     int
	StartType int
	PID       uint32
}

const stateRunning = 4

func stateName(s int) string {
	switch s {
	case 1:
		return "stopped"
	case 2:
		return "starting"
	case 3:
		return "stopping"
	case 4:
		return "running"
	case 5:
		return "resuming"
	case 6:
		return "pausing"
	case 7:
		return "paused"
	}
	return "unknown"
}

func startTypeName(t int) string {
	switch t {
	case 0:
		return "boot"
	case 1:
		return "system"
	case 2:
		return "auto"
	case 3:
		return "manual"
	case 4:
		return "disabled"
	}
	return "unknown"
}

type regRoot int

const (
	hkcu regRoot = iota
	hklm
)

// one rendered event log record
type winEvent struct {
	ID       int
	Level    int
	Time     time.Time
	Provider string
	Data     map[string]string // named <Data Name="..."> values
	List     []string          // every <Data> value in order
}

func (e winEvent) all() string { return strings.Join(e.List, "\n") }

type regValue struct {
	Name string
	Type uint32
	Data []byte
}

type procInfo struct {
	PID, PPID uint32
	Name      string
}

type usnJournal struct {
	ID       uint64
	FirstUsn int64
	NextUsn  int64
	MaxSize  uint64
}
