// KETTEHPOT - everything for a Minecraft screenshare in one exe
// By | Ketteh & Applepot · discord: zoe_mahhh
package main

import (
	"bufio"
	"fmt"
	"os"
	"os/exec"
	"path/filepath"
	"strings"
	"time"
)

const version = "1.3"

// set at build time to make the KettehLyzer exe: -X main.defaultMode=lyzer
var defaultMode = ""

// shown everywhere the toolkit credits its makers
const credits = "By | Ketteh & Applepot"

// ════════════════════════════════════════════════════════════════════
//  output (everything printed also goes into the report)
// ════════════════════════════════════════════════════════════════════

var (
	colorsOn = true
	report   strings.Builder
	findings []finding
	module   = "" // which tool is running, for the summary
	stdin    = bufio.NewReader(os.Stdin)
)

type finding struct{ module, level, text string }

var ansi = map[string]string{
	"Gray": "37", "White": "97", "DarkGray": "90", "Cyan": "96", "DarkCyan": "36",
	"Green": "92", "Yellow": "93", "Red": "91", "Magenta": "95", "DarkMagenta": "35",
	"DarkYellow": "33",
}

func out(text, color string, newline bool) {
	if gui {
		if structDepth == 0 {
			guiText(text, color, newline)
		}
		report.WriteString(text)
		if newline {
			report.WriteString("\r\n")
		}
		return
	}
	if colorsOn && text != "" {
		fmt.Printf("\x1b[%sm%s\x1b[0m", ansi[color], text)
	} else {
		fmt.Print(text)
	}
	report.WriteString(text)
	if newline {
		fmt.Println()
		report.WriteString("\r\n")
	}
}

func outln(text, color string) { out(text, color, true) }
func outn(text, color string)  { out(text, color, false) }
func blank()                   { outln("", "Gray") }

// printing that should not go into the report
func colorPart(text, color string) {
	if gui {
		guiNote(text, color, false)
		return
	}
	if colorsOn {
		fmt.Printf("\x1b[%sm%s\x1b[0m", ansi[color], text)
	} else {
		fmt.Print(text)
	}
}
func colorPrint(text, color string) {
	if gui {
		guiNote(text, color, true)
		return
	}
	colorPart(text, color)
	fmt.Println()
}

func pad(s string, n int) string {
	if c := len([]rune(s)); c < n {
		return s + strings.Repeat(" ", n-c)
	}
	return s
}

func cut(s string, n int) string {
	r := []rune(s)
	if len(r) <= n {
		return s
	}
	return string(r[:n-1]) + "…"
}

// toolCancelled is set by tools that ask for a path when the user backs out
var toolCancelled bool

func plural(n int, word string) string {
	if n == 1 {
		return "1 " + word
	}
	return fmt.Sprintf("%d %ss", n, word)
}

// progress is shown next to each title during Run everything, like [3/13]
var progress string

func title(name string) {
	structDepth++
	defer func() { structDepth-- }()
	blank()
	outln("  ════════════════════════════════════════════════════════════════", "DarkMagenta")
	outn("   ✦ ", "Magenta")
	if progress != "" {
		outn(strings.ToUpper(name), "White")
		outln("   "+progress, "DarkGray")
	} else {
		outln(strings.ToUpper(name), "White")
	}
	outln("  ════════════════════════════════════════════════════════════════", "DarkMagenta")
}

func section(t string) {
	emit(map[string]any{"type": "section", "text": t})
	structDepth++
	defer func() { structDepth-- }()
	blank()
	outn("  ▌ ", "Magenta")
	outn(strings.ToUpper(t)+" ", "White")
	n := 58 - len([]rune(t))
	if n < 4 {
		n = 4
	}
	outln(strings.Repeat("─", n), "DarkMagenta")
}

var chips = map[string][3]string{
	"OK":   {"  ok  ", "Green", "Gray"},
	"WARN": {" warn ", "Yellow", "Yellow"},
	"FAIL": {" fail ", "Red", "Red"},
	"INFO": {" info ", "Cyan", "Gray"},
}

func row(level, label, value, extra string) {
	emit(map[string]any{"type": "row", "level": level, "label": label, "value": value, "extra": extra})
	structDepth++
	defer func() { structDepth-- }()
	c := chips[level]
	outn("   ", "Gray")
	outn(c[0], c[1])
	outn(" │ ", "DarkGray")
	outn(pad(label, 24), "White")
	if extra != "" {
		outn(value, c[2])
		outln("   "+extra, "DarkGray")
	} else {
		outln(value, c[2])
	}
	if level == "WARN" || level == "FAIL" {
		flag(level, label+" · "+value)
	}
}

func flag(level, text string) {
	findings = append(findings, finding{module, level, text})
}

func sub(text, color string) {
	emit(map[string]any{"type": "sub", "text": text, "color": color})
	structDepth++
	defer func() { structDepth-- }()
	outln("          │   ↳ "+text, color)
}

// ago says how long ago t was and, once the SS start is known, how that sits against it.
func ago(t time.Time) string {
	s := agoPlain(t)
	if ssStart.IsZero() || t.IsZero() {
		return s
	}
	d := ssStart.Sub(t)
	switch {
	case d <= 0:
		return s + " · DURING the SS"
	case d < 3*time.Hour:
		return s + " · " + shortDur(d) + " before the SS"
	}
	return s
}

func shortDur(d time.Duration) string {
	if d < time.Minute {
		return "<1m"
	}
	if d < time.Hour {
		return fmt.Sprintf("%dm", int(d.Minutes()))
	}
	return fmt.Sprintf("%dh %dm", int(d.Hours()), int(d.Minutes())%60)
}

// ssStart is when the player was frozen / called in (asked at launch).
var ssStart time.Time

// askSSStart asks when the SS began; enter = right now.
func askSSStart() {
	if gui {
		a := guiAsk("time", "When was the player frozen?", "Times in the results will show how long before the SS things happened.", map[string]any{"now": time.Now().Format("15:04")})
		ssStart = parseSSTime(a)
		emit(map[string]any{"type": "ss_start", "key": "", "time": ssStart.Format("3:04 PM"), "unix": ssStart.Unix()})
		return
	}
	fmt.Println()
	for {
		colorPart("   when was the player frozen? ", "White")
		colorPart("(like 23:41 or 11:41pm, enter = now) ", "DarkGray")
		line, _ := stdin.ReadString('\n')
		a := strings.ToLower(strings.ReplaceAll(strings.TrimSpace(line), " ", ""))
		if a == "" {
			ssStart = time.Now()
			return
		}
		now := time.Now()
		for _, layout := range []string{"15:04", "3:04pm", "3pm", "15"} {
			if t, err := time.ParseInLocation(layout, a, time.Local); err == nil {
				ssStart = time.Date(now.Year(), now.Month(), now.Day(), t.Hour(), t.Minute(), 0, 0, time.Local)
				if ssStart.After(now.Add(5 * time.Minute)) {
					ssStart = ssStart.AddDate(0, 0, -1) // "23:50" typed just after midnight
				}
				colorPrint("   ok, SS started "+ssStart.Format("3:04 PM")+" · every time now shows how long before the SS it happened", "DarkGray")
				return
			}
		}
		colorPrint("   couldn't read that, try like 23:41", "DarkGray")
	}
}

// parseSSTime reads "23:41" / "11:41pm"; anything else = now.
func parseSSTime(a string) time.Time {
	a = strings.ToLower(strings.ReplaceAll(strings.TrimSpace(a), " ", ""))
	now := time.Now()
	for _, layout := range []string{"15:04", "3:04pm", "3pm", "15"} {
		if t, err := time.ParseInLocation(layout, a, time.Local); err == nil {
			s := time.Date(now.Year(), now.Month(), now.Day(), t.Hour(), t.Minute(), 0, 0, time.Local)
			if s.After(now.Add(5 * time.Minute)) {
				s = s.AddDate(0, 0, -1)
			}
			return s
		}
	}
	return now
}

func agoPlain(t time.Time) string {
	d := time.Since(t)
	switch {
	case d < 0:
		return "in the future?"
	case d < time.Minute:
		return "just now"
	case d < time.Hour:
		return fmt.Sprintf("%dm ago", int(d.Minutes()))
	case d < 24*time.Hour:
		return fmt.Sprintf("%dh %dm ago", int(d.Hours()), int(d.Minutes())%60)
	}
	return fmt.Sprintf("%dd %dh ago", int(d.Hours())/24, int(d.Hours())%24)
}

func ts(t time.Time) string { return t.Format("2006-01-02 15:04:05") }

func sizeText(b float64) string {
	switch {
	case b >= 1<<30:
		return fmt.Sprintf("%.1f GB", b/(1<<30))
	case b >= 1<<20:
		return fmt.Sprintf("%.1f MB", b/(1<<20))
	case b >= 1<<10:
		return fmt.Sprintf("%.1f KB", b/(1<<10))
	}
	return fmt.Sprintf("%d B", int64(b))
}

func readHost(prompt string) string {
	if gui {
		return guiAsk("text", "", strings.TrimSuffix(strings.TrimSpace(prompt), ">"), nil)
	}
	fmt.Print(prompt + " ")
	line, _ := stdin.ReadString('\n')
	return strings.TrimRight(line, "\r\n")
}

func isYes(s string) bool {
	s = strings.ToLower(strings.TrimSpace(s))
	return s == "y" || s == "yes"
}

func askYesNo(prompt string) bool {
	if gui {
		q := strings.TrimSpace(strings.TrimSuffix(strings.TrimSpace(prompt), "(y/n)"))
		return guiAsk("yesno", "", q, nil) == "y"
	}
	for {
		colorPart(prompt+" ", "Magenta")
		line, err := stdin.ReadString('\n')
		a := strings.ToLower(strings.TrimSpace(line))
		switch a {
		case "y", "yes":
			return true
		case "n", "no":
			return false
		}
		if err != nil {
			return false
		}
		colorPrint("   just type y or n", "DarkGray")
	}
}

func isDir(p string) bool {
	st, err := os.Stat(p)
	return err == nil && st.IsDir()
}

func exists(p string) bool {
	_, err := os.Stat(p)
	return err == nil
}

// writes a UTF-8 (with BOM, so notepad is happy) text file
func writeText(path, text string) error {
	return os.WriteFile(path, append([]byte("\xEF\xBB\xBF"), strings.ReplaceAll(strings.ReplaceAll(text, "\r\n", "\n"), "\n", "\r\n")...), 0o644)
}

func openInNotepad(path string) bool {
	return exec.Command("notepad.exe", path).Start() == nil
}

func outputDir() string {
	d := filepath.Join(desktopDir(), "KettehPot")
	if os.MkdirAll(d, 0o755) != nil {
		return desktopDir()
	}
	return d
}

// ════════════════════════════════════════════════════════════════════
//  menu
// ════════════════════════════════════════════════════════════════════

func banner() {
	if colorsOn {
		fmt.Print("\x1b[2J\x1b[3J\x1b[H")
	}
	lines := [][2]string{
		{" ██╗  ██╗███████╗████████╗████████╗███████╗██╗  ██╗", "Magenta"},
		{" ██║ ██╔╝██╔════╝╚══██╔══╝╚══██╔══╝██╔════╝██║  ██║", "Magenta"},
		{" █████╔╝ █████╗     ██║      ██║   █████╗  ███████║", "DarkMagenta"},
		{" ██╔═██╗ ██╔══╝     ██║      ██║   ██╔══╝  ██╔══██║", "DarkMagenta"},
		{" ██║  ██╗███████╗   ██║      ██║   ███████╗██║  ██║", "Cyan"},
		{" ╚═╝  ╚═╝╚══════╝   ╚═╝      ╚═╝   ╚══════╝╚═╝  ╚═╝", "DarkCyan"},
	}
	fmt.Println()
	for _, l := range lines {
		colorPrint("  "+l[0], l[1])
	}
	fmt.Println()
	colorPart("            k e t t e h p o t   ·   s s", "White")
	colorPrint("   v"+version, "DarkGray")
	colorPart("        By ", "DarkGray")
	colorPart("│ ", "Magenta")
	colorPart("Ketteh", "White")
	colorPart(" & ", "DarkGray")
	colorPart("Applepot  ", "White")
	colorPart("·", "Magenta")
	colorPart("  discord: zoe_mahhh  ", "DarkGray")
	colorPrint("</3", "Magenta")
}

type tool struct {
	key, name, desc string
	run             func()
	inAll           bool
}

var tools []tool

func init() {
	tools = []tool{
		{"1", "Service Checker", "services, registry, event logs, prefetch folder, recycle bin", runServices, true},
		{"2", "Tamper Check", "log wipes, journal resets, time changes, cleaners, exclusions", runTamper, true},
		{"3", "Execution History", "every program run recently (BAM + Prefetch), deleted exes", runExecution, true},
		{"4", "Deleted Files", "jars / exes deleted or renamed in the last 24h (USN journal)", runDeleted, true},
		{"5", "PowerShell Inspector", "powershell commands ran in the last 10 hours", runPowerShell, true},
		{"6", "Minecraft Instances", "every launcher's instances, last played, removed mods, Modrinth check", runInstances, true},
		{"7", "javaw Inspector", "what's loaded into the running Minecraft (agents, DLLs, args)", runJavaw, true},
		{"8", "Macro Check", "mouse software macros, autoclickers, AutoHotkey", runMacros, true},
		{"9", "Memory Strings", "cheat names in Minecraft's memory, programs seen by DPS / PcaSvc", runMemory, true},
		{"10", "USB & Devices", "usb sticks and phones plugged in recently", runUSB, true},
		{"11", "Recent Activity", "opened files / folders, UserAssist, Win+R history", runRecent, true},
		{"12", "DNS History", "sites looked up recently, cheat client + file sharing sites", runDNS, true},
		{"13", "Alt Accounts", "every minecraft account used on this pc", runAccounts, true},
		{"14", "Log Analyzer", "pick a logs folder / log file: removed mods, cheat traces, kicks", runLogs, false},
		{"15", "KettehLyzer", "deep scan a mods folder for cheat strings / bypasses", runLyzer, false},
	}
}

func menu() {
	fmt.Println()
	colorPrint("  ────────────────────────────────────────────────────────────────", "DarkMagenta")
	colorPart("   [", "DarkGray")
	colorPart("A", "Magenta")
	colorPart("]   ", "DarkGray")
	colorPart(pad("Run everything", 22), "White")
	colorPrint("tools 1-13, one after another", "DarkGray")
	for _, t := range tools {
		colorPart("   [", "DarkGray")
		colorPart(t.key, "Magenta")
		colorPart("]"+strings.Repeat(" ", 4-len(t.key)), "DarkGray")
		colorPart(pad(t.name, 22), "White")
		colorPrint(t.desc, "DarkGray")
	}
	colorPart("   [", "DarkGray")
	colorPart("S", "Magenta")
	colorPart("]   ", "DarkGray")
	colorPart(pad("Save report", 22), "White")
	colorPrint("everything shown so far -> txt", "DarkGray")
	colorPart("   [", "DarkGray")
	colorPart("W", "Magenta")
	colorPart("]   ", "DarkGray")
	colorPart(pad("Send to Discord", 22), "White")
	colorPrint("results go there by themselves, this re-sends", "DarkGray")
	colorPart("   [", "DarkGray")
	colorPart("Q", "Magenta")
	colorPart("]   ", "DarkGray")
	colorPrint("Quit", "White")
	colorPrint("  ────────────────────────────────────────────────────────────────", "DarkMagenta")
}

func runTool(t tool) {
	module = t.name
	guiTool = t.key
	before := len(findings)
	started := time.Now()
	emit(map[string]any{"type": "tool_start", "name": t.name, "progress": progress})
	title(t.name)
	crashed := ""
	toolCancelled = false
	func() {
		defer func() {
			if r := recover(); r != nil {
				crashed = fmt.Sprint(r)
				outln(fmt.Sprintf("   %s hit an error: %v", t.name, r), "Red")
			}
		}()
		t.run()
	}()
	took := time.Since(started)
	if toolCancelled { // backed out of a picker: nothing ran, nothing to report
		toolCancelled = false
		emit(map[string]any{"type": "tool_end", "cancelled": true})
		colorPrint("   cancelled", "DarkGray")
		return
	}
	toolSummary(t.name, findings[before:], took)
	fails, warns := 0, 0
	for _, f := range findings[before:] {
		if f.level == "FAIL" {
			fails++
		} else {
			warns++
		}
	}
	emit(map[string]any{"type": "tool_end", "fails": fails, "warns": warns, "took": took.Seconds(), "crashed": crashed})

	// keep the staff discord message up to date
	order := 0
	for i, x := range tools {
		if x.name == t.name {
			order = i
		}
	}
	recordRun(order, t.name, findings[before:], took, crashed)
	if findWebhook() != "" {
		if syncWebhook(false) {
			colorPrint("   ↳ sent to staff discord", "DarkGray")
		}
	}
}

func toolSummary(name string, fs []finding, took time.Duration) {
	structDepth++
	defer func() { structDepth-- }()
	blank()
	fails, warns := 0, 0
	for _, f := range fs {
		if f.level == "FAIL" {
			fails++
		} else {
			warns++
		}
	}
	outn("   ", "Gray")
	switch {
	case fails > 0:
		outn(" fail ", "Red")
		outn(" │ ", "DarkGray")
		outn(fmt.Sprintf("%s: %d fail, %d warn", strings.ToLower(name), fails, warns), "Red")
	case warns > 0:
		outn(" warn ", "Yellow")
		outn(" │ ", "DarkGray")
		outn(fmt.Sprintf("%s: %d warning(s)", strings.ToLower(name), warns), "Yellow")
	default:
		outn("  ok  ", "Green")
		outn(" │ ", "DarkGray")
		outn(strings.ToLower(name)+": nothing suspicious", "Green")
	}
	outln(fmt.Sprintf("   (%.1fs)", took.Seconds()), "DarkGray")
}

func finalSummary() {
	summaryEvent()
	structDepth++
	defer func() { structDepth-- }()
	title("Summary")
	var fails, warns []finding
	for _, f := range findings {
		if f.level == "FAIL" {
			fails = append(fails, f)
		} else {
			warns = append(warns, f)
		}
	}
	if len(fails)+len(warns) == 0 {
		outln("     nothing suspicious found </3", "Green")
		return
	}
	outln(fmt.Sprintf("     %d fail  ·  %d warn", len(fails), len(warns)), "White")
	blank()
	for _, f := range fails {
		outn("     ✗ ", "Red")
		outn(pad("["+f.module+"]", 24), "DarkGray")
		outln(f.text, "Red")
	}
	for _, f := range warns {
		outn("     ! ", "Yellow")
		outn(pad("["+f.module+"]", 24), "DarkGray")
		outln(f.text, "Yellow")
	}
}

func saveReport() {
	path := filepath.Join(outputDir(), "kettehpot_report_"+time.Now().Format("2006-01-02_15-04-05")+".txt")
	if err := writeText(path, fullReport()); err != nil {
		colorPrint("   couldn't save the report: "+err.Error(), "Red")
		return
	}
	colorPrint("   saved -> "+path, "Green")
	if askYesNo("   open it now? (y/n)") {
		openInNotepad(path)
	}
}

func main() {
	colorsOn = setupConsole("KettehPot v" + version + "  ·  zoe_mahhh")
	consoleMode := false
	lyzerMode := defaultMode == "lyzer"
	serveOnly := false
	for _, a := range os.Args[1:] {
		switch strings.ToLower(strings.TrimLeft(a, "-/")) {
		case "console", "c", "cli":
			consoleMode = true
		case "serve":
			serveOnly = true
		case "lyzer", "kettehlyzer":
			lyzerMode = true
		}
	}
	if lyzerMode {
		setupConsole("KettehLyzer  ·  " + credits)
	}
	if lyzerMode && runLyzerStandalone() {
		return
	}
	if !consoleMode && runGUI(serveOnly) {
		return
	}
	banner()
	if !isAdmin() {
		fmt.Println()
		colorPrint("   not running as admin </3  ·  a lot of checks need it", "Magenta")
		colorPrint("   right-click the exe -> Run as administrator", "DarkGray")
	}
	host, _ := os.Hostname()
	askSSStart()
	report.WriteString("computer: " + host + "  ·  user: " + currentUser() + "  ·  SS started " + ts(ssStart) + "\r\n")

	for {
		menu()
		choice := strings.ToLower(strings.TrimSpace(readHost("   pick one >")))
		switch choice {
		case "a", "all":
			runAll()
		case "s", "save":
			saveReport()
		case "w", "webhook", "discord":
			sendWebhook()
		case "q", "quit", "exit", "":
			if choice == "" {
				continue
			}
			fmt.Println()
			colorPart("   "+credits+"  ", "Gray")
			colorPart("·", "Magenta")
			colorPart("  issues? discord: ", "Gray")
			colorPart("zoe_mahhh", "Magenta")
			colorPrint("  </3", "DarkMagenta")
			fmt.Println()
			return
		default:
			found := false
			for _, t := range tools {
				if t.key == choice || strings.EqualFold(t.name, choice) {
					runTool(t)
					found = true
				}
			}
			if !found {
				colorPrint("   that's not an option", "DarkGray")
			}
		}
	}
}

// runGUI opens the window and serves it until it's closed. false = use the console instead.
func runGUI(serveOnly bool) bool {
	url, err := startGUI()
	if err != nil {
		return false
	}
	gui = true
	colorsOn = false
	if serveOnly {
		fmt.Println(url) // for testing in a normal browser
	} else if !openAppWindow(url) {
		gui = false
		return false
	}
	fmt.Println("   KettehPot is open in its own window. Closing that window quits.")
	if !serveOnly && !waitConnected(25*time.Second) {
		gui = false // window never showed up: fall back to the console
		return false
	}
	if !serveOnly {
		showConsole(false)
	}
	helloEvent()
	host, _ := os.Hostname()
	askSSStart()
	report.WriteString("computer: " + host + "  ·  user: " + currentUser() + "  ·  SS started " + ts(ssStart) + "\r\n")
	emit(map[string]any{"type": "ready", "key": ""})
	watchWindow() // blocks; exits the program when the window closes
	return true
}
