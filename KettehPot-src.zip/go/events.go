package main

import (
	"encoding/xml"
	"regexp"
	"strings"
	"time"
)

type evXML struct {
	System struct {
		Provider struct {
			Name string `xml:"Name,attr"`
		} `xml:"Provider"`
		EventID     int `xml:"EventID"`
		Level       int `xml:"Level"`
		TimeCreated struct {
			SystemTime string `xml:"SystemTime,attr"`
		} `xml:"TimeCreated"`
	} `xml:"System"`
	EventData struct {
		Data []struct {
			Name  string `xml:"Name,attr"`
			Value string `xml:",chardata"`
		} `xml:"Data"`
	} `xml:"EventData"`
	UserData struct {
		Inner string `xml:",innerxml"`
	} `xml:"UserData"`
}

// <UserData><LogFileCleared><SubjectUserName>x</SubjectUserName>... (log-cleared events use this)
var reUserDataField = regexp.MustCompile(`<(\w+)(?:\s[^>]*)?>([^<]*)</\w+>`)

// parseEventXML turns EvtRender's XML into a winEvent.
func parseEventXML(s string) (winEvent, bool) {
	var x evXML
	if err := xml.Unmarshal([]byte(s), &x); err != nil {
		return winEvent{}, false
	}
	t, err := time.Parse(time.RFC3339Nano, x.System.TimeCreated.SystemTime)
	if err != nil {
		return winEvent{}, false
	}
	e := winEvent{ID: x.System.EventID, Level: x.System.Level, Time: t.Local(), Provider: x.System.Provider.Name, Data: map[string]string{}}
	for _, d := range x.EventData.Data {
		v := strings.TrimSpace(d.Value)
		if d.Name != "" {
			e.Data[d.Name] = v
		}
		e.List = append(e.List, v)
	}
	for _, m := range reUserDataField.FindAllStringSubmatch(x.UserData.Inner, -1) {
		v := strings.TrimSpace(m[2])
		if _, ok := e.Data[m[1]]; !ok {
			e.Data[m[1]] = v
		}
		e.List = append(e.List, v)
	}
	return e, true
}

// sinceQuery builds an XPath for some event IDs within the last d.
func sinceQuery(d time.Duration, ids ...int) string {
	q := "*[System["
	if len(ids) > 0 {
		parts := make([]string, len(ids))
		for i, id := range ids {
			parts[i] = "EventID=" + itoa(id)
		}
		q += "(" + strings.Join(parts, " or ") + ") and "
	}
	return q + "TimeCreated[timediff(@SystemTime) <= " + itoa(int(d/time.Millisecond)) + "]]]"
}

func itoa(i int) string {
	if i == 0 {
		return "0"
	}
	neg := i < 0
	if neg {
		i = -i
	}
	var b []byte
	for i > 0 {
		b = append([]byte{byte('0' + i%10)}, b...)
		i /= 10
	}
	if neg {
		return "-" + string(b)
	}
	return string(b)
}
