// USB & Devices: drives and phones plugged in recently, so a cheat run off a stick still shows.
package main

import (
	"fmt"
	"sort"
	"strconv"
	"strings"
	"time"
	"unicode/utf16"
)

const usbWindow = 7 * 24 * time.Hour

type usbDevice struct {
	name     string
	serial   string
	changed  time.Time
	instance string
}

func runUSB() {
	// ---------------- connected right now
	section("Connected right now")
	any := false
	for _, d := range listDrives() {
		if d.Type == driveRemovable || d.Type == driveRemote {
			any = true
			label := d.Label
			if label == "" {
				label = "no label"
			}
			row("WARN", d.Letter, driveTypeName(d.Type)+" · "+label, sizeText(float64(d.Total)))
		}
	}
	if !any {
		row("OK", "Removable drives", "none plugged in", "")
	}

	// ---------------- every USB storage device Windows remembers
	section("USB storage ever connected")
	const stor = `SYSTEM\CurrentControlSet\Enum\USBSTOR`
	var devs []usbDevice
	if classes, ok := regSubkeys(hklm, stor); ok {
		for _, c := range classes {
			serials, _ := regSubkeys(hklm, stor+`\`+c)
			for _, s := range serials {
				key := stor + `\` + c + `\` + s
				d := usbDevice{serial: s, instance: c}
				d.name, _ = regString(hklm, key, "FriendlyName")
				if d.name == "" {
					d.name = prettyUSBClass(c)
				}
				d.changed, _ = regKeyTime(hklm, key)
				devs = append(devs, d)
			}
		}
	} else {
		row("WARN", "USBSTOR", "couldn't read it", "run as admin")
	}
	sort.Slice(devs, func(i, j int) bool { return devs[i].changed.After(devs[j].changed) })
	if len(devs) == 0 {
		row("OK", "USB storage", "none on record", "")
	}
	for i, d := range devs {
		if i == 15 {
			outln(fmt.Sprintf("   ... %d older devices in the saved report", len(devs)-15), "DarkGray")
		}
		line := fmt.Sprintf("serial %s", cut(strings.Split(d.serial, "&")[0], 24))
		if i >= 15 {
			report.WriteString(fmt.Sprintf("   %s  %s  %s\r\n", ts(d.changed), d.name, line))
			continue
		}
		lvl := "INFO"
		when := "last change " + ago(d.changed)
		if !d.changed.IsZero() && time.Since(d.changed) < 2*time.Hour {
			lvl = "WARN"
			when = "used " + ago(d.changed) + " · right before the SS?"
		}
		row(lvl, cut(d.name, 24), line, when)
	}

	// ---------------- connect / disconnect events
	section("Plug-in history  ·  last 7 days")
	type ev struct {
		t    time.Time
		what string
		name string
	}
	var evs []ev
	if list, err := queryEvents("Microsoft-Windows-Partition/Diagnostic", sinceQuery(usbWindow, 1006), 400); err == nil {
		for _, e := range list {
			name := strings.TrimSpace(firstNonEmpty(e.Data["Manufacturer"]+" "+e.Data["Model"], e.Data["Model"]))
			if name == "" {
				continue
			}
			bus := e.Data["BusType"]
			// keep usb (7) and sd (12); internal sata / nvme disks also log this at every boot
			ub := strings.ToUpper(bus)
			if bus != "" && bus != "7" && bus != "12" && !strings.Contains(ub, "USB") && !strings.Contains(ub, "SD") {
				continue
			}
			what := "connected"
			if c, _ := strconv.ParseUint(e.Data["Capacity"], 10, 64); c == 0 {
				what = "removed"
			} else {
				what += " · " + sizeText(float64(c))
			}
			evs = append(evs, ev{e.Time, what, name})
		}
	}
	if list, err := queryEvents("Microsoft-Windows-Kernel-PnP/Configuration", sinceQuery(usbWindow, 400, 410), 2000); err == nil {
		for _, e := range list {
			id := strings.ToUpper(e.Data["DeviceInstanceId"])
			var name string
			switch {
			case strings.HasPrefix(id, `USBSTOR\`):
				name = prettyUSBClass(strings.Split(strings.TrimPrefix(id, `USBSTOR\`), `\`)[0])
			case strings.HasPrefix(id, `SWD\WPDBUSENUM`):
				name = "phone / media device"
			default:
				continue
			}
			what := "started"
			if e.ID == 400 {
				what = "first time set up"
			}
			evs = append(evs, ev{e.Time, what, name})
		}
	}
	sort.Slice(evs, func(i, j int) bool { return evs[i].t.After(evs[j].t) })
	if len(evs) == 0 {
		row("OK", "Plug-ins", "none in the last 7 days", "")
	}
	for i, e := range evs {
		if i >= 20 {
			report.WriteString(fmt.Sprintf("   %s  %-28s %s\r\n", ts(e.t), e.what, e.name))
			continue
		}
		lvl := "INFO"
		if time.Since(e.t) < 2*time.Hour {
			lvl = "WARN"
		}
		row(lvl, cut(e.name, 24), e.what, e.t.Format("01-02 15:04:05")+" · "+ago(e.t))
	}
	if len(evs) > 20 {
		outln(fmt.Sprintf("   ... %d more in the saved report", len(evs)-20), "DarkGray")
	}

	// ---------------- drive letters USB sticks used
	section("Drive letters used by USB")
	vals, ok := regValues(hklm, `SYSTEM\MountedDevices`)
	letters := []string{}
	if ok {
		for _, v := range vals {
			if !strings.HasPrefix(v.Name, `\DosDevices\`) || len(v.Data) < 16 {
				continue
			}
			u := make([]uint16, len(v.Data)/2)
			for i := range u {
				u[i] = uint16(v.Data[2*i]) | uint16(v.Data[2*i+1])<<8
			}
			s := strings.ToUpper(string(utf16.Decode(u)))
			if strings.Contains(s, "USBSTOR") || strings.Contains(s, "#USB") || strings.Contains(s, "REMOVABLEMEDIA") {
				letters = append(letters, strings.TrimPrefix(v.Name, `\DosDevices\`))
			}
		}
	}
	sort.Strings(letters)
	if len(letters) == 0 {
		row("OK", "USB letters", "none", "")
	} else {
		row("INFO", "USB letters", strings.Join(letters, " "), "execution history flags programs run from these")
	}
}

// "Disk&Ven_SanDisk&Prod_Cruzer_Blade&Rev_1.00" -> "SanDisk Cruzer Blade"
func prettyUSBClass(c string) string {
	var ven, prod string
	for _, part := range strings.Split(c, "&") {
		switch {
		case strings.HasPrefix(strings.ToLower(part), "ven_"):
			ven = part[4:]
		case strings.HasPrefix(strings.ToLower(part), "prod_"):
			prod = part[5:]
		}
	}
	s := strings.TrimSpace(strings.ReplaceAll(ven+" "+prod, "_", " "))
	if s == "" {
		return c
	}
	return s
}
