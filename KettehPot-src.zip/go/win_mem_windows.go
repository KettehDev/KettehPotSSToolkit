//go:build windows

package main

import (
	"errors"
	"syscall"
	"time"
	"unsafe"
)

var (
	procVirtualQueryEx        = kernel32.NewProc("VirtualQueryEx")
	procReadProcessMemory     = kernel32.NewProc("ReadProcessMemory")
	procOpenProcessToken      = advapi32.NewProc("OpenProcessToken")
	procLookupPrivilegeValueW = advapi32.NewProc("LookupPrivilegeValueW")
	procAdjustTokenPrivileges = advapi32.NewProc("AdjustTokenPrivileges")
	procRegQueryInfoKeyW      = advapi32.NewProc("RegQueryInfoKeyW")
)

var debugOn bool

// enableDebugPrivilege lets an admin read memory of service processes (DPS, PcaSvc).
func enableDebugPrivilege() bool {
	if debugOn {
		return true
	}
	cur, _ := syscall.GetCurrentProcess()
	var tok syscall.Token
	if r, _, _ := procOpenProcessToken.Call(uintptr(cur), 0x0020|0x0008, uintptr(unsafe.Pointer(&tok))); r == 0 {
		return false
	}
	defer tok.Close()
	var tp struct {
		Count uint32
		Luid  uint64
		Attr  uint32
	}
	if r, _, _ := procLookupPrivilegeValueW.Call(0, uintptr(unsafe.Pointer(utf16Ptr("SeDebugPrivilege"))), uintptr(unsafe.Pointer(&tp.Luid))); r == 0 {
		return false
	}
	tp.Count, tp.Attr = 1, 0x2 // SE_PRIVILEGE_ENABLED
	r, _, e := procAdjustTokenPrivileges.Call(uintptr(tok), 0, uintptr(unsafe.Pointer(&tp)), 0, 0, 0)
	debugOn = r != 0 && e != syscall.Errno(1300) // ERROR_NOT_ALL_ASSIGNED
	return debugOn
}

type memInfo struct {
	BaseAddress       uintptr
	AllocationBase    uintptr
	AllocationProtect uint32
	PartitionID       uint16
	_                 uint16
	RegionSize        uintptr
	State             uint32
	Protect           uint32
	Type              uint32
	_                 uint32
}

// memWalk hands every readable committed chunk of a process's memory to fn (stop by returning false).
// maxBytes caps how much is read in total.
func memWalk(pid uint32, maxBytes int64, fn func([]byte) bool) (int64, error) {
	enableDebugPrivilege()
	h, err := syscall.OpenProcess(0x0400|0x0010, false, pid) // QUERY_INFORMATION | VM_READ
	if err != nil {
		return 0, err
	}
	defer syscall.CloseHandle(h)
	const chunk = 16 << 20
	buf := make([]byte, chunk)
	var total int64
	var mi memInfo
	addr := uintptr(0)
	for total < maxBytes {
		r, _, _ := procVirtualQueryEx.Call(uintptr(h), addr, uintptr(unsafe.Pointer(&mi)), unsafe.Sizeof(mi))
		if r == 0 {
			break
		}
		next := mi.BaseAddress + mi.RegionSize
		readable := mi.Protect&(0x02|0x04|0x08|0x20|0x40|0x80) != 0 && mi.Protect&(0x100|0x01) == 0
		if mi.State == 0x1000 && readable { // MEM_COMMIT
			for off := uintptr(0); off < mi.RegionSize && total < maxBytes; off += chunk {
				n := mi.RegionSize - off
				if n > chunk {
					n = chunk
				}
				var got uintptr
				ok, _, _ := procReadProcessMemory.Call(uintptr(h), mi.BaseAddress+off, uintptr(unsafe.Pointer(&buf[0])), n, uintptr(unsafe.Pointer(&got)))
				if ok == 0 && got == 0 {
					continue
				}
				total += int64(got)
				if !fn(buf[:got]) {
					return total, nil
				}
			}
		}
		if next <= addr {
			break
		}
		addr = next
	}
	if total == 0 {
		return 0, errors.New("nothing readable")
	}
	return total, nil
}

// regKeyTime returns when a registry key was last written.
func regKeyTime(root regRoot, path string) (time.Time, bool) {
	k, ok := openKey(root, path)
	if !ok {
		return time.Time{}, false
	}
	defer syscall.RegCloseKey(k)
	var ft syscall.Filetime
	r, _, _ := procRegQueryInfoKeyW.Call(uintptr(k), 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, uintptr(unsafe.Pointer(&ft)))
	if r != 0 {
		return time.Time{}, false
	}
	return time.Unix(0, ft.Nanoseconds()), true
}
